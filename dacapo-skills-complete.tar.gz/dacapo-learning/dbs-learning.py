#!/usr/bin/env python3
"""
dbs-learning - 交互式学习进度管理

基于概念网络的自适应学习进度跟踪系统。
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

# 概念网络路径
CONCEPTS_PATH = Path.home() / "Documents/交互式学习/AI内参-dacapo测试/schema/concepts.json"
PROGRESS_DIR = Path.home() / "Documents/交互式学习/AI内参-dacapo测试/.learning-progress"

# 确保进度目录存在
PROGRESS_DIR.mkdir(parents=True, exist_ok=True)


class LearningProgress:
    """学习进度数据类"""

    def __init__(self, concept_id: str):
        self.concept_id = concept_id
        self.status = "not-started"  # not-started | learning | mastered
        self.started_at: Optional[str] = None
        self.mastered_at: Optional[str] = None
        self.view_count = 0
        self.total_time_spent = 0  # 秒
        self.notes = ""

    @classmethod
    def load(cls, concept_id: str) -> 'LearningProgress':
        """从文件加载学习进度"""
        filepath = PROGRESS_DIR / f"{concept_id}.json"

        if filepath.exists():
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                progress = cls(concept_id)
                progress.status = data.get("status", "not-started")
                progress.started_at = data.get("startedAt")
                progress.mastered_at = data.get("masteredAt")
                progress.view_count = data.get("viewCount", 0)
                progress.total_time_spent = data.get("totalTimeSpent", 0)
                progress.notes = data.get("notes", "")
                return progress

        return cls(concept_id)

    def save(self):
        """保存学习进度到文件"""
        filepath = PROGRESS_DIR / f"{self.concept_id}.json"

        data = {
            "conceptId": self.concept_id,
            "status": self.status,
            "startedAt": self.started_at,
            "masteredAt": self.mastered_at,
            "viewCount": self.view_count,
            "totalTimeSpent": self.total_time_spent,
            "notes": self.notes
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def load_concepts() -> Dict:
    """加载概念网络数据"""
    if not CONCEPTS_PATH.exists():
        print(f"❌ 概念文件不存在：{CONCEPTS_PATH}")
        sys.exit(1)

    with open(CONCEPTS_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def get_concept_by_id(concepts: Dict, concept_id: str) -> Optional[Dict]:
    """通过 ID 查找概念"""
    for node in concepts.get("nodes", []):
        if node["id"] == concept_id:
            return node
    return None


def cmd_start(concept_id: str):
    """开始学习某个概念"""
    concepts = load_concepts()
    concept = get_concept_by_id(concepts, concept_id)

    if not concept:
        print(f"❌ 概念不存在：{concept_id}")
        print(f"\n💡 可用概念列表：")
        for node in concepts["nodes"][:10]:
            print(f"   - {node['id']}")
        print(f"   ... 共 {len(concepts['nodes'])} 个概念")
        sys.exit(1)

    # 加载或创建学习进度
    progress = LearningProgress.load(concept_id)

    # 更新状态
    if progress.status == "not-started":
        progress.started_at = datetime.now(timezone.utc).isoformat()
        progress.status = "learning"

    progress.view_count += 1
    progress.save()

    # 显示概念信息
    print(f"📚 开始学习：{concept['name']}")
    print(f"\n{'='*60}")
    print(f"📖 定义：\n{concept['definition']}")
    print(f"\n💡 为什么重要：\n{concept['why']}")

    # 显示依赖关系
    prerequisites = concept.get("prerequisites", [])
    if prerequisites:
        print(f"\n🔗 前置依赖：")
        for prereq_id in prerequisites:
            prereq = get_concept_by_id(concepts, prereq_id)
            prereq_progress = LearningProgress.load(prereq_id)
            status_icon = {
                "not-started": "⭕",
                "learning": "🔄",
                "mastered": "✅"
            }.get(prereq_progress.status, "⭕")
            print(f"   {status_icon} {prereq['name']} ({prereq_id})")

    # 显示统计
    print(f"\n📊 学习统计：")
    print(f"   - 状态：{progress.status}")
    print(f"   - 查看次数：{progress.view_count}")
    print(f"   - 首次学习：{progress.started_at or '未开始'}")

    # 显示来源
    print(f"\n📄 首次出现：{concept['firstAppearance']}")
    print(f"{'='*60}")


def cmd_next():
    """推荐下一个学习概念"""
    concepts = load_concepts()

    # 加载所有学习进度
    progress_map = {}
    for node in concepts["nodes"]:
        progress_map[node["id"]] = LearningProgress.load(node["id"])

    # 找出候选概念（前置依赖已掌握 + 自己未掌握）
    candidates = []
    learning_concepts = [cid for cid, p in progress_map.items() if p.status == "learning"]

    for node in concepts["nodes"]:
        concept_id = node["id"]
        progress = progress_map[concept_id]

        # 跳过已掌握的
        if progress.status == "mastered":
            continue

        # 检查前置依赖
        prerequisites = node.get("prerequisites", [])
        if all(progress_map[dep].status == "mastered" for dep in prerequisites):
            # 计算优先级
            priority = 0
            reasons = []

            # Hub 概念优先
            if node.get("hub", False):
                priority += 100
                reasons.append("Hub 概念（核心）")

            # 被引用次数高的优先
            in_degree = node.get("inDegree", 0)
            priority += in_degree * 5
            if in_degree >= 3:
                reasons.append(f"被引用 {in_degree} 次")

            # 正在学习的概念的依赖优先
            for learning_id in learning_concepts:
                learning_concept = get_concept_by_id(concepts, learning_id)
                if concept_id in learning_concept.get("prerequisites", []):
                    priority += 50
                    reasons.append(f"是「{learning_concept['name']}」的依赖")
                    break

            # 已经开始学习的优先完成
            if progress.status == "learning":
                priority += 30
                reasons.append("已开始学习")

            candidates.append({
                "concept": node,
                "priority": priority,
                "reasons": reasons
            })

    # 排序
    candidates.sort(key=lambda x: x["priority"], reverse=True)

    # 输出推荐
    if not candidates:
        print("🎉 恭喜！所有前置依赖已满足的概念都已掌握。")

        # 显示还有哪些未掌握
        not_mastered = [n for n in concepts["nodes"] if progress_map[n["id"]].status != "mastered"]
        if not_mastered:
            print(f"\n📚 还有 {len(not_mastered)} 个概念等待前置依赖满足：")
            for node in not_mastered[:5]:
                prereqs = node.get("prerequisites", [])
                unmet = [p for p in prereqs if progress_map[p].status != "mastered"]
                print(f"   - {node['name']} （需要先掌握：{', '.join(unmet)}）")
        return

    print("📚 推荐学习概念：\n")

    for i, item in enumerate(candidates[:3], 1):
        concept = item["concept"]
        reasons = item["reasons"]
        priority_label = "高" if item["priority"] >= 100 else "中" if item["priority"] >= 50 else "一般"

        print(f"{i}. {concept['name']} ({concept['id']})")
        print(f"   优先级：{priority_label}")
        if reasons:
            print(f"   理由：{', '.join(reasons)}")

        # 显示依赖状态
        prerequisites = concept.get("prerequisites", [])
        if prerequisites:
            prereq_names = []
            for prereq_id in prerequisites:
                prereq = get_concept_by_id(concepts, prereq_id)
                prereq_names.append(f"{prereq['name']}（✅）")
            print(f"   前置依赖：{', '.join(prereq_names)}")
        else:
            print(f"   前置依赖：无")

        print()

    # 建议命令
    top_concept = candidates[0]["concept"]
    print(f"💡 建议执行：dbs-learning start {top_concept['id']}")


def cmd_status():
    """查看学习进度"""
    concepts = load_concepts()

    # 统计各状态的概念
    mastered = []
    learning = []
    not_started = []

    for node in concepts["nodes"]:
        progress = LearningProgress.load(node["id"])
        if progress.status == "mastered":
            mastered.append(node)
        elif progress.status == "learning":
            learning.append(node)
        else:
            not_started.append(node)

    total = len(concepts["nodes"])
    mastered_count = len(mastered)
    learning_count = len(learning)

    # 输出进度
    percentage = (mastered_count / total * 100) if total > 0 else 0
    print(f"📊 学习进度：{mastered_count}/{total} 概念已掌握（{percentage:.1f}%）\n")

    # 已掌握
    if mastered:
        print(f"✅ 已掌握（{mastered_count}）：")
        for node in mastered[:10]:
            print(f"   - {node['name']} ({node['id']})")
        if len(mastered) > 10:
            print(f"   ... 还有 {len(mastered) - 10} 个")
        print()

    # 学习中
    if learning:
        print(f"🔄 学习中（{learning_count}）：")
        for node in learning:
            progress = LearningProgress.load(node["id"])
            print(f"   - {node['name']} ({node['id']}) - 查看 {progress.view_count} 次")
        print()

    # 建议
    if learning_count > 0:
        print("💡 建议下一步：")
        print("   1. 完成正在学习的概念")
        print("   2. 执行 `dbs-learning next` 获取新推荐")
    else:
        print("💡 建议下一步：")
        print("   - 执行 `dbs-learning next` 开始学习")


def cmd_mark(concept_id: str, status: str):
    """手动标记概念掌握状态"""
    valid_statuses = ["not-started", "learning", "mastered"]

    if status not in valid_statuses:
        print(f"❌ 无效状态：{status}")
        print(f"有效状态：{', '.join(valid_statuses)}")
        sys.exit(1)

    concepts = load_concepts()
    concept = get_concept_by_id(concepts, concept_id)

    if not concept:
        print(f"❌ 概念不存在：{concept_id}")
        sys.exit(1)

    # 加载并更新进度
    progress = LearningProgress.load(concept_id)
    old_status = progress.status
    progress.status = status

    # 更新时间戳
    now = datetime.now(timezone.utc).isoformat()
    if status == "learning" and not progress.started_at:
        progress.started_at = now
    elif status == "mastered" and not progress.mastered_at:
        progress.mastered_at = now

    progress.save()

    status_icon = {
        "not-started": "⭕",
        "learning": "🔄",
        "mastered": "✅"
    }

    print(f"{status_icon[status]} 已更新：{concept['name']}")
    print(f"   {old_status} → {status}")


def main():
    if len(sys.argv) < 2:
        print("用法：")
        print("  dbs-learning start <concept-id>   - 开始学习概念")
        print("  dbs-learning next                 - 获取下一个推荐")
        print("  dbs-learning status               - 查看学习进度")
        print("  dbs-learning mark <id> <status>   - 标记概念状态")
        sys.exit(1)

    command = sys.argv[1]

    if command == "start":
        if len(sys.argv) < 3:
            print("❌ 缺少参数：concept-id")
            sys.exit(1)
        cmd_start(sys.argv[2])

    elif command == "next":
        cmd_next()

    elif command == "status":
        cmd_status()

    elif command == "mark":
        if len(sys.argv) < 4:
            print("❌ 缺少参数：concept-id 和 status")
            sys.exit(1)
        cmd_mark(sys.argv[2], sys.argv[3])

    else:
        print(f"❌ 未知命令：{command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
