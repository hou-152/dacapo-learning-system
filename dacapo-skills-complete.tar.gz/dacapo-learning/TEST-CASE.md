# dbs-learning 测试用例

## 测试目标

验证 dbs-learning 能够：
1. 正确解析学习上下文
2. 基于已学概念生成复利式问题
3. 评估用户答案并计算掌握度
4. 更新概念文件的 frontmatter

## 测试用例 1：无上下文学习 harness

### 前置条件
- concepts/harness.md 存在
- frontmatter 中 mastery 为 null 或不存在

### 执行命令
```bash
cd ~/.openclaw-autoclaw/skills/dbs-learning
python interactive_learning.py learn harness
```

### 预期交互流程

```
📚 学习概念：harness
============================================================

📖 定义：
我们用来把 AI agent 管住的工具与实践。

💡 为什么重要：
既限制它乱跑，又让它的力气能被用上。

============================================================

### 问题 1
用一句话说说你理解的「harness」是什么？

你的回答：[用户输入：管理 agent 的工具框架]

✓ 包含关键词：管理, agent, 工具, 框架 — 理解正确 (评分: 0.8)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：[用户输入：Claude Code 的权限控制系统]

✓ 提到了实际案例 (评分: 0.6)

============================================================
### 掌握度：70%
📖 学习中，继续加油

建议下一步：
1. 查看概念在文章中的实际应用
2. 尝试在项目中使用这个概念

✓ 已更新概念文件的 mastery 字段
✓ 后台触发联想推荐（由 llm-wiki 处理）
============================================================
```

### 验证结果

检查 `concepts/harness.md` frontmatter：
```yaml
---
tags: concept
inDegree: 1
firstAppearance: "[[01-Martin-Fowler-harness-engineering]]"
mastery: 0.7  # 新增
lastStudied: 2026-09-28T10:30:00Z  # 新增
studyCount: 1  # 新增
---
```

## 测试用例 2：带上下文学习 agent（利用已学 harness）

### 前置条件
- concepts/agent.md 存在
- concepts/harness.md 已学习，mastery = 0.8

### 执行命令
```bash
python interactive_learning.py learn agent "learned: harness(0.8), context-engineering(0.7); connections: harness → agent → deployment"
```

### 预期交互流程

```
📚 学习概念：agent
============================================================

📖 定义：
能够自主决策和执行任务的智能体，通过工具调用与环境交互。

💡 为什么重要：
agent 是 AI 应用的核心抽象，决定了系统的智能程度和可控性。

🔗 你已经学过的相关概念：
   ✅ harness (掌握度: 80%)
   🔄 context-engineering (掌握度: 70%)

🌿 草蛇灰线：harness → agent → deployment

============================================================

### 问题 1
还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？

你的回答：[用户输入：agent 是被 harness 管理的实体，harness 提供约束和工具，agent 在其中执行任务]

✓ 包含关键词：管理, 约束, 工具, 执行 — 理解正确 (评分: 0.9)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：[用户输入：AI 内参文章里的 Martin Fowler 案例]

✓ 提到了首次出现的来源 (评分: 0.8)

============================================================
### 掌握度：85%
🎉 掌握得很好！

建议下一步：
1. 学习依赖这个概念的下游概念
2. 分享你的理解给他人

✓ 已更新概念文件的 mastery 字段
✓ 后台触发联想推荐（由 llm-wiki 处理）
============================================================
```

### 验证结果

检查 `concepts/agent.md` frontmatter：
```yaml
---
tags: concept
inDegree: 5
firstAppearance: "[[01-Martin-Fowler-harness-engineering]]"
mastery: 0.85  # 新增
lastStudied: 2026-09-28T10:45:00Z  # 新增
studyCount: 1  # 新增
---
```

### 核心验证点

1. ✅ **上下文解析**：正确解析 learned 和 connections
2. ✅ **复利式提问**：问题 1 提到了已学的 harness
3. ✅ **关联展示**：显示已学概念和草蛇灰线
4. ✅ **掌握度计算**：(0.9 + 0.8) / 2 = 0.85
5. ✅ **frontmatter 更新**：mastery、lastStudied、studyCount 正确写入

## 测试用例 3：查看学习状态

### 前置条件
- 已完成用例 1 和用例 2
- harness (mastery: 0.7)
- agent (mastery: 0.85)
- 其他概念未学习

### 执行命令
```bash
python interactive_learning.py status
```

### 预期输出

```
📊 学习进度总览

总计：13 个概念
已掌握：1 个 (≥80%)
学习中：1 个 (1-79%)
未开始：11 个

✅ 已掌握：
   agent (85%)

🔄 学习中：
   harness (70%)

⭕ 未开始：context-engineering, deployment, service-template, 架构约束的确定性执行, 解空间收窄, 卡住即信号, 垃圾回收型-agent, ...
```

## 测试用例 4：边界情况 - 概念不存在

### 执行命令
```bash
python interactive_learning.py learn nonexistent-concept
```

### 预期输出
```
❌ 概念不存在：nonexistent-concept
   路径：/Users/housibo/Documents/dacapo-学习仓库/concepts/nonexistent-concept.md
```

## 测试用例 5：边界情况 - 重复学习

### 前置条件
- harness 已学习过，mastery = 0.7，studyCount = 1

### 执行命令
```bash
python interactive_learning.py learn harness
```

### 预期行为
- 正常执行学习流程
- 重新计算 mastery（可能上升或下降）
- studyCount 累加到 2
- lastStudied 更新为新时间

### 验证结果
```yaml
---
mastery: 0.75  # 可能变化
lastStudied: 2026-09-28T11:00:00Z  # 更新
studyCount: 2  # 累加
---
```

## 自动化测试脚本

```bash
#!/bin/bash
# 运行所有测试用例

SKILL_DIR=~/.openclaw-autoclaw/skills/dbs-learning
CONCEPTS_DIR=~/Documents/dacapo-学习仓库/concepts

cd $SKILL_DIR

echo "=== 测试用例 1: 无上下文学习 harness ==="
python interactive_learning.py learn harness <<EOF
管理 agent 的工具框架
Claude Code 的权限控制系统
EOF

echo -e "\n=== 验证 harness frontmatter ==="
head -10 $CONCEPTS_DIR/harness.md

echo -e "\n=== 测试用例 2: 带上下文学习 agent ==="
python interactive_learning.py learn agent "learned: harness(0.8); connections: harness → agent" <<EOF
agent 是被 harness 管理的实体，harness 提供约束和工具，agent 在其中执行任务
AI 内参文章里的 Martin Fowler 案例
EOF

echo -e "\n=== 验证 agent frontmatter ==="
head -10 $CONCEPTS_DIR/agent.md

echo -e "\n=== 测试用例 3: 查看学习状态 ==="
python interactive_learning.py status

echo -e "\n=== 测试用例 4: 概念不存在 ==="
python interactive_learning.py learn nonexistent-concept || echo "预期错误"

echo -e "\n=== 所有测试完成 ==="
```

## 测试检查清单

- [ ] 解析学习上下文正确
- [ ] 无上下文时正常提问
- [ ] 有已学概念时生成复利式问题
- [ ] 答案评估逻辑正确
- [ ] frontmatter 正确更新（mastery, lastStudied, studyCount）
- [ ] status 命令正确显示统计
- [ ] 边界情况处理正常（不存在的概念、重复学习）
- [ ] YAML 格式保持正确（不破坏原有字段）
