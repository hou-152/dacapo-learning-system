#!/usr/bin/env python3
"""
interactive_learning.py - 接收上下文的交互式学习执行器

核心功能：
1. 从提示词中解析学习上下文（已学概念、掌握度、草蛇灰线）
2. 复利式学习对话（利用已学概念）
3. 2 问题快速评估
4. frontmatter 记录
5. 触发 llm-wiki 后台推荐
"""

import os
import re
import sys
import yaml
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# 概念库路径
CONCEPTS_DIR = Path.home() / "Documents/dacapo-学习仓库/concepts"


class ConceptFile:
    """概念文件操作类"""

    def __init__(self, concept_name: str):
        self.concept_name = concept_name
        self.filepath = CONCEPTS_DIR / f"{concept_name}.md"
        self.frontmatter: Dict = {}
        self.content: str = ""

    def exists(self) -> bool:
        return self.filepath.exists()

    def load(self) -> bool:
        """加载概念文件，解析 frontmatter 和内容"""
        if not self.exists():
            return False

        with open(self.filepath, 'r', encoding='utf-8') as f:
            text = f.read()

        # 解析 YAML frontmatter
        if text.startswith('---'):
            parts = text.split('---', 2)
            if len(parts) >= 3:
                try:
                    self.frontmatter = yaml.safe_load(parts[1]) or {}
                    self.content = parts[2].strip()
                except yaml.YAMLError:
                    self.frontmatter = {}
                    self.content = text
            else:
                self.content = text
        else:
            self.content = text

        return True

    def save(self):
        """保存概念文件，更新 frontmatter"""
        # 构建新的文件内容
        frontmatter_text = yaml.dump(self.frontmatter, allow_unicode=True, sort_keys=False)
        new_content = f"---\n{frontmatter_text}---\n\n{self.content}"

        with open(self.filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)

    def update_mastery(self, mastery: float, study_count_increment: int = 1):
        """更新掌握度和学习统计"""
        self.frontmatter['mastery'] = round(mastery, 2)
        self.frontmatter['lastStudied'] = datetime.now(timezone.utc).isoformat()

        current_count = self.frontmatter.get('studyCount', 0)
        self.frontmatter['studyCount'] = current_count + study_count_increment

    def get_definition(self) -> str:
        """提取定义部分"""
        match = re.search(r'##\s*定义\s*\n\n(.*?)(?=\n##|\Z)', self.content, re.DOTALL)
        return match.group(1).strip() if match else ""

    def get_importance(self) -> str:
        """提取重要性说明"""
        match = re.search(r'##\s*为什么重要\s*\n\n(.*?)(?=\n##|\Z)', self.content, re.DOTALL)
        return match.group(1).strip() if match else ""


class LearningContext:
    """学习上下文数据类"""

    def __init__(self):
        self.learned_concepts: Dict[str, float] = {}  # 已学概念 -> 掌握度
        self.connections: List[str] = []  # 草蛇灰线连接
        self.recommended_angles: List[str] = []  # 推荐理解角度

    @classmethod
    def parse_from_prompt(cls, prompt: str) -> 'LearningContext':
        """从提示词中解析学习上下文

        期望格式：
        LEARNING_CONTEXT:
        - learned: harness(0.8), context-engineering(0.7)
        - connections: harness → agent → deployment
        - angles: 从工具角度理解, 对比传统编程
        """
        ctx = cls()

        # 解析已学概念
        learned_match = re.search(r'learned:\s*([^\n]+)', prompt)
        if learned_match:
            items = learned_match.group(1).split(',')
            for item in items:
                match = re.match(r'(\w[\w-]*)\s*\(([0-9.]+)\)', item.strip())
                if match:
                    concept, mastery = match.groups()
                    ctx.learned_concepts[concept] = float(mastery)

        # 解析连接
        connections_match = re.search(r'connections:\s*([^\n]+)', prompt)
        if connections_match:
            ctx.connections = [c.strip() for c in connections_match.group(1).split('→')]

        # 解析推荐角度
        angles_match = re.search(r'angles:\s*([^\n]+)', prompt)
        if angles_match:
            ctx.recommended_angles = [a.strip() for a in angles_match.group(1).split(',')]

        return ctx


def assess_answer(question_type: str, answer: str, concept_file: ConceptFile,
                 context: Optional[LearningContext] = None) -> Tuple[float, str]:
    """评估用户答案，返回 (分数, 反馈)"""

    if question_type == "definition":
        # 提取定义中的关键词
        definition = concept_file.get_definition()
        keywords = extract_keywords(definition)

        # 检查答案中包含的关键词
        answer_lower = answer.lower()
        matched = [kw for kw in keywords if kw.lower() in answer_lower]

        score = len(matched) / max(len(keywords), 1)
        score = min(score, 1.0)

        feedback = f"✓ 包含关键词：{', '.join(matched) if matched else '(无)'}"
        if score >= 0.6:
            feedback += " — 理解正确"
        elif score >= 0.3:
            feedback += " — 部分理解"
        else:
            feedback += " — 建议重新阅读定义"

        return score, feedback

    elif question_type == "example":
        # 检查是否提到首次出现的来源
        first_appearance = concept_file.frontmatter.get('firstAppearance', '')

        if first_appearance and first_appearance.replace('[[', '').replace(']]', '') in answer:
            return 0.8, "✓ 提到了首次出现的来源"
        elif any(word in answer for word in ['文章', '内参', '项目', '案例']):
            return 0.6, "✓ 提到了实际案例"
        else:
            return 0.3, "建议回顾概念的实际出现场景"

    return 0.5, "已记录答案"


def extract_keywords(text: str) -> List[str]:
    """从文本中提取关键词（简单实现）"""
    # 移除标点和停用词
    text = re.sub(r'[，。！？、；：""''（）《》\s]+', ' ', text)
    words = text.split()

    # 过滤停用词（简化版）
    stopwords = {'的', '是', '在', '和', '了', '有', '个', '这', '那', '我们', '就是'}
    keywords = [w for w in words if w not in stopwords and len(w) >= 2]

    return keywords[:5]  # 返回前 5 个关键词


def generate_compound_question(concept_name: str, context: LearningContext) -> Optional[str]:
    """基于已学概念生成复利式问题"""
    if not context.learned_concepts:
        return None

    # 选择掌握度最高的相关概念
    best_learned = max(context.learned_concepts.items(), key=lambda x: x[1])
    learned_name, mastery = best_learned

    if mastery >= 0.7:
        return f"还记得你学过的「{learned_name}」吗？试着用它来理解「{concept_name}」——它们有什么联系？"

    return None


def interactive_learn(concept_name: str, prompt_context: str = ""):
    """执行交互式学习"""

    # 加载概念文件
    concept = ConceptFile(concept_name)
    if not concept.load():
        print(f"❌ 概念不存在：{concept_name}")
        print(f"   路径：{concept.filepath}")
        sys.exit(1)

    # 解析学习上下文
    context = LearningContext.parse_from_prompt(prompt_context)

    print(f"📚 学习概念：{concept_name}")
    print(f"{'='*60}\n")

    # 显示定义和重要性
    definition = concept.get_definition()
    importance = concept.get_importance()

    if definition:
        print(f"📖 定义：\n{definition}\n")
    if importance:
        print(f"💡 为什么重要：\n{importance}\n")

    # 显示学习上下文（如果有）
    if context.learned_concepts:
        print(f"🔗 你已经学过的相关概念：")
        for name, mastery in context.learned_concepts.items():
            icon = "✅" if mastery >= 0.8 else "🔄"
            print(f"   {icon} {name} (掌握度: {mastery:.0%})")
        print()

    if context.connections:
        print(f"🌿 草蛇灰线：{' → '.join(context.connections)}\n")

    print(f"{'='*60}\n")

    # 问题 1：定义理解
    print("### 问题 1")
    compound_q = generate_compound_question(concept_name, context)
    if compound_q:
        print(compound_q)
    else:
        print(f"用一句话说说你理解的「{concept_name}」是什么？")

    answer1 = input("\n你的回答：").strip()
    score1, feedback1 = assess_answer("definition", answer1, concept, context)
    print(f"\n{feedback1} (评分: {score1:.1f})\n")

    # 问题 2：实例应用
    print("### 问题 2")
    print("能举个你见过或想到的例子吗？")

    answer2 = input("\n你的回答：").strip()
    score2, feedback2 = assess_answer("example", answer2, concept, context)
    print(f"\n{feedback2} (评分: {score2:.1f})\n")

    # 计算总体掌握度
    avg_mastery = (score1 + score2) / 2

    # 更新 frontmatter
    concept.update_mastery(avg_mastery)
    concept.save()

    print(f"{'='*60}")
    print(f"### 掌握度：{avg_mastery:.0%}")

    if avg_mastery >= 0.8:
        print("🎉 掌握得很好！")
    elif avg_mastery >= 0.5:
        print("📖 学习中，继续加油")
    else:
        print("💪 建议重新学习")

    # 给出学习建议
    print(f"\n建议下一步：")
    if avg_mastery < 0.5:
        print(f"1. 重读概念定义和重要性说明")
        print(f"2. 查看首次出现：{concept.frontmatter.get('firstAppearance', '未记录')}")
    elif avg_mastery < 0.8:
        print(f"1. 查看概念在文章中的实际应用")
        print(f"2. 尝试在项目中使用这个概念")
    else:
        print(f"1. 学习依赖这个概念的下游概念")
        print(f"2. 分享你的理解给他人")

    print(f"\n✓ 已更新概念文件的 mastery 字段")
    print(f"✓ 后台触发联想推荐（由 llm-wiki 处理）")
    print(f"{'='*60}")


def show_status():
    """显示所有概念的学习状态"""
    if not CONCEPTS_DIR.exists():
        print(f"❌ 概念目录不存在：{CONCEPTS_DIR}")
        sys.exit(1)

    mastered = []
    learning = []
    not_started = []

    for filepath in CONCEPTS_DIR.glob("*.md"):
        concept = ConceptFile(filepath.stem)
        if concept.load():
            mastery = concept.frontmatter.get('mastery')

            if mastery is None:
                not_started.append(filepath.stem)
            elif mastery >= 0.8:
                mastered.append((filepath.stem, mastery))
            else:
                learning.append((filepath.stem, mastery))

    total = len(mastered) + len(learning) + len(not_started)

    print(f"📊 学习进度总览\n")
    print(f"总计：{total} 个概念")
    print(f"已掌握：{len(mastered)} 个 (≥80%)")
    print(f"学习中：{len(learning)} 个 (1-79%)")
    print(f"未开始：{len(not_started)} 个\n")

    if mastered:
        print("✅ 已掌握：")
        for name, mastery in sorted(mastered, key=lambda x: x[1], reverse=True):
            print(f"   {name} ({mastery:.0%})")
        print()

    if learning:
        print("🔄 学习中：")
        for name, mastery in sorted(learning, key=lambda x: x[1], reverse=True):
            print(f"   {name} ({mastery:.0%})")
        print()

    if not_started:
        print(f"⭕ 未开始：{', '.join(not_started[:10])}")
        if len(not_started) > 10:
            print(f"   ... 还有 {len(not_started) - 10} 个")


def main():
    if len(sys.argv) < 2:
        print("用法：")
        print("  python interactive_learning.py learn <concept> [context]")
        print("  python interactive_learning.py status")
        sys.exit(1)

    command = sys.argv[1]

    if command == "learn":
        if len(sys.argv) < 3:
            print("❌ 缺少参数：concept")
            sys.exit(1)

        concept_name = sys.argv[2]
        context = sys.argv[3] if len(sys.argv) > 3 else ""
        interactive_learn(concept_name, context)

    elif command == "status":
        show_status()

    else:
        print(f"❌ 未知命令：{command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
