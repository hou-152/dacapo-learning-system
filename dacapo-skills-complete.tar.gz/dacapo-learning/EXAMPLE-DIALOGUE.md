# 示例对话流程 - dbs-learning 复利式学习

本文档展示 dbs-learning 如何利用学习上下文实现复利式学习，对比传统学习方式的差异。

## 场景：学习 agent 概念

### 传统方式（无上下文）

```
📚 学习概念：agent
============================================================

📖 定义：
能够自主决策和执行任务的智能体，通过工具调用与环境交互。

💡 为什么重要：
agent 是 AI 应用的核心抽象，决定了系统的智能程度和可控性。

============================================================

### 问题 1
用一句话说说你理解的「agent」是什么？

你的回答：能自动做事的程序

✓ 包含关键词：自动 — 部分理解 (评分: 0.4)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：不太清楚

建议回顾概念的实际出现场景 (评分: 0.3)

============================================================
### 掌握度：35%
💪 建议重新学习

建议下一步：
1. 重读概念定义和重要性说明
2. 查看首次出现：[[01-Martin-Fowler-harness-engineering]]
============================================================
```

**问题**：
- 用户没有关联已学知识
- 答案泛泛而谈，缺乏深度
- 评分低，学习效果差

---

### 复利式方式（带上下文）

**前提**：用户已学习 harness (掌握度 80%)、context-engineering (掌握度 70%)

**llm-wiki 提供的上下文**：
```
LEARNING_CONTEXT:
- learned: harness(0.8), context-engineering(0.7)
- connections: harness → agent → deployment
- angles: agent 是被 harness 管住的对象, agent 需要 context-engineering 来获取信息
```

**交互流程**：

```
📚 学习概念：agent
============================================================

📖 定义：
能够自主决策和执行任务的智能体，通过工具调用与环境交互。

💡 为什么重要：
agent 是 AI 应用的核心抽象，决定了系统的智能程度和可控性。

🔗 你已经学过的相关概念：
   ✅ harness (掌握度: 80%)
   🔄 context-engineering (掌握度: 70%)

🌿 草蛇灰线：harness → agent → deployment

============================================================

### 问题 1
还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？

你的回答：harness 是管理 agent 的工装，agent 是被管理的智能体。harness 提供工具和约束，agent 在这个框架内执行任务。就像马套上挽具才能拉车，agent 套上 harness 才能可控地工作。

✓ 包含关键词：管理, 工装, 智能体, 约束, 框架, 执行 — 理解正确 (评分: 0.9)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：Martin Fowler 那篇文章里讲的，Claude Code 就是一个 agent，它通过 harness 提供的工具（文件读写、命令执行）来完成编程任务，同时 harness 限制了它不能做危险操作。

✓ 提到了首次出现的来源 (评分: 0.8)

============================================================
### 掌握度：85%
🎉 掌握得很好！

建议下一步：
1. 学习依赖这个概念的下游概念
2. 分享你的理解给他人

✓ 已更新概念文件的 mastery 字段
✓ 后台触发联想推荐（由 llm-wiki 处理）
============================================================
```

**优势**：
- ✅ 唤起已学概念记忆（harness）
- ✅ 强化概念间连接（harness 管理 agent）
- ✅ 答案有深度和关联
- ✅ 掌握度显著提升（35% → 85%）

---

## 复利效应分析

### 知识连接强化

| 维度 | 传统方式 | 复利式方式 |
|------|----------|-----------|
| **提问方式** | 「agent 是什么？」 | 「harness 和 agent 的关系？」 |
| **思考深度** | 孤立定义 | 关系理解 |
| **记忆方式** | 单点记忆 | 网络记忆 |
| **遗忘速度** | 快 | 慢（有锚点） |

### 学习路径对比

**传统路径**（线性）：
```
harness → 学完忘记
agent → 从零理解
context-engineering → 从零理解
deployment → 从零理解
```

**复利式路径**（网络）：
```
harness (80%) 
  ↓ 用来理解
agent (85%) ← 同时关联 context-engineering (70%)
  ↓ 用来理解
deployment (预计 88%)
  ↓ 用来理解
monitoring (预计 90%)
```

### 掌握度增长曲线

```
传统方式：
概念1: 60% → 概念2: 55% → 概念3: 50% (遗忘导致下降)

复利式方式：
概念1: 70% → 概念2: 75% → 概念3: 80% → 概念4: 85% (复利增长)
```

---

## 完整学习链示例

### 学习序列：harness → agent → deployment

#### 第 1 步：学习 harness（无依赖）

```bash
python interactive_learning.py learn harness
```

无上下文，直接提问：
- Q1: 用一句话说说你理解的「harness」是什么？
- Q2: 能举个你见过的例子吗？

结果：mastery = 0.75

---

#### 第 2 步：学习 agent（依赖 harness）

```bash
python interactive_learning.py learn agent "learned: harness(0.75)"
```

复利式提问：
- Q1: 还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？

结果：
- 因为利用了 harness 的锚点，理解更深
- mastery = 0.82

**附带效应**：harness 的记忆被强化（虽然没有重新测试，但通过关联使用而巩固）

---

####第 3 步：学习 deployment（依赖 agent 和 harness）

```bash
python interactive_learning.py learn deployment "learned: harness(0.75), agent(0.82); connections: harness → agent → deployment"
```

显示学习上下文：
```
🔗 你已经学过的相关概念：
   ✅ agent (掌握度: 82%)
   🔄 harness (掌握度: 75%)

🌿 草蛇灰线：harness → agent → deployment
```

复利式提问：
- Q1: 还记得你学过的「agent」吗？试着用它来理解「deployment」——agent 如何被部署？

结果：
- 同时关联了两个已学概念
- mastery = 0.88

**复利累积**：
- harness (0.75) 被第三次使用，记忆深度 +++
- agent (0.82) 被第二次使用，记忆深度 ++
- deployment (0.88) 建立在坚实基础上

---

## 关键设计点

### 1. 上下文解析
从 llm-wiki 提供的提示词中提取：
```python
context = LearningContext.parse_from_prompt(prompt)
# learned: harness(0.8), context-engineering(0.7)
# connections: harness → agent → deployment
```

### 2. 复利式问题生成
```python
def generate_compound_question(concept_name: str, context: LearningContext):
    if context.learned_concepts:
        # 选择掌握度最高的相关概念
        best_learned = max(context.learned_concepts.items(), key=lambda x: x[1])
        learned_name, mastery = best_learned
        
        if mastery >= 0.7:  # 只有掌握得好的概念才用于复利
            return f"还记得你学过的「{learned_name}」吗？试着用它来理解「{concept_name}」——它们有什么联系？"
    
    return None  # 回退到传统提问
```

### 3. 评估关系理解
不只是评估定义记忆，更评估概念间关系：
```python
# 检查答案是否同时提到两个概念
if learned_name in answer and concept_name in answer:
    score += 0.2  # 奖励关联理解
```

---

## 与 llm-wiki 的协作

### llm-wiki 的职责
1. 分析用户已学概念及掌握度
2. 识别概念间的草蛇灰线连接
3. 生成学习上下文并传递给 dbs-learning

### dbs-learning 的职责
1. 接收并解析学习上下文
2. 基于上下文生成复利式问题
3. 评估答案并更新掌握度
4. 学习完成后触发 llm-wiki 更新推荐

### 数据闭环
```
llm-wiki 读取 frontmatter (mastery)
    ↓
生成学习上下文
    ↓
dbs-learning 交互学习
    ↓
更新 frontmatter (mastery)
    ↓
触发 llm-wiki 后台推荐
    ↓
llm-wiki 读取新的 mastery
    ↓
生成新的推荐
```

---

## 总结

复利式学习的核心优势：
1. **记忆锚点**：用已学概念作为新概念的锚点
2. **关系强化**：每次学习都强化概念网络
3. **深度理解**：评估关系而非死记定义
4. **增长曲线**：掌握度随学习推进而提升，而非下降

实现要点：
1. **轻量接收上下文**：解析简单格式，不做复杂推理
2. **智能回退**：无上下文时回退到传统提问
3. **规则评估**：关键词匹配，不依赖 LLM
4. **数据驱动**：frontmatter 是唯一数据源
