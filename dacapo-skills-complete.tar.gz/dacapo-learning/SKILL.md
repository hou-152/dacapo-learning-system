# dbs-learning - 接收上下文的交互式学习

**作用**：轻量交互式学习执行器，接收 llm-wiki 提供的学习上下文，通过复利式对话评估概念掌握度。

## 核心定位

**从 dispatch 接收上下文 → 复利式对话 → 快速评估 → frontmatter 记录 → 触发 llm-wiki**

## 使用场景

### 场景 1：独立学习（无上下文）
```
/dbs-learning harness
```

系统会：
1. 读取 `concepts/harness.md`
2. 问 2 个问题评估理解
3. 将掌握度写入 frontmatter：`mastery: 0.75`
4. 根据掌握度给出学习建议

### 场景 2：带上下文学习（从 dispatch）
```
/dbs-learning agent --context "learned: harness(0.8), context-engineering(0.7); connections: harness → agent → deployment"
```

系统会：
1. 解析学习上下文（已学概念、连接）
2. **复利式提问**：「还记得你学过的「harness」吗？试着用它来理解「agent」」
3. 评估时参考已学概念的掌握度
4. 更新 frontmatter 并触发 llm-wiki 推荐

## 执行流程

### 1. 接收学习上下文（新增）

从 dispatch 提供的提示词中解析：
```
LEARNING_CONTEXT:
- learned: harness(0.8), context-engineering(0.7)
- connections: harness → agent → deployment
- angles: 从工具角度理解, 对比传统编程
```

解析结果：
- `learned_concepts`: {harness: 0.8, context-engineering: 0.7}
- `connections`: [harness, agent, deployment]
- `recommended_angles`: [从工具角度理解, 对比传统编程]

### 2. 读取概念文件
```yaml
# concepts/agent.md frontmatter
---
tags: concept
inDegree: 3
firstAppearance: "[[01-Martin-Fowler-harness-engineering]]"
mastery: null  # 首次学习为 null
lastStudied: null
studyCount: 0
---
```

### 3. 复利式学习对话（核心创新）

展示概念定义和重要性后，显示学习上下文：

```
🔗 你已经学过的相关概念：
   ✅ harness (掌握度: 80%)
   🔄 context-engineering (掌握度: 70%)

🌿 草蛇灰线：harness → agent → deployment
```

### 4. 掌握度评估（2 个问题）

**问题 1（复利式）**：
- 有已学概念且掌握度 ≥ 0.7：「还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？」
- 无已学概念：「用一句话说说你理解的「agent」是什么？」

评估方式：基于关键词匹配给出分数 0-1

**问题 2**：「能举个你见过或想到的例子吗？」

评估方式：检查是否提到 firstAppearance 中的来源

平均分 = (问题1分数 + 问题2分数) / 2

### 5. 更新 frontmatter

```yaml
---
tags: concept
inDegree: 3
firstAppearance: "[[01-Martin-Fowler-harness-engineering]]"
mastery: 0.65  # 新增/更新
lastStudied: 2026-09-28T15:30:00Z  # 新增/更新
studyCount: 1  # 新增/累加
---
```

### 6. 给出学习建议

- mastery < 0.5：建议重读概念定义，查看首次出现的文章
- mastery 0.5-0.8：建议查看概念在文章中的实际应用
- mastery ≥ 0.8：建议学习依赖这个概念的下游概念

### 7. 触发 llm-wiki（后台静默）

学习完成后，后台调用 `llm-wiki push <concept>` 生成联想推荐，不阻塞当前对话。

## 输出示例

### 示例 1：带上下文学习（复利式）

```markdown
📚 学习概念：agent
============================================================

📖 定义：
能够自主决策和执行任务的智能体，通过工具调用与环境交互。

💡 为什么重要：
agent 是 AI 应用的核心抽象，决定了系统的智能程度和可控性。

🔗 你已经学过的相关概念：
   ✅ harness (掌握度: 80%)
   🔄 context-engineering (掌握度: 70%)

🌿 草蛇灰线：harness → agent → deployment

============================================================

### 问题 1
还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？

你的回答：harness 是管住 agent 的工装，agent 需要 harness 来限制和引导它的行为

✓ 包含关键词：管住, 工装, 限制 — 理解正确 (评分: 0.8)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：Claude Code 就是一个 agent，通过 harness 控制它的工具调用

✓ 提到了实际案例 (评分: 0.7)

============================================================
### 掌握度：75%
📖 学习中，继续加油

建议下一步：
1. 查看概念在文章中的实际应用
2. 尝试在项目中使用这个概念

✓ 已更新概念文件的 mastery 字段
✓ 后台触发联想推荐（由 llm-wiki 处理）
============================================================
```

### 示例 2：无上下文学习

```markdown
📚 学习概念：harness
============================================================

📖 定义：
我们用来把 AI agent 管住的工具与实践。

💡 为什么重要：
既限制它乱跑，又让它的力气能被用上。

============================================================

### 问题 1
用一句话说说你理解的「harness」是什么？

你的回答：控制 AI 的框架

✓ 包含关键词：控制, 框架 — 部分理解 (评分: 0.5)

### 问题 2
能举个你见过或想到的例子吗？

你的回答：没见过具体的

建议回顾概念的实际出现场景 (评分: 0.3)

============================================================
### 掌握度：40%
💪 建议重新学习

建议下一步：
1. 重读概念定义和重要性说明
2. 查看首次出现：[[01-Martin-Fowler-harness-engineering]]

✓ 已更新概念文件的 mastery 字段
✓ 后台触发联想推荐（由 llm-wiki 处理）
============================================================
```

## 数据结构

**全部数据都在概念文件的 frontmatter 中**，不需要额外的 JSON 文件：

```yaml
---
name: agent
dependencies: [harness, context-engineering]
inDegree: 5
mastery: 0.75
lastStudied: 2026-09-12T15:30:00Z
studyCount: 2
---
```

**联想推荐缓存**（可选，仅用于 llm-wiki）：
- 位置：`~/Documents/dacapo-学习仓库/.learning-progress/suggestions.json`
- 由 llm-wiki 后台写入，dbs-learning 只读取显示

## 命令

### `python interactive_learning.py learn <concept> [context]`
开始学习指定概念（主命令）

参数：
- `<concept>`: 概念名（对应 concepts/ 下的文件名，不含 .md）
- `[context]`: 可选的学习上下文字符串

示例：
```bash
# 无上下文学习
python interactive_learning.py learn harness

# 带上下文学习
python interactive_learning.py learn agent "learned: harness(0.8); connections: harness → agent"
```

### `python interactive_learning.py status`
查看所有概念的掌握度总览：
```markdown
📊 学习进度总览

总计：13 个概念
已掌握：2 个 (≥80%)
学习中：3 个 (1-79%)
未开始：8 个

✅ 已掌握：
   harness (85%)
   context-engineering (82%)

🔄 学习中：
   agent (75%)
   deployment (60%)
   service-template (45%)
```

## 核心创新：复利式学习

传统学习：每个概念独立评估，不利用已学知识
复利式学习：基于已学概念提问，强化知识连接

### 示例对比

**传统提问**：
> Q: 用一句话说说你理解的「agent」是什么？

**复利式提问**（已学 harness，掌握度 80%）：
> Q: 还记得你学过的「harness」吗？试着用它来理解「agent」——它们有什么联系？

复利效应：
1. 唤起已学概念记忆
2. 强化概念间连接
3. 评估关系理解（不只是定义记忆）
4. 构建知识网络而非孤立知识点

## 轻量化原则

1. **不做复杂状态机**：2 个问题，一轮对话，不做多轮循环
2. **数据在 Obsidian**：利用 frontmatter，不建额外数据库
3. **评估靠规则**：简单关键词匹配，不调用 LLM 评估
4. **接收不生成上下文**：从 llm-wiki 接收上下文，自己只记录掌握度
5. **后台推送异步**：学习完成触发 llm-wiki，失败不影响当前学习

## 与其他 Skill 的关系

```
dispatch (路由) → llm-wiki (生成上下文) → dbs-learning (交互学习) → llm-wiki (后台推荐)
                                              ↓
                                        frontmatter 记录
                                              ↓
                                     dacapo-visualize (可视化)
```

### 数据流

1. **dispatch** 判断用户意图，调用 llm-wiki
2. **llm-wiki** 读取已学概念，生成学习上下文，传给 dbs-learning
3. **dbs-learning** 接收上下文，执行交互式学习，更新 frontmatter
4. **dbs-learning** 学习完成后触发 llm-wiki push（后台）
5. **llm-wiki** 根据新掌握的概念生成联想推荐

### 上下文格式

dispatch → llm-wiki → dbs-learning 的上下文传递格式：

```
LEARNING_CONTEXT:
- learned: <concept1>(<mastery>), <concept2>(<mastery>), ...
- connections: <concept1> → <concept2> → <concept3>
- angles: <推荐理解角度1>, <推荐理解角度2>
```

示例：
```
LEARNING_CONTEXT:
- learned: harness(0.8), context-engineering(0.7)
- connections: harness → agent → deployment
- angles: 从工具链角度理解, 对比传统编程模式
```

### 关键约定

1. **dbs-learning 不生成上下文**：只接收、解析、使用
2. **llm-wiki 是上下文源头**：负责分析概念关系和推荐
3. **frontmatter 是唯一数据源**：所有 skill 都读写同一份 frontmatter
4. **后台触发不阻塞**：llm-wiki 推荐失败不影响学习完成
