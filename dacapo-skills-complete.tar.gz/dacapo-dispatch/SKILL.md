---
name: interactive-learning-dispatch
description: 交互式学习统一入口，整合上下文并生成可执行提示词
version: 1.0.0
---

# interactive-learning-dispatch

**定位**：导航层——解析用户学习意图，整合上下文，生成可直接发送的提示词

---

## 核心价值

像 qiuzhi-dispatch 一样，这是学习系统的「智能入口」：

1. **定位**：找到用户想学的概念文件
2. **整合**：调用 llm-wiki 获取学习上下文（已学概念、推荐路径）
3. **生成**：输出可直接复制发送的提示词（包含已定位事实 + 学习建议）

**不执行**，只生成提示词交给用户。

---

## 路由规则

### 场景 1：开始学习某个概念（最常用）

**触发词**：「学习」「了解」「掌握」+ 概念名

**执行**：
```
/interactive-learning-dispatch <概念名>
```

**输出**：可直接发送的提示词

**示例**：

用户输入：「我想学习 harness 概念」

输出：

---

**推荐：`/dbs-learning harness`**

**选择理由**：你要开始学习特定概念——dbs-learning 通过简单问答评估掌握度，并将结果记录到概念文件的 frontmatter 中。

**已定位的事实**：
- 〔概念位置｜`~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`〕概念文件已存在
- 〔依赖关系｜同上 frontmatter〕该概念依赖：无（这是基础概念）
- 〔当前进度｜同上 frontmatter〕mastery 字段为 null（首次学习）
- 〔网络拓扑｜同上 frontmatter〕inDegree: 3（被 3 个其他概念依赖，是 Hub 概念）

**学习上下文（llm-wiki 提供）**：
- 这是首次学习，没有前置概念需要补
- 学完后推荐学习：agent（依赖 harness）、tool-use（依赖 harness）
- 这是 Hub 概念，掌握后能理解更多下游概念

**边界**：学习完成后 dbs-learning 自动触发 llm-wiki 后台推送（静默执行，写入 `.learning-progress/suggestions.json`），不打断当前学习流程。

---

**可直接发送的提示词**：

> 使用 `/dbs-learning harness`。
> 
> 我要学习「AI 内参」项目中的 harness 概念。
> 
> **学习上下文（llm-wiki 提供）**：
> - 这是首次学习，没有前置概念需要补
> - 这是 Hub 概念（被 3 个概念依赖），掌握后能理解更多下游概念
> - 学完后推荐学习：agent、tool-use
> 
> 请执行交互式学习流程：
> 1. 读取概念文件 `~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
> 2. 检查前置概念（无），可以直接开始学习
> 3. 通过 2 个问题评估我的当前掌握度
> 4. 根据评估结果给出学习建议
> 5. 将掌握度（mastery）和学习时间（lastStudied）写入概念文件的 frontmatter
> 6. 完成后触发 llm-wiki 后台推送（静默执行，不阻塞）
> 
> 已定位事实：
> - 概念文件存在：`~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
> - 包含定义、为什么重要、出现文章
> - 该概念被 3 个其他概念依赖（inDegree: 3）→ Hub 概念
> - 当前 mastery 字段为 null，这是首次学习

把上面引用块整段复制发送即可。发出去之后由 dbs-learning 接管交互式学习。

---

### 场景 2：查看学习进度

**触发词**：「进度」「学到哪了」「掌握情况」

**路由**：
```
/dbs-learning status
```

**输出示例**：
```markdown
## 📊 学习进度总览

**已掌握** (mastery ≥ 0.8)：
- ✅ context-engineering (85%)
- ✅ harness (82%)

**学习中** (0.5 ≤ mastery < 0.8)：
- ⚠️ agent (65%)
- ⚠️ tool-use (70%)

**初识** (0 < mastery < 0.5)：
- ❓ memory-management (30%)

**未学习** (mastery = null 或 0)：
- ⭕️ 其余 8 个概念

---

总计：13 个概念
- 已掌握：2 个 (15%)
- 学习中：2 个 (15%)
- 初识：1 个 (8%)
- 未学习：8 个 (62%)

**建议**：先巩固「agent」（当前 65% → 目标 80%）
```

---

### 场景 3：查看推荐概念

**触发词**：「推荐」「还能学什么」「相关概念」

**路由**：
```
/dbs-learning suggestions
```

**输出示例**：
```markdown
## 💡 为你推荐的概念（基于你学习的 harness）

### 同项目推荐

1. **agent** (相似度 85%)
   - 直接下游：harness 的典型应用
   - 📁 AI内参/concepts/agent.md
   - 当前掌握度：65% → 建议巩固到 80%

2. **tool-use** (相似度 80%)
   - 直接下游：agent 的核心能力
   - 📁 AI内参/concepts/tool-use.md
   - 当前掌握度：未学习

### 跨项目联想（草蛇灰线）

3. **skill-composition** (相似度 72%)
   - 来自「AI实战营-前沿速递」
   - 语义相似：都涉及 orchestration、coordination
   - 📁 AI实战营-前沿速递/concepts/skill-composition.md
   - 当前掌握度：未学习

---

📌 推荐有效期：7 天（至 2026-10-05）

使用 `/学习 <概念名>` 开始学习任一概念
```

---

### 场景 4：探索概念网络

**触发词**：「有哪些概念」「概念地图」「整体结构」

**路由**：
```
/dacapo-visualize
```

（如果 dacapo-visualize 可用，否则提示概念列表）

---

### 场景 5：发现跨项目关联

**触发词**：「发现」「关联」「联想」「草蛇灰线」

**路由**：
```
/llm-wiki discover
```

**输出示例**：
```markdown
## 💡 发现概念关联（跨项目）

扫描了 3 个项目，21 个概念，发现这些有趣的跨项目联想：

### 1. harness ↔ deepseek-harness
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 同名概念，不同实现视角
- 相似度：0.95
- 你已掌握 AI内参 的 harness (82%)，可以快速理解 deepseek-harness

### 2. agent ↔ skill-composition
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 关键词重叠：orchestration, coordination, workflow
- 相似度：0.72
- 你已学习 agent (65%)，可以类比理解 skill-composition

### 3. context-engineering ↔ prompt-design
- 📁 AI内参 ↔ AI实战营-从Demo到产品
- 🔗 来源重叠：都在「内参 #3」中出现
- 相似度：0.68
- 你已掌握 context-engineering (85%)，可以扩展到 prompt-design
```

---

## 执行流程

### Step 1: 定位概念文件

```python
def locate_concept(concept_name, user_input):
    """
    定位概念文件的完整路径
    """
    # 1. 读取真源导航
    source_of_truth = read_file("~/Documents/dacapo-学习仓库/SOURCE_OF_TRUTH.md")
    
    # 2. 扫描所有项目的 concepts/ 目录
    projects = scan_projects(source_of_truth)
    
    # 3. 模糊匹配概念名
    matches = []
    for project in projects:
        concept_files = list_files(f"{project}/concepts/")
        for file in concept_files:
            if fuzzy_match(concept_name, file):
                matches.append({
                    "path": f"{project}/concepts/{file}",
                    "project": project
                })
    
    # 4. 返回匹配结果
    if len(matches) == 0:
        return None, "概念不存在"
    elif len(matches) == 1:
        return matches[0], None
    else:
        return matches, "多个匹配，请选择"
```

### Step 2: 读取概念数据

```python
def read_concept_data(concept_path):
    """
    读取概念文件的 frontmatter 和正文
    """
    content = read_file(concept_path)
    
    # 解析 frontmatter
    frontmatter = parse_yaml_frontmatter(content)
    
    # 提取关键字段
    return {
        "name": frontmatter.get("name", extract_from_filename(concept_path)),
        "dependencies": frontmatter.get("dependencies", []),
        "inDegree": frontmatter.get("inDegree", 0),
        "mastery": frontmatter.get("mastery", None),
        "lastStudied": frontmatter.get("lastStudied", None),
        "firstAppearance": frontmatter.get("firstAppearance", None),
        "definition": extract_definition(content),
        "why_important": extract_why_important(content)
    }
```

### Step 3: 调用 llm-wiki 获取上下文

```python
def get_learning_context(concept_name, concept_data):
    """
    调用 llm-wiki 获取学习上下文
    """
    try:
        # 调用 llm-wiki context 接口
        context = call_skill("llm-wiki", "context", {
            "concept": concept_name,
            "project": concept_data["project"]
        })
        
        return {
            "learnedConcepts": context.get("learnedConcepts", []),
            "suggestedPath": context.get("suggestedPath", []),
            "crossProjectLinks": context.get("crossProjectLinks", [])
        }
    except Exception as e:
        # 降级：llm-wiki 失败不阻塞主流程
        log_error(f"llm-wiki 调用失败: {e}")
        return {
            "learnedConcepts": [],
            "suggestedPath": [],
            "crossProjectLinks": []
        }
```

### Step 4: 生成可执行提示词

```python
def generate_prompt(concept_name, concept_data, learning_context):
    """
    生成可直接发送的提示词
    """
    # 构建已定位事实
    located_facts = f"""
已定位事实：
- 概念文件存在：`{concept_data['path']}`
- 包含定义、为什么重要、出现文章
- 该概念被 {concept_data['inDegree']} 个其他概念依赖{' → Hub 概念' if concept_data['inDegree'] >= 3 else ''}
- 当前 mastery 字段为 {concept_data['mastery'] or 'null'}，{'这是首次学习' if not concept_data['mastery'] else f'上次掌握度 {concept_data["mastery"]*100:.0f}%'}
"""
    
    # 构建学习上下文
    context_text = build_context_text(learning_context, concept_data)
    
    # 构建依赖检查
    dependency_check = build_dependency_check(concept_data)
    
    # 组装完整提示词
    prompt = f"""
使用 `/dbs-learning {concept_name}`。

我要学习「{concept_data['project']}」项目中的 {concept_name} 概念。

**学习上下文（llm-wiki 提供）**：
{context_text}

请执行交互式学习流程：
1. 读取概念文件 `{concept_data['path']}`
2. 检查前置概念{dependency_check}
3. 通过 2 个问题评估我的当前掌握度
4. 根据评估结果给出学习建议
5. 将掌握度（mastery）和学习时间（lastStudied）写入概念文件的 frontmatter
6. 完成后触发 llm-wiki 后台推送（静默执行，不阻塞）

{located_facts}
"""
    
    return prompt
```

---

## 关键实现细节

### 1. 模糊匹配逻辑

```python
def fuzzy_match(query, filename):
    """
    支持以下匹配方式：
    - 精确匹配：harness == harness.md
    - 部分匹配：context == context-engineering.md
    - 中文匹配：上下文工程 == context-engineering.md（如果文件内有中文定义）
    """
    query_lower = query.lower().replace(" ", "-")
    filename_lower = filename.lower().replace(".md", "")
    
    # 精确匹配
    if query_lower == filename_lower:
        return True
    
    # 部分匹配
    if query_lower in filename_lower or filename_lower in query_lower:
        return True
    
    # 中文匹配（需要读取文件内的中文定义）
    # 简化：只在文件名匹配失败时才读取文件
    return False
```

### 2. 依赖检查逻辑

```python
def build_dependency_check(concept_data):
    """
    构建依赖概念检查文本
    """
    dependencies = concept_data.get("dependencies", [])
    
    if not dependencies:
        return "（无），可以直接开始学习"
    
    # 读取依赖概念的掌握度
    dep_status = []
    for dep in dependencies:
        dep_data = read_concept_data(find_concept_file(dep))
        mastery = dep_data.get("mastery", 0) or 0
        
        if mastery >= 0.8:
            dep_status.append(f"{dep} ✅ 已掌握 ({mastery*100:.0f}%)")
        elif mastery >= 0.5:
            dep_status.append(f"{dep} ⚠️ 需要巩固 ({mastery*100:.0f}%)")
        else:
            dep_status.append(f"{dep} ❌ 未掌握 ({mastery*100:.0f}%)")
    
    return "：\n   - " + "\n   - ".join(dep_status)
```

### 3. 学习上下文构建

```python
def build_context_text(learning_context, concept_data):
    """
    构建学习上下文文本（llm-wiki 提供的信息）
    """
    lines = []
    
    # 1. 已学概念（复利效应）
    learned = learning_context.get("learnedConcepts", [])
    if learned:
        for concept in learned:
            lines.append(f"- 你之前学过 {concept['name']}（掌握度 {concept['mastery']*100:.0f}%），可以用来理解 {concept_data['name']}")
    else:
        lines.append("- 这是首次学习，没有前置概念需要补")
    
    # 2. Hub 概念提示
    if concept_data.get("inDegree", 0) >= 3:
        lines.append(f"- 这是 Hub 概念（被 {concept_data['inDegree']} 个概念依赖），掌握后能理解更多下游概念")
    
    # 3. 推荐路径
    suggested = learning_context.get("suggestedPath", [])
    if suggested:
        lines.append(f"- 学完后推荐学习：{', '.join(suggested)}")
    
    # 4. 跨项目联想
    cross_links = learning_context.get("crossProjectLinks", [])
    if cross_links:
        lines.append(f"- 跨项目联想：{cross_links[0]['concept']}（{cross_links[0]['project']}，相似度 {cross_links[0]['similarity']*100:.0f}%）")
    
    return "\n".join(lines)
```

---

## 错误处理

### 概念不存在

```markdown
❌ **找不到概念「XYZ」**

可用概念有（共 13 个）：

**AI内参**：
- harness
- context-engineering
- agent
- tool-use
- memory-management
- ...

**AI实战营-前沿速递**：
- skill-composition
- deepseek-harness
- ...

请使用 `/学习 <概念名>` 重新选择。
```

### 多个匹配

```markdown
⚠️ **找到多个匹配「context」的概念**

1. context-engineering（AI内参）
2. context-design（AI实战营-从Demo到产品）

请明确指定：
- `/学习 context-engineering`
- `/学习 context-design`
```

### 依赖未满足

```markdown
⚠️ **建议先学习前置概念**

你要学习「agent」，但它依赖：
- harness（当前掌握度 30% ⚠️）
- context-engineering（当前掌握度 0% ❌）

建议学习顺序：
1. /学习 context-engineering
2. /学习 harness
3. /学习 agent

是否继续学习 agent？（可能较难理解）
```

### SOURCE_OF_TRUTH.md 不存在

```markdown
⚠️ **找不到学习仓库真源导航**

正在扫描 `~/Documents/dacapo-学习仓库/` ...

发现 2 个项目：
- AI内参（13 个概念）
- AI实战营-前沿速递（8 个概念）

已自动生成 SOURCE_OF_TRUTH.md ✓

继续执行...
```

---

## 输出格式规范

### 提示词结构

所有生成的提示词遵循统一结构：

```
1. 命令行（可复制）
   使用 `/dbs-learning <concept>`。

2. 任务描述
   我要学习「项目名」中的 <concept> 概念。

3. 学习上下文（llm-wiki 提供）
   - 已学概念
   - Hub 概念提示
   - 推荐路径
   - 跨项目联想

4. 执行流程（6 步）
   1. 读取文件
   2. 检查依赖
   3. 评估掌握度
   4. 给出建议
   5. 更新 frontmatter
   6. 触发后台推送

5. 已定位事实
   - 文件路径
   - inDegree
   - 当前 mastery
```

### 边界说明

每个提示词末尾附加：

```markdown
**边界**：学习完成后 dbs-learning 自动触发 llm-wiki 后台推送（静默执行，写入 `.learning-progress/suggestions.json`），不打断当前学习流程。

把上面引用块整段复制发送即可。发出去之后由 dbs-learning 接管交互式学习。
```

---

## 与其他 Skill 的协作

### dispatch → llm-wiki（同步调用）

```python
# dispatch 调用 llm-wiki 获取上下文
context = call_skill("llm-wiki", "context", {
    "concept": "harness",
    "project": "AI内参"
})

# llm-wiki 返回
{
    "learnedConcepts": [...],
    "suggestedPath": [...],
    "crossProjectLinks": [...]
}
```

### dispatch → dbs-learning（通过提示词）

```python
# dispatch 不直接调用 dbs-learning
# 而是生成提示词，由用户复制发送

prompt = generate_prompt(...)
print(prompt)  # 输出给用户

# 用户复制粘贴 prompt，发送给 AI
# AI 解析 prompt，调用 dbs-learning
```

### dbs-learning → llm-wiki（异步触发）

```python
# dbs-learning 学习完成后
update_frontmatter(concept, mastery=0.65)

# 后台触发 llm-wiki（不等待结果）
background_task(call_skill, "llm-wiki", "push", {
    "concept": concept,
    "mastery": 0.65
})
```

---

## 测试用例

### 测试 1：首次学习基础概念

**输入**：
```
/学习 harness
```

**预期输出**：
- ✅ 定位到 `AI内参/concepts/harness.md`
- ✅ frontmatter.mastery 为 null
- ✅ frontmatter.dependencies 为空
- ✅ 学习上下文：「这是首次学习，没有前置概念需要补」
- ✅ 提示词可复制

---

### 测试 2：学习有依赖的概念

**输入**：
```
/学习 agent
```

**预期输出**：
- ✅ 定位到 `AI内参/concepts/agent.md`
- ✅ frontmatter.dependencies: [harness, context-engineering]
- ✅ 检查依赖掌握度：
  - harness: 82% ✅
  - context-engineering: 85% ✅
- ✅ 学习上下文：「你之前学过 harness (82%)，agent 是在 harness 之上的执行单元」
- ✅ 提示词可复制

---

### 测试 3：概念不存在

**输入**：
```
/学习 xyz
```

**预期输出**：
- ✅ 错误提示：「找不到概念 xyz」
- ✅ 列出可用概念列表
- ✅ 建议用户重新选择

---

### 测试 4：查看进度

**输入**：
```
/进度
```

**预期输出**：
- ✅ 扫描所有概念文件
- ✅ 统计掌握度分布
- ✅ 给出学习建议

---

### 测试 5：查看推荐

**输入**：
```
/推荐
```

**预期输出**：
- ✅ 读取 `.learning-progress/suggestions.json`
- ✅ 检查是否过期
- ✅ 显示同项目推荐 + 跨项目联想

---

## 性能要求

- **定位概念**：< 1 秒（扫描 100 个文件）
- **读取概念数据**：< 0.5 秒（单个文件）
- **调用 llm-wiki**：< 3 秒（首次）、< 0.5 秒（缓存命中）
- **生成提示词**：< 0.5 秒

**总计**：< 5 秒完成整个 dispatch 流程

---

## 扩展与优化

### 未来可支持

1. **智能推荐学习顺序**
   - 基于拓扑排序 + 掌握度
   - 自动规划最优学习路径

2. **多人协同学习**
   - 共享掌握度数据
   - 查看其他学习者的路径

3. **学习分析报告**
   - 每周/每月学习总结
   - 掌握度增长曲线

4. **语音学习模式**
   - 语音提问，语音回答
   - 自动评估并更新掌握度

---

## 约定与限制

### dispatch 只负责

- ✅ 定位概念文件
- ✅ 读取 frontmatter
- ✅ 调用 llm-wiki 获取上下文
- ✅ 生成可执行提示词

### dispatch 不负责

- ❌ 评估掌握度（由 dbs-learning 负责）
- ❌ 更新 frontmatter（由 dbs-learning 负责）
- ❌ 生成推荐（由 llm-wiki 负责）
- ❌ 可视化概念网络（由 dacapo-visualize 负责）

---

## 总结

### 核心设计

**dispatch = 定位 + 整合 + 生成**

1. **定位**：找到概念文件，读取 frontmatter
2. **整合**：调用 llm-wiki，获取学习上下文
3. **生成**：输出可直接发送的提示词

### 用户体验

```
用户：「我想学习 harness」
  ↓
dispatch：生成提示词（3 秒内）
  ↓
用户：复制粘贴，发送
  ↓
dbs-learning：接管交互式学习
```

### 开发者体验

```python
# 调用 dispatch
result = call_skill("interactive-learning-dispatch", "harness")

# 返回提示词（字符串）
print(result)  # 用户可直接复制

# dispatch 不执行任何学习逻辑
# 只是「智能路由 + 上下文整合」
```

---

**设计哲学**：

> dispatch 是「导航员」，不是「执行者」。
> 
> 它的任务是告诉用户「该去哪里（哪个 Skill）、带上什么（上下文）、怎么走（提示词）」。
> 
> 具体的学习、评估、推荐，由专门的 Skill 负责。
