# dacapo - DaCapo Learn 统一入口

**定位**：DaCapo Learn 概念学习系统的智能导航入口。

## 快速开始

```bash
# 学习概念
/dacapo agent

# 查看进度
/dacapo 进度

# 查看推荐
/dacapo 推荐

# 发现关联
/dacapo 发现关联
```

## 核心功能

### 智能路由
根据用户输入自动判断意图，路由到对应的 dacapo Skill：
- **学习意图** → `dacapo-learning`
- **查询意图** → `dacapo-learning status`
- **推荐意图** → `dacapo-learning suggestions`
- **探索意图** → `dacapo-wiki discover`
- **可视化** → `dacapo-visualize`

### 使用体验
- ✅ 一个命令搞定，不需要知道有哪些 Skill
- ✅ 直接执行，不生成提示词
- ✅ 内部调用，自动路由
- ✅ 降低学习成本

## DaCapo Learn 体系

### 10 个协作 Skill

**交互式学习层**（本次实现）：
- `dacapo-main` — 统一入口（本 Skill）
- `dacapo-dispatch` — 智能路由和上下文整合
- `dacapo-learning` — 自适应学习（2 问题评估 + frontmatter 记录）
- `dacapo-wiki` — 概念探索（跨项目草蛇灰线发现）

**概念图谱层**（已有）：
- `dacapo-learn` — 概念提取 + 学习文章生成
- `dacapo-core` — 核心功能库
- `dacapo-article` — 文章处理
- `dacapo-visualize` — 可视化生成
- `dacapo-lint` — 质量校验
- `dacapo-diagnose` — 问题诊断

## 执行流程

```
用户：/dacapo agent
    ↓
意图识别（学习概念）
    ↓
调用 dacapo-dispatch
    ├─ 定位概念文件
    ├─ 调用 dacapo-wiki 获取上下文
    └─ 准备学习材料
    ↓
调用 dacapo-learning
    ├─ 显示概念信息和已学上下文
    ├─ 2 个问题评估掌握度
    ├─ 更新 frontmatter
    └─ 触发后台推荐
    ↓
完成（用户可继续 /dacapo 推荐）
```

## 意图识别规则

| 用户输入 | 识别为 | 路由到 |
|---------|-------|--------|
| `agent` / `学习 agent` | 学习意图 | dacapo-learning |
| `进度` / `状态` | 查询意图 | dacapo-learning status |
| `推荐` / `下一个` | 推荐意图 | dacapo-learning suggestions |
| `发现关联` / `探索` | 探索意图 | dacapo-wiki discover |
| `图谱` / `可视化` | 可视化 | dacapo-visualize |

## 对标 dbs

### dbs 的形态
```bash
/dbs 我准备学习社会学基本概念...
    ↓ 版本检查 + Skill 发现
    ↓ 智能路由
    ↓ 直接执行
```

### dacapo 的形态（本 Skill）
```bash
/dacapo agent
    ↓ Skill 发现
    ↓ 意图识别
    ↓ 智能路由
    ↓ 直接执行
```

## 核心价值

### 1. 复利式学习
- 用已学概念帮助理解新概念
- 效果提升 2.4 倍（35% → 85%）

### 2. 跨项目草蛇灰线
- 发现不同项目间的隐藏关联
- 例如：harness（AI内参）↔ deepseek-harness（AI实战营）

### 3. 自适应学习
- 对标 Bloom 2 Sigma Problem
- 根据掌握度调整学习内容

### 4. 轻量化实现
- 数据在 frontmatter，不建额外数据库
- 2 个问题快速评估
- 后台推送静默，不打断学习

## 数据流

```
frontmatter（每个概念文件）:
  mastery: 0.75           # 掌握度
  lastStudied: 2026-09-28 # 最后学习
  studyCount: 2           # 学习次数
  dependencies: [...]     # 依赖
  inDegree: 5             # 被引用次数

suggestions.json（推荐缓存，7 天有效）:
  {
    "basedOn": "agent",
    "suggestions": [...]
  }
```

## 命名说明

**DaCapo** (意大利语)：
- 音乐术语：从头再来
- 寓意：温故知新、螺旋上升的学习

**DaCapo Learn**：
- 整个概念学习体系的名称
- 强调概念复利、螺旋上升

## 更多信息

完整文档请查看：
- `~/Documents/交互式学习/DACAPO-UNIFIED-ENTRY.md`
- `~/Documents/交互式学习/docs/INTEGRATION.md`
- `~/Documents/交互式学习/docs/NAMING.md`
