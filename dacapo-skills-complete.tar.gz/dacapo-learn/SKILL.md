---
name: dacapo-learn
description: 读原始文章，提取概念，生成 Obsidian 知识库（两阶段生成）
version: 2.0-two-phase
---

# dacapo-learn：Obsidian 原生交互式学习（两阶段版）

**新特性**：分离自由理解和结构化转换，提升输出完整性和质量。

---

## 核心变更

### v2.0 两阶段架构

**Phase 1：自由理解**
- AI 专注理解材料、提取概念、建立关系
- 输出 JSON 格式（不受 Obsidian 格式约束）
- JSON Schema 约束确保结构完整

**Phase 2：结构化转换**
- 读取 Phase 1 的 JSON
- 机械转换为 Obsidian 格式（.md 文件 + frontmatter + wikilink）
- 生成 Mermaid 图和学习文章

**优势**：
1. ✅ 充分发挥 AI 理解能力（Phase 1 无格式负担）
2. ✅ 确保输出完整性（Phase 2 强制生成所有组件）
3. ✅ 可调试（检查 Phase 1 JSON 质量）
4. ✅ 关系类型更丰富（20 种语义标签）

---

## 核心任务

**输入**：原始文章路径（Markdown）

**输出**：
1. 概念页面（`concepts/concept-id.md`）：每个概念一个独立页面
2. 学习文章（`articles/NN-title.md`）：使用 `[[concept]]` 双向链接
3. **Mermaid 图谱**（`graph/concept-network.md`）：独立的可视化网络图
4. **中间 JSON**（`.tmp/phase1-output.json`）：Phase 1 输出（可调试）

**核心价值**：让用户在 Obsidian 中看到概念网络如何随着学习成长，利用原生双向链接和图谱功能。

---

## 工作流程

### Step 1：读取上下文

1. 读取 `purpose.md`（学习目标）
2. 扫描 `concepts/` 目录，读取所有已有概念的 frontmatter（获取 inDegree）
3. 读取原始文章（用户指定路径）
4. 确定文章编号（扫描 `articles/` 目录，自动递增）

### Step 2：Phase 1 - 自由理解（输出 JSON）

**任务**：提取概念、建立关系、撰写学习文章，输出为 JSON。

**JSON 输出格式**：

```json
{
  "concepts": [
    {
      "id": "hooks",
      "name": "Hooks",
      "definition": "React 16.8 引入的新特性，允许在函数组件中使用 state 和其他 React 特性",
      "importance": "彻底改变了 React 组件的编写方式，让函数组件拥有了 Class 组件的能力",
      "prerequisites": ["function-component"],
      "relationshipLabels": {
        "function-component": "增强"
      },
      "examples": [
        "const [count, setCount] = useState(0);"
      ],
      "isNew": true
    }
  ],
  "hubConcepts": ["hooks"],
  "insights": [
    "Hooks 让函数组件完全取代 Class 组件成为可能",
    "useState 的函数式更新可以避免闭包陷阱"
  ],
  "learningArticle": {
    "title": "React Hooks 使用指南",
    "sections": [
      {
        "heading": "什么是 Hooks",
        "content": "{{hooks}} 是 React 16.8 引入的新特性。通过 {{use-state}} 和 {{use-effect}} 等 Hook，{{function-component}} 可以拥有状态和副作用管理能力。"
      }
    ],
    "introducedConcepts": ["hooks", "use-state", "use-effect"],
    "nextSteps": "下一步学习 useEffect 的依赖数组和清理函数"
  },
  "metadata": {
    "sourceFile": "raw-sources/react-hooks.md",
    "articleNumber": 5
  }
}
```

**关键要求**：
1. **概念 ID**：使用 kebab-case（如 `use-state`、`dependency-array`）
2. **关系标签**：使用语义化标签（20 种类型，见下文）
3. **学习文章占位符**：在 content 中用 `{{concept-id}}` 标记概念引用位置
4. **完整性**：必须包含 `learningArticle`（不能缺失）

**关系类型（20 种）**：
- **技术关系**：依赖、实现、增强、替代、组合
- **逻辑关系**：导致、解决、避免、优化
- **层次关系**：属于、包含、抽象、具体化
- **时序关系**：先于、后于、触发
- **对比关系**：对比、权衡、互补
- **应用关系**：应用于、适用场景、控制

**输出**：
- 创建 `.tmp/` 目录（如果不存在）
- 将 JSON 保存到 `.tmp/phase1-output.json`
- 显示 JSON 内容供用户检查

### Step 3：验证 JSON 完整性

**关键检查项**：
1. `concepts` 数组非空
2. 每个概念有必填字段：`id`、`name`、`definition`、`importance`、`prerequisites`
3. **`learningArticle` 存在**且有 `title`、`sections`、`introducedConcepts`
4. 所有 `prerequisites` 引用的概念 ID 都在 `concepts` 数组中
5. 学习文章中的占位符 `{{concept-id}}` 都对应存在的概念

**如果验证失败**：
- 报错并显示具体问题
- 停止执行

### Step 4：Phase 2 - 结构化转换

**输入**：`.tmp/phase1-output.json`

**任务**：将 JSON 转换为 Obsidian 文件

#### 4.1 生成/更新概念页面

对 JSON 中的每个概念：

**新概念**（`isNew: true` 且 `concepts/` 目录中不存在）：
1. 创建 `concepts/{id}.md`
2. frontmatter：
   ```yaml
   ---
   tags: concept
   hub: false
   inDegree: 0
   mastery: 20
   firstAppearance: "[[{article-name}]]"
   ---
   ```
3. 正文：
   ```markdown
   # {name}
   
   ## 定义
   
   {definition}
   
   ## 为什么重要
   
   {importance}
   
   ## 前置概念
   
   {prerequisites 转换为 [[id]] 列表，无则写"无"}
   
   ## 示例
   
   {examples（如果有）}
   ```

**已有概念被引用**：
1. 读取 `concepts/{id}.md` 的 frontmatter
2. `inDegree` +1
3. 更新 `mastery`
4. 如果 `inDegree >= 3` 且 `hub: false`，更新为 `hub: true`

**计算 inDegree**：
- 对每个概念，统计有多少其他概念将其列为 prerequisite
- 更新所有概念的 `inDegree` 字段

**掌握度更新规则**：
- 新概念：20（普通）或 30（有示例）
- Hub 概念（inDegree >= 3）：40
- 每增加 1 个引用：+5（上限 70）

#### 4.2 生成学习文章

1. 读取 JSON 中的 `learningArticle`
2. 创建 `articles/{N}-{title-slug}.md`（N 从 metadata.articleNumber 获取）
3. 生成内容：

```markdown
# 第 {N} 篇：{title}

## 📊 前置概念检查

{从 introducedConcepts 提取，列出每个概念的掌握度}

## {sections[0].heading}

{sections[0].content，将 {{concept-id}} 替换为 [[concept-id]]}

## {sections[1].heading}

{sections[1].content，将 {{concept-id}} 替换为 [[concept-id]]}

...

## 本文引入的概念

{introducedConcepts 转换为 [[id]] 列表}

## 下一步

{nextSteps（如果有）}
```

**关键转换**：
- 占位符 `{{concept-id}}` → wikilink `[[concept-id]]`
- 前置概念掌握度从 `concepts/{id}.md` 的 frontmatter 读取

#### 4.3 生成 Mermaid 概念网络图

1. 扫描所有 `concepts/*.md`，读取 frontmatter 和前置概念
2. 生成 `graph/concept-network.md`

**简化逻辑**（避免认知负担）：
- 如果概念数 ≤ 15：生成单个完整图谱
- 如果概念数 > 15：生成简化版（Top 15）+ 完整版

**简化版内容**：

```markdown
# 概念网络图谱

## 统计信息

- 总概念数：{count}
- Hub 概念：{hub_count}（inDegree >= 3）
- 平均掌握度：{avg_mastery}%

## Hub 概念列表

| 概念 | inDegree | 掌握度 |
|------|----------|--------|
| [[hooks]] | 7 | 40% |

## 概念网络

```mermaid
graph TD
    %% Hub 概念用双框标记
    hooks[["hooks<br/>inDegree: 7"]]
    
    %% 普通概念
    use-state["use-state<br/>inDegree: 2"]
    function-component["function-component<br/>inDegree: 1"]
    
    %% 概念依赖关系（带语义标签）
    use-state -->|"实现"| hooks
    hooks -->|"增强"| function-component
    
    %% 样式
    classDef hub fill:#ff6b6b,stroke:#c92a2a,stroke-width:3px
    classDef normal fill:#4ecdc4,stroke:#0891b2,stroke-width:2px
    
    class hooks hub
    class use-state,function-component normal
```
\```
```

**关键特性**：
- 使用 `relationshipLabels` 作为边标签（如 `|"增强"|`）
- Hub 概念用双框 `[[ ]]`
- 视觉区分（红色 Hub，蓝色普通）

### Step 5：清理与输出

1. 检查所有文件是否生成成功
2. 输出摘要：

```
✅ 已处理文章：{article-name}
📝 新增概念：{count} 个
🔗 更新引用：{count} 次
⭐ 新 Hub 概念：{list}（如有）
📊 Mermaid 图谱：graph/concept-network.md
📂 可在 Obsidian 中打开该目录查看双向链接

🔍 Phase 1 JSON：.tmp/phase1-output.json
```

---

## 边界与约束

**本 Skill 负责**：
- Phase 1：从原始文章提取概念、关系、洞察（JSON）
- Phase 2：生成/更新概念页面（`concepts/*.md`）
- Phase 2：生成学习文章（`articles/*.md`）
- Phase 2：生成 Mermaid 概念网络图（`graph/concept-network.md`）
- 维护双向链接和 frontmatter 元数据

**本 Skill 不负责**：
- 交互式诊断
- 健康检查与提醒
- 查漏补缺与复习计划

---

## 停止条件

**成功完成**：
- Phase 1 JSON 已生成
- 所有新概念已生成独立页面
- 所有引用关系已建立（双向链接）
- **学习文章已生成**（不能缺失）
- 所有 inDegree 已更新
- Hub 概念已标记
- Mermaid 图已生成

**失败情况**：
- Phase 1 JSON 验证失败 → 报错，显示具体问题
- 原始文章路径不存在 → 报错并列出 `raw-sources/` 可用文件

---

## 错误处理

1. **Phase 1 JSON 缺少 learningArticle**：
   - 报错："`learningArticle` 字段缺失，必须生成学习文章"
   - 停止执行

2. **概念引用不存在**：
   - 检查占位符 `{{concept-id}}` 是否在 `concepts` 数组中
   - 检查 `prerequisites` 是否引用了不存在的概念

3. **文件写入失败**：
   - 自动创建缺失的目录（`concepts/`, `articles/`, `graph/`, `.tmp/`）

---

## 示例执行

**输入**：
```
raw-sources/react-hooks.md
```

**Phase 1 输出**：
```json
{
  "concepts": [...13 个概念...],
  "hubConcepts": ["hooks"],
  "insights": [...3 条洞察...],
  "learningArticle": {
    "title": "React Hooks 使用指南",
    "sections": [...5 节...],
    "introducedConcepts": ["hooks", "use-state", "use-effect"]
  }
}
```

**Phase 2 转换**：
1. 生成 `concepts/hooks.md`、`concepts/use-state.md` 等 13 个文件
2. 生成 `articles/05-react-hooks.md`（**确保生成**）
3. 更新 `graph/concept-network.md`

**输出**：
```
✅ 已处理文章：React Hooks 使用指南
📝 新增概念：13 个（hooks, use-state, use-effect...）
🔗 更新引用：7 次
⭐ 新 Hub 概念：hooks（inDegree: 7）
📊 Mermaid 图谱：graph/concept-network.md
📂 可在 Obsidian 中打开该目录查看 Graph View

🔍 Phase 1 JSON：.tmp/phase1-output.json
```

---

## 语言

- 用户用中文就用中文回复
- 中文回复遵循《中文文案排版指北》
