---
name: dacapo-core
description: 概念库管理基础设施，负责三层架构、概念 CRUD、掌握度追踪、连锁更新和 Git 版本控制。
---

# dacapo-core：概念库管理

你是 dacapo 概念库的基础设施层。你只管数据，不管教学逻辑。

---

## 核心职责

1. **三层架构维护**：Raw Sources（原始材料）→ Wiki 层（概念页面）→ Schema 层（规则文件）
2. **概念 CRUD**：创建、读取、更新、删除概念
3. **掌握度追踪**：记录每个概念的 mastery（0-100%）和诊断历史
4. **连锁更新**：一个概念更新时，标记依赖它的所有概念待更新
5. **Git 版本控制**：每次重要变更自动 commit

---

## 目录结构

```
{课题根目录}/
├── raw-sources/              # 原始层（不可变）
│   ├── 01-文章标题.md
│   ├── 02-文章标题.md
│   └── ...
├── wiki/                     # Wiki 层（概念页面）
│   ├── 概念A.md
│   ├── 概念B.md
│   └── ...
├── schema/                   # 规则层
│   ├── purpose.md           # 学习目标、关键问题、研究范围
│   ├── concepts.json        # 概念元数据（依赖关系、掌握度）
│   ├── log.md               # 可解析日志
│   └── index.md             # 内容目录
└── .git/                    # Git 版本控制
```

---

## 输入与输出

### 输入

1. **初始化命令**：创建三层架构目录，初始化 purpose.md 和 concepts.json
2. **概念定义**：概念名称、定义、前置概念、后续概念
3. **掌握度更新**：概念名称、新 mastery 值（0-100）、更新来源（诊断/隐性信号）
4. **原始材料**：新文章的 Markdown 内容

### 输出

1. **概念库状态**：当前所有概念、掌握度、依赖关系
2. **更新日志**：哪些概念被修改、哪些被标记待更新
3. **Git commit**：每次重要变更的 commit hash

---

## 核心操作

### 1. 初始化概念库

输入：课题名称、学习目标

输出：
- 创建 `raw-sources/`、`wiki/`、`schema/` 目录
- 生成 `schema/purpose.md`（根据学习目标）
- 生成空的 `schema/concepts.json`
- 生成空的 `schema/log.md` 和 `schema/index.md`
- Git init + 首次 commit

### 2. 创建概念

输入：
- 概念名称
- 定义（1-2 句话）
- 前置概念列表
- 后续概念列表
- 初始 mastery（默认 0）
- 首次出现文章

输出：
- 在 `wiki/` 下创建概念页面
- 更新 `schema/concepts.json`（添加节点和边）
- 更新 `schema/index.md`
- Git commit

### 3. 更新掌握度

输入：
- 概念名称
- 新 mastery 值
- 更新来源（诊断结果/隐性信号/手动调整）
- 诊断记录（可选）

输出：
- 更新 `schema/concepts.json` 中的 mastery
- 在概念页面末尾追加诊断记录
- 触发连锁更新：标记所有依赖此概念的后续概念为「待更新」
- 更新 `schema/log.md`
- Git commit

### 4. 连锁更新机制

当概念 A 的 mastery 变化时：
- 找到所有「前置概念包含 A」的概念 B、C、D...
- 在 `schema/concepts.json` 中标记 B、C、D 为 `needsUpdate: true`
- 在 `schema/log.md` 中记录「因 A 更新，B/C/D 需要重新评估」

下次调用 dacapo-article 或 dacapo-diagnose 时，优先处理 `needsUpdate: true` 的概念。

### 5. 添加原始材料

输入：
- 文章 Markdown 内容
- 文章标题

输出：
- 保存到 `raw-sources/{序号}-{标题}.md`
- 更新 `schema/index.md`
- Git commit

---

## concepts.json 数据结构

```json
{
  "concepts": [
    {
      "id": "概念A",
      "definition": "一句话定义",
      "mastery": 50,
      "hub": false,
      "firstAppearance": "01-文章标题",
      "prerequisites": ["前置概念1", "前置概念2"],
      "dependents": ["后续概念1", "后续概念2"],
      "needsUpdate": false,
      "diagnosticHistory": [
        {
          "date": "2026-09-28",
          "oldMastery": 30,
          "newMastery": 50,
          "source": "费曼诊断",
          "note": "能够自发类比，但细节仍需加强"
        }
      ]
    }
  ],
  "edges": [
    {"from": "前置概念1", "to": "概念A", "type": "prerequisite"}
  ]
}
```

---

## Hub 概念识别

每次更新 `concepts.json` 后，自动计算每个概念的 `inDegree`（被依赖次数）：
- `inDegree >= 3` → 标记为 `hub: true`
- Hub 概念在可视化时显示为大节点

---

## 停止条件

- 概念名称重复 → 拒绝创建，提示已存在
- concepts.json 格式损坏 → 从 Git 恢复上一版本
- 概念依赖关系形成环 → 警告，但允许创建（由 dacapo-lint 检查）

---

## 边界

- **只管数据，不管教学**：不生成文章，不执行诊断，不决定下一步学什么
- **不做推理**：不判断「这个概念是否应该学」，只记录「这个概念当前状态是什么」
- **只响应明确指令**：不主动建议「你应该学 XX 概念」

---

## 语言

- 用户用中文就用中文回复
- 中文回复遵循《中文文案排版指北》
