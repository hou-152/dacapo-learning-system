---
name: dacapo-learn
description: 读原始文章，提取概念，生成 Obsidian 知识库（原生图谱）
---

# dacapo-learn：Obsidian 原生交互式学习

一个 Skill 完成从原始文章到 Obsidian 概念网络的完整流程。

---

## 核心任务

**输入**：原始文章路径（Markdown）

**输出**：
1. 概念页面（`concepts/concept-id.md`）：每个概念一个独立页面
2. 学习文章（`articles/NN-title.md`）：使用 `[[concept]]` 双向链接
3. **Mermaid 图谱**（`graph/concept-network.md`）：独立的可视化网络图
4. Obsidian Graph View 自动生成可视化网络（可选）

**核心价值**：让用户在 Obsidian 中看到概念网络如何随着学习成长，利用原生双向链接和图谱功能。

---

## 架构设计

### Obsidian Vault 结构

```
vault/
├── concepts/              # 概念库（每个概念一个文件）
│   ├── harness.md
│   ├── context-engineering.md
│   └── durable-execution.md
├── articles/              # 学习文章（引用概念时用 [[concept-id]]）
│   ├── 01-harness-engineering.md
│   └── 02-agent-equation.md
├── raw-sources/          # 原始材料
└── purpose.md            # 学习目标
```

### 概念页面格式

```markdown
---
tags: concept
hub: false
inDegree: 2
mastery: 20
firstAppearance: "[[01-harness-engineering]]"
---

# Harness（把 agent 管住的那套工装）

## 定义

If you're not the model, you're the harness。除模型本身之外的每一段代码、配置和执行逻辑...

## 为什么重要

裸模型不是 agent。模型需要 harness 提供四样东西才能成为 agent...

## 前置概念

无

## 被以下文章引用

（Obsidian 自动生成反向链接）
```

### 学习文章格式

```markdown
# 第 01 篇：Harness 工程基础

## 📊 前置概念检查

- [[harness]] — 待学习
- [[context-engineering]] — 待学习

## 正文

今天学习 [[harness]] 的基础概念。[[harness]] 是 [[agent]] 的必要组成部分...

当我们讨论 [[context-engineering]] 时，实际上是在讨论 [[harness]] 的核心能力...

## 本文引入的概念

- [[harness]]
- [[context-engineering]]
- [[deterministic-constraints]]
```

---

## 工作流程

### Step 1：读取上下文

1. 读取 `purpose.md`（学习目标）
2. 扫描 `concepts/` 目录，读取所有已有概念的 frontmatter（获取 inDegree）
3. 读取原始文章（用户指定路径）

### Step 2：提取概念

从原始文章中提取概念，对每个概念：

**新概念**（`concepts/` 目录中不存在）：
- 文件名：`concepts/{id}.md`（id 为 kebab-case）
- frontmatter：
  - `tags: concept`
  - `hub: false`（新概念初始不是 hub）
  - `inDegree: 0`（新概念初始入度为 0）
  - `mastery: 20`（普通概念）或 `30`（有详细示例）
  - `firstAppearance: "[[article-name]]"`
- 正文：
  - `# 中文名称`
  - `## 定义`
  - `## 为什么重要`
  - `## 前置概念`（用 `[[concept-id]]` 引用）

**已有概念被引用**：
- 读取 `concepts/{id}.md` 的 frontmatter
- `inDegree` +1
- 更新 frontmatter
- 如果 `inDegree >= 3` 且 `hub: false`，更新为 `hub: true`

**掌握度估算规则**：
- 新概念首次出现：
  - 有详细示例：30
  - 普通概念：20
- 被引用后更新：
  - Hub 概念（inDegree >= 3）：40
  - 每增加 1 个引用：+5（上限 70）

### Step 3：生成/更新概念页面

对每个新概念：
1. 创建 `concepts/{id}.md`
2. 写入 frontmatter + 正文
3. 在 `## 前置概念` 中用 `[[prerequisite-id]]` 建立链接

对每个已引用概念：
1. 读取 `concepts/{id}.md`
2. 更新 frontmatter 中的 `inDegree` 和 `mastery`
3. 如果达到 Hub 阈值，更新 `hub: true`

### Step 4：生成学习文章

在 `articles/` 目录生成学习文章：

```markdown
# 第 NN 篇：{文章标题}

## 📊 前置概念检查

- [[concept-a]] — 掌握度 60%
- [[concept-b]] — 掌握度 30%

## {正文各节}

...（正文中用 [[concept]] 引用概念）

## 本文引入的概念

- [[new-concept-1]]
- [[new-concept-2]]

## 下一步

...
```

### Step 5：生成 Mermaid 概念网络图

在 `graph/` 目录生成独立的 Mermaid 图谱文件。

**文件路径**：
- 概念数 ≤ 15：`graph/concept-network.md`（单文件）
- 概念数 > 15：
  - `graph/concept-network.md`（简化版，Top 15）
  - `graph/concept-network-full.md`（完整版）

**内容结构**：
```markdown
# 概念网络图谱（简化版 - Top 15）

> ⚠️ 为避免认知负担，此图仅显示关联度最高的 15 个概念
> 完整图谱请查看：[[concept-network-full]]

## 统计信息

- 总概念数：{total_count}
- 当前显示：{shown_count} 个
- Hub 概念：{hub_count}（inDegree >= 3）
- 平均掌握度：{avg_mastery}%

## 概念列表（按关联度排序）

| 概念 | inDegree | 掌握度 |
|------|----------|--------|
| [[harness]] | 19 | 40% |
| [[context-engineering]] | 8 | 35% |

## 概念网络

```mermaid
graph TD
    %% Hub 概念用双框标记
    harness[["harness<br/>inDegree: 19"]]
    context[["context-engineering<br/>inDegree: 8"]]
    
    %% 普通概念
    agent["agent<br/>inDegree: 2"]
    loop["agent-loop<br/>inDegree: 1"]
    
    %% 概念依赖关系
    agent --> harness
    loop --> agent
    context --> harness
    
    %% 样式
    classDef hub fill:#ff6b6b,stroke:#c92a2a,stroke-width:3px
    classDef normal fill:#4ecdc4,stroke:#0891b2,stroke-width:2px
    
    class harness,context hub
    class agent,loop normal
```
\```

## 使用说明

1. **在 Obsidian 中查看**：直接渲染 Mermaid 图
2. **导出为图片**：使用 Obsidian 插件或在线工具
3. **点击概念名**：跳转到对应概念页面
4. **查看完整图谱**：[[concept-network-full]]
```

**生成规则**：
1. 扫描所有 `concepts/*.md`，读取 frontmatter
2. 如果概念数 > 15，按 inDegree 降序排序，取前 15 个生成简化版
3. Hub 概念（inDegree >= 3）用双框 `[[ ]]` 标记
4. 普通概念用单框 `[ ]` 标记
5. 从每个概念的 `## 前置概念` 提取依赖关系（简化版只显示 Top 15 内的关系）
6. Hub 概念用红色，普通概念用蓝色

### Step 6：Obsidian Graph View（可选）

如果用户的 Vault 不大，也可以使用 Obsidian 原生 Graph View：

1. **Graph View**：`Ctrl/Cmd + G` 打开全局图谱
   - 显示所有 `[[wikilink]]` 连接
   - Hub 概念自动显示为更大节点

2. **Local Graph**：在任一概念页面打开局部图谱
   - 显示该概念的直接前驱和后继

3. **反向链接面板**：每个概念页面自动显示引用上下文

**问题**：如果 Vault 较大（包含其他项目），Graph View 会显示整个仓库的图谱，不只是 dacapo 概念网络。

**解决方案**：使用独立的 Mermaid 图谱（Step 5）

---

## 可视化配置

为避免概念过多时认知负担过重，支持动态阈值控制：

```yaml
visualization:
  maxNodes: 15          # 超过则自动简化
  minInDegree: 2        # 简化版只显示关联度 >= 2 的概念
  generateFullGraph: true  # 是否同时生成完整图谱
```

**简化逻辑**：
1. 如果概念数 ≤ maxNodes，生成单个文件：`graph/concept-network.md`
2. 如果概念数 > maxNodes，生成两个版本：
   - `graph/concept-network.md` - 简化版（按 inDegree 排序，取前 15 个）
   - `graph/concept-network-full.md` - 完整版（所有概念）

**简化版选择规则**：
1. 按 inDegree 降序排序所有概念
2. 优先保留 inDegree ≥ minInDegree 的概念
3. 如果高关联度概念不足 maxNodes，补充 inDegree 最高的概念至上限
4. 简化版标题注明"简化版（Top 15）"，并提示完整图谱路径

---

## 边界与约束

**本 Skill 负责**：
- 从原始文章提取概念
- 生成/更新概念页面（`concepts/*.md`）
- 生成学习文章（`articles/*.md`）
- 生成 Mermaid 概念网络图（`graph/concept-network.md`）
- 维护双向链接和 frontmatter 元数据

**本 Skill 不负责**：
- 交互式诊断（"你觉得这个概念掌握了吗？"）
- 健康检查与提醒
- 查漏补缺与复习计划

**假设与依赖**：
- 工作目录已是或将成为 Obsidian vault
- 用户会在 Obsidian 中打开该目录
- 掌握度是估算值，用于热力图，不做精确追踪

---

## 停止条件

**成功完成**：
- 所有新概念已生成独立页面
- 所有引用关系已建立（双向链接）
- 学习文章已生成
- 所有 inDegree 已更新
- Hub 概念已标记

**停止时输出**：
```
✅ 已处理文章：{article-name}
📝 新增概念：{count} 个
🔗 更新引用：{count} 次
⭐ 新 Hub 概念：{list}（如有）
📊 Mermaid 图谱：graph/concept-network.md
   （概念数 > 15，已生成简化版 + 完整版）
📂 可在 Obsidian 中打开该目录查看双向链接
```

---

## 示例执行

**输入**：
```
raw-sources/04-loop-engineering.md
```

**执行过程**：
1. 读取已有概念（扫描 `concepts/` 目录）
2. 提取新概念：`loop-engineering`、`heartbeat`、`persistent-state`
3. 生成 `concepts/loop-engineering.md`、`concepts/heartbeat.md`、`concepts/persistent-state.md`
4. 更新 `concepts/harness.md`（inDegree: 19 → 20）
5. 生成 `articles/04-loop-engineering.md`（正文中使用 `[[loop-engineering]]` 等链接）

**输出**：
```
✅ 已处理文章：04-loop-engineering
📝 新增概念：3 个（loop-engineering, heartbeat, persistent-state）
🔗 更新引用：5 次（harness +1, context-engineering +1...）
⭐ 新 Hub 概念：long-running-autonomy（inDegree 4→5）
📂 请在 Obsidian 中打开该目录查看 Graph View
```

**Obsidian 中的效果**：
- Graph View 显示 `[[loop-engineering]]` 连接到 `[[harness]]`
- 点击 `[[harness]]` 节点，显示为橙色大节点（Hub）
- 在 `harness.md` 页面底部，反向链接面板显示"被 04-loop-engineering 引用"
- 悬停在文章中的 `[[loop-engineering]]` 上，自动预览其定义

---

## 错误处理

- 原始文章路径不存在 → 报错并列出 `raw-sources/` 可用文件
- `concepts/` 目录不存在 → 自动创建
- 概念提取失败（无新概念） → 询问用户是否继续生成文章

---

## 语言

- 用户用中文就用中文回复
- 中文回复遵循《中文文案排版指北》
