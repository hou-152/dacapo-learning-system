---
name: dacapo-main
description: DaCapo Learn 概念学习系统的智能导航入口。根据用户输入自动识别意图并路由到对应的 Skill。支持学习概念（learn）、查询进度（status）、探索关联（discover）、生成可视化（visualize）、获取推荐（suggest）五种核心意图。当用户说 "学习 agent"、"查看进度"、"推荐下一个" 时使用。
---

# dacapo - DaCapo Learn 统一入口

**定位**：DaCapo Learn 概念学习系统的智能导航入口，提供意图识别 + 上下文整合 + 智能路由。

## 核心能力

### 1. 五种意图识别

自动识别用户意图并路由到对应 Skill：

| 意图 | 触发词示例 | 路由目标 | 需要上下文 |
|------|-----------|---------|-----------|
| **learn** | "agent"、"学习 harness" | dacapo-dispatch → dacapo-learning | ✅ 需要历史上下文 |
| **status** | "进度"、"状态" | dacapo-learning status | ❌ 直接查询 |
| **discover** | "发现关联"、"探索" | dacapo-wiki discover | ✅ 需要全局图谱 |
| **visualize** | "图谱"、"可视化" | dacapo-visualize | ✅ 需要关系数据 |
| **suggest** | "推荐"、"下一个" | dacapo-learning suggestions | ✅ 需要推荐缓存 |

详细意图模式见 `references/intent-patterns.md`。

### 2. 历史上下文检索

当意图为 **learn** 时，自动调用 dacapo-wiki 获取：
- ✅ 依赖概念（已学习的优先展示）
- ✅ 被依赖关系（谁在用这个概念）
- ✅ 跨项目关联（草蛇灰线发现）
- ✅ 当前掌握度和学习历史

### 3. 智能推荐输出

输出格式：**推荐 Skill + 推荐理由 + 可直接发送的提示词**

示例：
```
🎯 检测到学习意图

📍 目标概念：agent
📂 文件路径：~/Documents/AI-concepts/agent.md

📊 上下文分析：
  ✅ 依赖概念 harness (85% 掌握, 2026-09-27)
  ⚠️ 依赖概念 context engineering (0% 掌握, 未学习)
  🔗 被 3 个概念引用
  🌐 跨项目关联：AI实战营/deepseek-harness

🚀 推荐执行：dacapo-learning
📝 理由：依赖概念已掌握 85%，可以开始学习

---
正在调用 dacapo-learning 开始学习...
```

## 快速开始

```bash
# 学习概念（自动获取上下文）
/dacapo agent

# 查看进度
/dacapo 进度

# 获取推荐
/dacapo 推荐

# 探索关联
/dacapo 发现关联

# 生成图谱
/dacapo 图谱
```

## 执行流程

### Step 1: 意图识别

读取 `references/intent-patterns.md` 进行意图识别。

**识别策略**：
```
1. 检查是否提到具体概念名称 → learn
2. 检查是否包含"进度/状态" → status
3. 检查是否包含"推荐/下一个" → suggest
4. 检查是否包含"发现/探索/关联" → discover
5. 检查是否包含"图/可视化" → visualize
6. 无法判断 → 提供选项菜单
```

### Step 2: 上下文获取（仅 learn 意图）

当意图为 **learn** 时，调用 dacapo-wiki 获取历史上下文：

```bash
# 1. 定位概念文件
dacapo-wiki locate "agent"

# 2. 获取依赖和关联
dacapo-wiki context "agent"
```

返回的上下文包含：
- **依赖概念**：学习本概念需要先掌握哪些概念
- **被依赖关系**：哪些概念依赖本概念
- **跨项目关联**：相关概念在其他项目的出现
- **掌握度数据**：当前 mastery、lastStudied、studyCount

详细路由规则见 `references/context-routing.md`。

### Step 3: 输出推荐

使用以下格式输出：

```
🎯 检测到 [意图类型] 意图

[根据意图类型展示对应信息]

🚀 推荐执行：[skill-name]
📝 理由：[为什么推荐这个 Skill]

---
正在调用 [skill-name]...
```

### Step 4: 执行路由

直接调用目标 Skill，不再询问用户确认。

---

## DaCapo Learn 体系

### 10 个协作 Skill

**交互式学习层**（智能路由）：
- `dacapo-main` — 统一入口（本 Skill）
- `dacapo-dispatch` — 智能路由和上下文整合
- `dacapo-learning` — 自适应学习（2 问题评估 + frontmatter 记录）
- `dacapo-wiki` — 概念探索（跨项目草蛇灰线发现）

**概念图谱层**（内容生产）：
- `dacapo-learn` — 概念提取 + 学习文章生成
- `dacapo-core` — 核心功能库
- `dacapo-article` — 文章处理
- `dacapo-visualize` — 可视化生成
- `dacapo-lint` — 质量校验
- `dacapo-diagnose` — 问题诊断

---

## 执行指令

### 基本流程

1. **读取 `references/intent-patterns.md`** 进行意图识别
2. **learn 意图**：调用 dacapo-wiki 获取上下文（详见 `references/context-routing.md`）
3. **输出推荐**：使用统一格式（skill + 理由 + 行动）
4. **直接执行**：调用目标 Skill，无需用户确认

### 意图识别优先级

```
1. learn    - 如果提到具体概念名称
2. status   - 如果包含"进度/状态"
3. suggest  - 如果包含"推荐/下一个"
4. discover - 如果包含"发现/探索/关联"
5. visualize- 如果包含"图/可视化"
6. unknown  - 提供选项菜单
```

### 输出格式模板

```markdown
🎯 检测到 [意图类型] 意图

[意图特定的上下文信息]

🚀 推荐执行：[skill-name]
📝 理由：[推荐理由，1-2 句话]

---
正在调用 [skill-name]...
```

详细执行步骤、输出示例、异常处理见 `references/detailed-instructions.md`。

---

## 核心价值

### 1. 复利式学习（2.4倍提升）

**问题**：传统学习割裂，每个概念孤立学习。

**解决方案**：自动关联已学概念，用已知理解未知。

**效果**：
- 无上下文：35% 理解度
- 有上下文：85% 理解度
- **提升 2.4 倍**

### 2. 跨项目草蛇灰线

**问题**：不同项目的相关概念被分隔。

**解决方案**：dacapo-wiki 自动发现跨项目关联。

**案例**：
- harness（AI内参）↔ deepseek-harness（AI实战营）
- agent（AI-concepts）↔ autonomous agent（Research）

### 3. 自适应学习路径

**问题**：不知道下一步学什么。

**解决方案**：基于掌握度 + 依赖关系智能推荐。

**对标**：Bloom 2 Sigma Problem（一对一辅导 vs 课堂教学）

### 4. 轻量化实现

**无需额外数据库**：
- 数据存储：frontmatter
- 评估方式：2个问题
- 推荐缓存：7天 JSON

**快速响应**：
- 意图识别：<100ms
- 上下文获取：<2s
- 推荐计算：<5s

---

## 设计原则

### 1. 渐进式加载

遵循 skill-creator 的三级加载原则：

1. **Metadata**（always）：name + description
2. **SKILL.md body**（on trigger）：核心流程 <500 行
3. **References**（as needed）：详细规则和示例

### 2. 最小必要上下文

只传递当前意图所需的上下文，避免信息过载：

- learn：需要依赖、关联、掌握度
- status：无需额外上下文
- discover：需要全局图谱
- visualize：需要关系数据
- suggest：需要推荐缓存

### 3. 直接执行，不生成提示词

区别于传统路由：
- ❌ 传统：生成提示词让用户复制
- ✅ dacapo：直接调用目标 Skill

### 4. 对标 dbs 形态

```bash
# dbs 形态
/dbs 我准备学习社会学基本概念...
    ↓ 版本检查 + Skill 发现
    ↓ 智能路由
    ↓ 直接执行

# dacapo 形态
/dacapo agent
    ↓ Skill 发现
    ↓ 意图识别
    ↓ 智能路由
    ↓ 直接执行
```

---

## 命名说明

**DaCapo** (意大利语)：
- 音乐术语：从头再来（Da Capo al Fine）
- 寓意：温故知新、螺旋上升的学习

**DaCapo Learn**：
- 整个概念学习体系的名称
- 强调概念复利、螺旋上升

---

## 参考资料

### Skill 内部文档

- `references/intent-patterns.md` — 意图识别示例库
- `references/context-routing.md` — 带上下文的路由规则

### 项目文档

- `~/Documents/交互式学习/DACAPO-UNIFIED-ENTRY.md` — 完整设计文档
- `~/Documents/交互式学习/docs/INTEGRATION.md` — 集成架构
- `~/Documents/交互式学习/docs/NAMING.md` — 命名说明
- `~/Documents/交互式学习/docs/TEST-CASES.md` — 测试用例

### 相关 Skills

- `dacapo-dispatch` — 智能路由和上下文整合
- `dacapo-learning` — 自适应学习引擎
- `dacapo-wiki` — 概念探索和跨项目发现
- `dacapo-visualize` — 概念图谱可视化

---

## 版本历史

- **v2.0** (2026-09-28)：升级为智能路由系统
  - ✅ 添加 5 种意图识别
  - ✅ 集成 dacapo-wiki 历史上下文检索
  - ✅ 推荐输出格式（skill + 理由 + 提示词）
  - ✅ 创建 references/intent-patterns.md
  - ✅ 创建 references/context-routing.md
  - ✅ 渐进式加载设计（<500 行）

- **v1.0** (2026-09-28)：初始版本
  - ✅ 简单关键词路由
  - ✅ 统一入口设计
