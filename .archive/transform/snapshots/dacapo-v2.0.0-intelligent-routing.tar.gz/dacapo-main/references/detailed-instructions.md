# 详细执行指令

本文件包含每种意图的详细处理步骤、输出示例和技术实现。

## 1. learn 意图处理

**触发条件**：用户输入包含具体概念名称，如 "agent"、"学习 harness"

**执行步骤**：

```
Step 1: 调用 dacapo-wiki 定位概念
  → 如果找到：继续
  → 如果未找到：提示"概念不存在，是否创建？"

Step 2: 调用 dacapo-wiki 获取上下文
  → 读取依赖概念的 frontmatter（mastery, lastStudied）
  → 查找跨项目关联
  → 查找被依赖关系

Step 3: 分析依赖就绪度
  → 已学习的依赖（mastery > 0.6）标记 ✅
  → 未学习的依赖（mastery < 0.6）标记 ⚠️
  → 计算整体就绪度

Step 4: 输出推荐并调用 dacapo-learning
```

**输出示例**：

```
🎯 检测到学习意图

📍 目标概念：agent
📂 文件路径：~/Documents/AI-concepts/agent.md

📊 上下文分析：
  ✅ 依赖概念 harness (85% 掌握, 2026-09-27)
     最近学习：Agent 运行环境的基本概念
  ⚠️ 依赖概念 context engineering (0% 掌握, 未学习)
  
  🔗 被以下概念依赖：
     - multi-agent system
     - agent framework
     - autonomous agent

  🌐 跨项目关联：
     - AI实战营/deepseek-harness: Harness 在实战项目的实现
     - DBS Skills/skill-harness: Skill 执行环境

🚀 推荐执行：dacapo-learning
📝 理由：核心依赖 harness 已掌握 85%，建议学习

---
正在调用 dacapo-learning...
```

---

## 2. status 意图处理

**触发条件**：用户输入包含"进度"、"状态"、"学了多少"

**执行步骤**：

```
Step 1: 直接调用 dacapo-learning status
  → 无需额外上下文获取
  → 该 Skill 会读取所有概念文件的 frontmatter
```

**输出示例**：

```
🎯 检测到状态查询意图

🚀 推荐执行：dacapo-learning status
📝 理由：查看整体学习进度和掌握度分布

---
正在调用 dacapo-learning status...
```

---

## 3. discover 意图处理

**触发条件**：用户输入包含"发现"、"探索"、"关联"、"草蛇灰线"

**执行步骤**：

```
Step 1: 判断是否指定概念
  → 有指定：调用 dacapo-wiki discover [concept]
  → 无指定：调用 dacapo-wiki discover（全局探索）

Step 2: dacapo-wiki 返回跨项目关联和关系网络
```

**输出示例**：

```
🎯 检测到探索发现意图

📍 目标：探索概念关联和跨项目草蛇灰线

🚀 推荐执行：dacapo-wiki discover
📝 理由：发现概念之间的隐藏关联，建立知识网络

---
正在调用 dacapo-wiki discover...
```

---

## 4. visualize 意图处理

**触发条件**：用户输入包含"图谱"、"可视化"、"图"

**执行步骤**：

```
Step 1: 读取所有概念的 dependencies 和 mastery
Step 2: 调用 dacapo-visualize 生成 Mermaid 图谱
  → 绿色节点：mastery > 0.6（已掌握）
  → 红色节点：mastery < 0.6（待学习）
```

**输出示例**：

```
🎯 检测到可视化意图

📊 将生成概念关系图谱，展示：
  - 概念依赖关系
  - 掌握度分布（颜色编码）
  - 学习路径建议

🚀 推荐执行：dacapo-visualize
📝 理由：可视化帮助理解概念网络结构

---
正在调用 dacapo-visualize...
```

---

## 5. suggest 意图处理

**触发条件**：用户输入包含"推荐"、"下一个"、"接下来学什么"

**执行步骤**：

```
Step 1: 检查 suggestions.json（7天缓存）
  → 存在且未过期：使用缓存
  → 不存在或过期：调用 dacapo-learning 重新计算

Step 2: 调用 dacapo-learning suggestions
  → 基于依赖就绪度、重要度、新鲜度计算推荐优先级
```

**输出示例**：

```
🎯 检测到推荐意图

📚 将基于以下因素推荐下一步学习：
  - 依赖就绪度（已学概念可支撑）
  - 重要度（被多少概念依赖）
  - 新鲜度（距离上次学习时间）

🚀 推荐执行：dacapo-learning suggestions
📝 理由：智能推荐最适合当前学习的概念

---
正在调用 dacapo-learning suggestions...
```

---

## 模糊输入处理

当用户输入无法明确判断意图时，提供选项菜单：

```
❓ 你想做什么？

1️⃣ 学习一个概念
   示例：/dacapo agent

2️⃣ 查看学习进度
   示例：/dacapo 进度

3️⃣ 获取学习推荐
   示例：/dacapo 推荐

4️⃣ 探索概念关联
   示例：/dacapo 发现关联

5️⃣ 生成可视化图谱
   示例：/dacapo 图谱

请输入对应数字或具体指令。
```

---

## 核心技术实现

### 意图识别算法

使用关键词匹配 + 优先级规则：

```python
def identify_intent(user_input):
    # 优先级 1: learn（如果提到具体概念）
    if contains_concept_name(user_input):
        return "learn", extract_concept_name(user_input)
    
    # 优先级 2: status
    if any(keyword in user_input for keyword in ["进度", "状态", "学了多少"]):
        return "status", None
    
    # 优先级 3: suggest
    if any(keyword in user_input for keyword in ["推荐", "下一个", "接下来"]):
        return "suggest", None
    
    # 优先级 4: discover
    if any(keyword in user_input for keyword in ["发现", "探索", "关联", "草蛇灰线"]):
        return "discover", None
    
    # 优先级 5: visualize
    if any(keyword in user_input for keyword in ["图", "可视化", "图谱"]):
        return "visualize", None
    
    # 无法判断
    return "unknown", None
```

### 上下文获取流程

仅 **learn** 意图需要上下文：

```
1. 调用 dacapo-wiki locate [concept]
   → 返回概念文件路径

2. 读取概念文件的 frontmatter
   → mastery, lastStudied, studyCount, dependencies

3. 对每个依赖概念，读取其 frontmatter
   → 判断是否已学习（mastery > 0.6）

4. 调用 dacapo-wiki 查询跨项目关联
   → 搜索其他项目中提到该概念的文件

5. 查询被依赖关系（inDegree）
   → 有多少其他概念依赖本概念
```

### 推荐输出格式模板

统一使用以下 Markdown 模板：

```markdown
🎯 检测到 [意图类型] 意图

[意图特定的上下文信息]

🚀 推荐执行：[skill-name]
📝 理由：[推荐理由，1-2 句话]

---
正在调用 [skill-name]...
```

### 性能优化策略

- **懒加载**：只有 learn 意图才调用 dacapo-wiki
- **并行查询**：同时查询依赖、被依赖、跨项目关联
- **缓存策略**：suggestions.json 7天缓存
- **增量更新**：frontmatter 只写变化字段

---

## 异常处理

### 概念未找到

```
❌ 未找到概念 "xyz"

可能原因：
  - 概念尚未创建
  - 拼写错误
  - 概念在其他项目

建议操作：
  1. 使用 /dacapo discover 探索现有概念
  2. 检查拼写是否正确
  3. 使用 /dacapo-learn 创建新概念
```

### 依赖循环检测

```
⚠️ 检测到依赖循环

循环路径：agent → harness → context engineering → agent

建议操作：
  1. 使用 /dacapo visualize 查看完整依赖图
  2. 重新梳理概念依赖关系
  3. 考虑拆分或合并概念
```

### 上下文获取失败

```
⚠️ 无法获取历史上下文

降级处理：继续基础学习模式（无上下文增强）

可能原因：
  - dacapo-wiki 不可用
  - 概念文件格式错误
  - frontmatter 缺失

---
正在调用 dacapo-learning（基础模式）...
```

### 推荐缓存过期

```
ℹ️ 推荐缓存已过期（>7天），正在重新计算...

预计耗时：5-10 秒
```

---

## 数据结构

### Frontmatter 结构

每个概念文件的 frontmatter：

```yaml
---
mastery: 0.75           # 掌握度 (0.0-1.0)
lastStudied: 2026-09-28 # 最后学习日期
studyCount: 2           # 学习次数
dependencies:           # 依赖概念
  - harness
  - context engineering
inDegree: 5            # 被引用次数
---
```

### suggestions.json 结构

推荐缓存文件（7天有效）：

```json
{
  "basedOn": "agent",
  "timestamp": "2026-09-28T10:30:00Z",
  "suggestions": [
    {
      "concept": "multi-agent system",
      "reason": "依赖 agent (已掌握 85%)",
      "priority": 0.9,
      "readiness": "ready"
    }
  ]
}
```

### 上下文传递结构

从 dacapo-main 到目标 Skill：

```json
{
  "intent": "learn",
  "target": "agent",
  "filePath": "/Users/housibo/Documents/AI-concepts/agent.md",
  "context": {
    "dependencies": [
      {
        "name": "harness",
        "mastery": 0.85,
        "lastStudied": "2026-09-27",
        "learned": true
      }
    ],
    "dependents": ["multi-agent system", "agent framework"],
    "crossProject": [
      {
        "project": "AI实战营",
        "path": "~/Documents/AI实战营/concepts/deepseek-harness.md"
      }
    ],
    "mastery": 0.0,
    "lastStudied": null
  }
}
```
