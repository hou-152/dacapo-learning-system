# 意图识别示例库

本文件提供意图识别的模式示例，帮助 dacapo-main 准确判断用户意图并路由到正确的 Skill。

## 五种核心意图

### 1. learn（学习意图）

**触发特征**：
- 直接提及具体概念名称
- 包含"学习""掌握""理解""搞懂"等动词
- 提供概念文件路径或链接

**示例**：
```
/dacapo agent
/dacapo 学习 agent
/dacapo 我想理解 harness
/dacapo 帮我搞懂 context engineering
/dacapo ~/Documents/AI-concepts/agent.md
```

**路由目标**：`dacapo-dispatch` → `dacapo-learning`

**上下文需求**：需要调用 dacapo-wiki 获取：
- 该概念的依赖概念（已学习的优先展示）
- 该概念被哪些其他概念引用
- 跨项目关联（如 AI内参 ↔ AI实战营）

---

### 2. status（状态查询意图）

**触发特征**：
- 包含"进度""状态""学了多少""掌握度"等词
- 询问某个概念或整体学习情况
- 请求统计数据

**示例**：
```
/dacapo 进度
/dacapo 状态
/dacapo 我学了多少概念
/dacapo agent 掌握度如何
/dacapo 查看学习统计
```

**路由目标**：`dacapo-learning status`

**上下文需求**：无需额外上下文，直接读取 frontmatter 数据

---

### 3. discover（探索发现意图）

**触发特征**：
- 包含"发现""探索""关联""关系"等词
- 询问跨项目连接
- 想了解概念网络结构

**示例**：
```
/dacapo 发现关联
/dacapo 探索 agent 相关概念
/dacapo harness 和哪些概念相关
/dacapo 草蛇灰线
/dacapo 跨项目关联
```

**路由目标**：`dacapo-wiki discover`

**上下文需求**：需要 dacapo-wiki 的全局概念图谱

---

### 4. visualize（可视化意图）

**触发特征**：
- 包含"图谱""可视化""图""展示"等词
- 请求生成概念关系图
- 想看学习路径

**示例**：
```
/dacapo 图谱
/dacapo 可视化
/dacapo 生成概念图
/dacapo agent 的依赖图
/dacapo 学习路径图
```

**路由目标**：`dacapo-visualize`

**上下文需求**：需要读取多个概念文件的 frontmatter 和 dependencies

---

### 5. suggest（推荐意图）

**触发特征**：
- 包含"推荐""下一个""接下来学什么"等词
- 学习完一个概念后的延续
- 请求学习建议

**示例**：
```
/dacapo 推荐
/dacapo 下一个
/dacapo 接下来学什么
/dacapo 推荐相关概念
/dacapo 学习建议
```

**路由目标**：`dacapo-learning suggestions`

**上下文需求**：需要读取 suggestions.json（7天缓存）和全局掌握度数据

---

## 意图识别优先级

当用户输入模糊时，按以下优先级判断：

1. **learn** - 如果提到具体概念名称，优先视为学习意图
2. **status** - 如果包含"进度""状态"等查询词
3. **suggest** - 如果包含"推荐""下一个"
4. **discover** - 如果包含"发现""探索""关联"
5. **visualize** - 如果包含"图""可视化"

## 模糊输入处理

对于无法明确判断的输入，默认路由到 `dacapo-dispatch`，由它进一步澄清用户意图：

```
用户：/dacapo 
→ dacapo-dispatch 提问："你想做什么？"
  1. 学习一个概念
  2. 查看学习进度
  3. 获取推荐
  4. 探索概念关联
  5. 生成可视化图谱
```

## 上下文传递格式

当路由到目标 Skill 时，传递以下结构化上下文：

```json
{
  "intent": "learn",
  "target": "agent",
  "context": {
    "dependencies": ["harness", "context engineering"],
    "dependents": ["multi-agent system", "agent framework"],
    "crossProject": [
      {
        "project": "AI实战营",
        "concepts": ["deepseek-harness"]
      }
    ],
    "mastery": 0.0,
    "lastStudied": null
  }
}
```
