# 带上下文的路由规则

本文件定义如何为每种意图获取和传递上下文，以及路由决策逻辑。

## 路由决策树

```
用户输入
  ↓
意图识别（参考 intent-patterns.md）
  ↓
┌─────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│   learn     │   status     │   discover   │  visualize   │   suggest    │
└─────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
      ↓              ↓              ↓              ↓              ↓
  上下文获取      直接执行       上下文获取      上下文获取      上下文获取
      ↓                            ↓              ↓              ↓
dacapo-dispatch              dacapo-wiki    dacapo-visualize  suggestions.json
      ↓
dacapo-learning
```

## 1. learn 意图的上下文路由

### 1.1 定位概念文件

调用 `dacapo-wiki` 的概念定位功能：

```bash
# 方法 1: 通过概念名搜索
dacapo-wiki locate "agent"

# 方法 2: 用户直接提供路径
# 跳过定位，直接使用
```

### 1.2 获取历史上下文

调用 `dacapo-wiki` 获取以下上下文：

```json
{
  "concept": "agent",
  "filePath": "/Users/housibo/Documents/AI-concepts/agent.md",
  "frontmatter": {
    "mastery": 0.0,
    "lastStudied": null,
    "studyCount": 0,
    "dependencies": ["harness", "context engineering"],
    "inDegree": 3
  },
  "context": {
    "dependencies": [
      {
        "name": "harness",
        "path": "/Users/housibo/Documents/AI-concepts/harness.md",
        "mastery": 0.85,
        "lastStudied": "2026-09-27",
        "learned": true
      },
      {
        "name": "context engineering",
        "path": "/Users/housibo/Documents/AI-concepts/context-engineering.md",
        "mastery": 0.0,
        "learned": false
      }
    ],
    "dependents": [
      {
        "name": "multi-agent system",
        "inDegree": 2
      }
    ],
    "crossProject": [
      {
        "project": "AI实战营",
        "path": "/Users/housibo/Documents/AI实战营/concepts/deepseek-harness.md",
        "relation": "harness 在另一个项目的实现"
      }
    ]
  }
}
```

### 1.3 准备学习材料

`dacapo-dispatch` 整理上下文后，调用 `dacapo-learning`：

**传递格式**：
```
概念：agent
文件：/Users/housibo/Documents/AI-concepts/agent.md

📊 当前掌握度：0% (首次学习)

📚 依赖概念（建议先掌握）：
  ✅ harness (85% 掌握, 上次学习: 2026-09-27)
  ⚠️ context engineering (0% 掌握, 未学习)

🔗 被以下概念依赖：
  - multi-agent system
  - agent framework

🌐 跨项目关联：
  - AI实战营/deepseek-harness: harness 在另一个项目的实现

---

开始学习...
```

---

## 2. status 意图的路由

### 2.1 无需额外上下文

直接调用 `dacapo-learning status`，读取所有概念文件的 frontmatter。

### 2.2 输出格式

```
📊 DaCapo Learn 学习进度

总计概念：24
已学概念：8 (33%)
平均掌握度：42%

📈 掌握度分布：
  ████████░░ 0.8-1.0: 2 个
  ██████░░░░ 0.6-0.8: 3 个
  ████░░░░░░ 0.4-0.6: 3 个
  ░░░░░░░░░░ 0.0-0.4: 16 个

🔥 最近学习：
  - agent (2026-09-28, 85%)
  - harness (2026-09-27, 85%)
  - context engineering (2026-09-26, 65%)
```

---

## 3. discover 意图的上下文路由

### 3.1 调用 dacapo-wiki

```bash
dacapo-wiki discover [concept-name]
```

### 3.2 返回跨项目草蛇灰线

```json
{
  "concept": "harness",
  "localPath": "/Users/housibo/Documents/AI-concepts/harness.md",
  "crossProjectLinks": [
    {
      "project": "AI实战营",
      "path": "/Users/housibo/Documents/AI实战营/concepts/deepseek-harness.md",
      "relation": "实现细节",
      "similarity": 0.85
    },
    {
      "project": "DBS Skills",
      "path": "/Users/housibo/Documents/dbs/concepts/skill-harness.md",
      "relation": "应用场景",
      "similarity": 0.72
    }
  ],
  "relatedConcepts": [
    {
      "name": "agent",
      "relation": "uses",
      "strength": 0.9
    }
  ]
}
```

---

## 4. visualize 意图的上下文路由

### 4.1 收集概念关系数据

调用 `dacapo-visualize`，传递：

```json
{
  "concepts": [
    {
      "name": "agent",
      "dependencies": ["harness", "context engineering"],
      "mastery": 0.85
    },
    {
      "name": "harness",
      "dependencies": [],
      "mastery": 0.85
    }
  ],
  "focus": "agent",  // 可选，高亮特定概念
  "scope": "local"   // local | cross-project | all
}
```

### 4.2 生成 Mermaid 图谱

```mermaid
graph TD
  A[harness<br/>85%] --> B[agent<br/>85%]
  C[context engineering<br/>0%] --> B
  B --> D[multi-agent system<br/>0%]
  
  style A fill:#90EE90
  style B fill:#90EE90
  style C fill:#FFB6C1
  style D fill:#FFB6C1
```

---

## 5. suggest 意图的上下文路由

### 5.1 读取推荐缓存

检查 `suggestions.json`（7天有效）：

```json
{
  "basedOn": "agent",
  "timestamp": "2026-09-28T10:30:00Z",
  "suggestions": [
    {
      "concept": "multi-agent system",
      "reason": "依赖 agent (已掌握 85%)",
      "priority": 0.9,
      "readiness": "ready"
    },
    {
      "concept": "context engineering",
      "reason": "agent 的依赖，建议补充",
      "priority": 0.7,
      "readiness": "prerequisite"
    }
  ]
}
```

### 5.2 推荐算法

基于以下因素计算推荐优先级：

1. **依赖就绪度**（40%）：所有依赖概念的平均掌握度
2. **重要度**（30%）：被多少其他概念依赖（inDegree）
3. **新鲜度**（20%）：距离上次学习的时间
4. **相关性**（10%）：与最近学习概念的关联强度

公式：
```
priority = 0.4 * readiness + 0.3 * importance + 0.2 * freshness + 0.1 * relevance
```

### 5.3 输出格式

```
🎯 推荐下一步学习

1. multi-agent system (优先级: 90%)
   理由: 依赖 agent (已掌握 85%)，核心概念 (被 5 个概念依赖)
   状态: ✅ 准备就绪

2. context engineering (优先级: 70%)
   理由: agent 的依赖概念，建议补充基础
   状态: ⚠️ 前置概念

3. agent framework (优先级: 65%)
   理由: 与 agent 强相关 (0.85)，实践性强
   状态: ⚠️ 部分依赖未满足

输入 `/dacapo multi-agent system` 开始学习
```

---

## 上下文传递的通用规则

### 1. 最小必要原则

只传递当前意图所需的上下文，避免信息过载。

### 2. 结构化传递

使用 JSON 或 Markdown 结构化格式，便于解析和展示。

### 3. 已学优先

对于依赖概念，优先展示已学习的，降低认知负担。

### 4. 跨项目发现

learn 意图默认启用跨项目关联发现，其他意图按需启用。

### 5. 缓存策略

- 推荐缓存（suggestions.json）：7天有效
- 概念定位缓存：实时，无缓存
- 关系图缓存：按需重建

---

## 路由异常处理

### 概念未找到

```
❌ 未找到概念 "xyz"

建议：
  - 检查拼写
  - 使用 /dacapo discover 探索现有概念
  - 使用 /dacapo-learn 创建新概念
```

### 依赖循环

```
⚠️ 检测到依赖循环: agent → harness → agent

建议：
  - 重新梳理概念依赖关系
  - 使用 /dacapo visualize 查看完整依赖图
```

### 上下文获取失败

```
⚠️ 无法获取历史上下文，继续基础学习

(降级到无上下文模式)
```

---

## 性能优化

### 1. 懒加载

只在 learn 意图时调用 dacapo-wiki，其他意图按需。

### 2. 并行查询

同时查询依赖、被依赖、跨项目关联，减少等待。

### 3. 增量更新

frontmatter 更新只写变化字段，不重写整个文件。

### 4. 缓存失效

suggestions.json 超过 7 天或检测到新概念时重建。
