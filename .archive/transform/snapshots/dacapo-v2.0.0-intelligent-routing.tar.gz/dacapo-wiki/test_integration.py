#!/usr/bin/env python3
"""
模拟 dacapo-dispatch 调用 dacapo-wiki 的完整场景
"""

import subprocess
import json
import sys


def get_concept_context(concept_name: str) -> dict:
    """获取概念的学习上下文"""
    result = subprocess.run(
        ["python3", "llm-wiki.py", "context", concept_name, "--format", "json"],
        capture_output=True,
        text=True,
        cwd="/Users/housibo/.openclaw-autoclaw/skills/dacapo-wiki"
    )

    if result.returncode != 0:
        return {"error": "llm-wiki 调用失败"}

    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"error": "JSON 解析失败"}


def build_learning_context(context: dict) -> str:
    """构建传递给 dacapo-learning 的学习上下文"""
    if "error" in context:
        return f"错误: {context['error']}"

    target = context["target"]
    suggestions = context["suggestions"]

    # 构建上下文文本
    lines = [
        f"📚 概念：{target['name']}",
        f"📁 项目：{target['project']}",
        ""
    ]

    # 掌握度
    if target['mastery'] is not None:
        lines.append(f"✅ 当前掌握度：{target['mastery']:.0%}")
    else:
        lines.append("🆕 首次学习")

    lines.append("")

    # 定义
    if target['definition']:
        lines.append("📖 定义：")
        lines.append(target['definition'][:200] + "..." if len(target['definition']) > 200 else target['definition'])
        lines.append("")

    # 前置概念
    if target['dependencies']:
        lines.append("⬅️  前置概念（建议先学）：")
        for dep in target['dependencies'][:3]:
            lines.append(f"   • {dep}")
        lines.append("")

    # 推荐概念
    if suggestions:
        lines.append("💡 相关概念：")

        # 按类型分组
        by_type = {}
        for s in suggestions:
            type_name = s['type']
            if type_name not in by_type:
                by_type[type_name] = []
            by_type[type_name].append(s)

        # 显示推荐
        for type_name in ['dependency', 'downstream', 'hub', 'semantic']:
            if type_name in by_type:
                type_label = {
                    'dependency': '前置',
                    'downstream': '应用',
                    'hub': '核心',
                    'semantic': '关联'
                }.get(type_name, type_name)

                for s in by_type[type_name][:2]:
                    concept = s['concept']
                    lines.append(f"   • {concept['name']} ({type_label}) - {s['reason']}")

        lines.append("")

    # 跨项目关联
    cross_project = [s for s in suggestions if s['type'] == 'semantic' and s['concept']['project'] != target['project']]
    if cross_project:
        lines.append("🔗 跨项目联想（草蛇灰线）：")
        for s in cross_project[:2]:
            concept = s['concept']
            keywords = s.get('common_keywords', [])
            kw_text = f" [{', '.join(keywords[:3])}]" if keywords else ""
            lines.append(f"   • {concept['name']} (来自 {concept['project']}){kw_text}")
        lines.append("")

    return "\n".join(lines)


def simulate_dispatch(concept_name: str):
    """模拟 dacapo-dispatch 的完整调用流程"""
    print("=" * 70)
    print(f"🚀 模拟 dacapo-dispatch 调用流程：{concept_name}")
    print("=" * 70)
    print()

    # Step 1: 调用 llm-wiki
    print("Step 1: 调用 llm-wiki context...")
    context = get_concept_context(concept_name)

    if "error" in context:
        print(f"❌ {context['error']}")
        return False

    print(f"✅ 成功获取上下文")
    print(f"   - 概念：{context['target']['name']}")
    print(f"   - 项目：{context['target']['project']}")
    print(f"   - 掌握度：{context['target']['mastery']}")
    print(f"   - 推荐数量：{len(context['suggestions'])}")
    print()

    # Step 2: 构建学习上下文
    print("Step 2: 构建学习上下文...")
    learning_context = build_learning_context(context)
    print("✅ 上下文构建完成")
    print()

    # Step 3: 显示将传递给 dacapo-learning 的内容
    print("Step 3: 传递给 dacapo-learning 的上下文：")
    print("-" * 70)
    print(learning_context)
    print("-" * 70)
    print()

    return True


def main():
    print("\n🧪 dacapo-wiki 集成测试\n")

    # 测试用例
    test_cases = [
        ("harness", "存在的概念（有跨项目关联）"),
        ("context-engineering", "存在的概念（可能有依赖）"),
        ("nonexistent", "不存在的概念（错误处理）"),
    ]

    results = []

    for concept, description in test_cases:
        print(f"\n{'='*70}")
        print(f"测试：{description}")
        print(f"{'='*70}\n")

        success = simulate_dispatch(concept)
        results.append((concept, success))

        print()

    # 总结
    print("\n" + "=" * 70)
    print("📊 测试总结")
    print("=" * 70)

    for concept, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"{status} - {concept}")

    all_passed = all(success or concept == "nonexistent" for concept, success in results)

    print()
    if all_passed:
        print("🎉 所有核心测试通过！dacapo-wiki 已准备好被调用。")
        return 0
    else:
        print("⚠️  部分测试失败，请检查。")
        return 1


if __name__ == '__main__':
    sys.exit(main())
