#!/usr/bin/env python3
"""
llm-wiki - 概念探索和上下文挖掘引擎

基于 Obsidian 原生方案的跨项目概念关联发现系统。
从 ~/Documents/dacapo-学习仓库/ 读取所有项目的概念文件。
"""

import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# 学习仓库路径
LEARNING_REPO = Path.home() / "Documents/dacapo-学习仓库"
PROGRESS_DIR = LEARNING_REPO / ".learning-progress"

# 确保进度目录存在
PROGRESS_DIR.mkdir(parents=True, exist_ok=True)

# 停用词列表
STOP_WORDS = {
    # 中文停用词
    '的', '是', '在', '和', '与', '或', '等', '也', '就', '而', '有', '为', '这', '那',
    '它', '把', '被', '从', '到', '将', '会', '可以', '能够', '需要', '什么', '如何',
    '一个', '这个', '那个', '不是', '没有', '通过', '使用', '进行', '实现', '提供',
    # 英文停用词
    'the', 'is', 'at', 'which', 'on', 'a', 'an', 'as', 'are', 'was', 'were',
    'for', 'to', 'of', 'in', 'by', 'with', 'from', 'that', 'this', 'it',
}


class Concept:
    """概念数据类"""

    def __init__(self, file_path: Path, project: str):
        self.file_path = file_path
        self.project = project
        self.name = file_path.stem

        # Frontmatter 字段
        self.tags: List[str] = []
        self.dependencies: List[str] = []
        self.in_degree: int = 0
        self.mastery: Optional[float] = None
        self.first_appearance: Optional[str] = None

        # 内容
        self.definition: str = ""
        self.why: str = ""
        self.content: str = ""

        # Wikilinks
        self.wikilinks: Set[str] = set()

        self._parse()

    def _parse(self):
        """解析概念文件"""
        if not self.file_path.exists():
            return

        with open(self.file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 解析 frontmatter
        fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
        if fm_match:
            fm_text = fm_match.group(1)
            self._parse_frontmatter(fm_text)

            # 剩余内容
            body = content[fm_match.end():]
        else:
            body = content

        self.content = body

        # 提取 wikilinks
        self.wikilinks = set(re.findall(r'\[\[([^\]]+)\]\]', body))

        # 提取定义和重要性
        self._extract_sections(body)

    def _parse_frontmatter(self, fm_text: str):
        """解析 frontmatter"""
        for line in fm_text.split('\n'):
            line = line.strip()
            if not line or ':' not in line:
                continue

            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip().strip('"\'')

            if key == 'tags':
                # 可能是列表或单个值
                if value.startswith('['):
                    self.tags = [t.strip().strip('"\'') for t in value.strip('[]').split(',')]
                else:
                    self.tags = [value] if value else []

            elif key == 'dependencies' or key == '前置概念':
                if value.startswith('['):
                    self.dependencies = [d.strip().strip('"\'') for d in value.strip('[]').split(',')]
                else:
                    self.dependencies = [value] if value else []

            elif key == 'inDegree' or key == '被引用次数':
                try:
                    self.in_degree = int(value)
                except ValueError:
                    pass

            elif key == 'mastery' or key == '掌握度':
                try:
                    self.mastery = float(value) if value.lower() not in ('null', 'none', '') else None
                except ValueError:
                    pass

            elif key == 'firstAppearance' or key == '首次出现':
                self.first_appearance = value

    def _extract_sections(self, body: str):
        """提取定义和重要性章节"""
        lines = body.split('\n')

        current_section = None
        section_content = []

        for line in lines:
            # 检查是否是章节标题
            if line.startswith('#'):
                # 保存上一个章节
                if current_section and section_content:
                    content = '\n'.join(section_content).strip()
                    if current_section in ('定义', 'Definition', 'Context', '费曼一下'):
                        self.definition = content
                    elif current_section in ('为什么重要', 'Why', '重要性'):
                        self.why = content

                # 新章节
                current_section = line.lstrip('#').strip()
                section_content = []
            else:
                section_content.append(line)

        # 保存最后一个章节
        if current_section and section_content:
            content = '\n'.join(section_content).strip()
            if current_section in ('定义', 'Definition', 'Context', '费曼一下'):
                self.definition = content
            elif current_section in ('为什么重要', 'Why', '重要性'):
                self.why = content

    def get_text_for_keywords(self) -> str:
        """获取用于提取关键词的文本"""
        return f"{self.name} {self.definition} {self.why}"

    def to_dict(self) -> dict:
        """转为字典"""
        return {
            'name': self.name,
            'project': self.project,
            'file_path': str(self.file_path),
            'tags': self.tags,
            'dependencies': self.dependencies,
            'inDegree': self.in_degree,
            'mastery': self.mastery,
            'firstAppearance': self.first_appearance,
            'definition': self.definition,
            'why': self.why,
            'wikilinks': list(self.wikilinks),
        }


class ConceptGraph:
    """概念图谱"""

    def __init__(self):
        self.concepts: Dict[str, Concept] = {}  # name -> Concept
        self.projects: Dict[str, List[str]] = defaultdict(list)  # project -> [concept_names]

    def add_concept(self, concept: Concept):
        """添加概念"""
        self.concepts[concept.name] = concept
        self.projects[concept.project].append(concept.name)

    def get_concept(self, name: str) -> Optional[Concept]:
        """获取概念"""
        return self.concepts.get(name)

    def get_dependents(self, concept_name: str) -> List[str]:
        """获取依赖该概念的其他概念"""
        dependents = []
        for name, concept in self.concepts.items():
            if concept_name in concept.dependencies or concept_name in concept.wikilinks:
                dependents.append(name)
        return dependents

    def is_hub(self, concept_name: str) -> bool:
        """判断是否为 Hub 概念"""
        concept = self.get_concept(concept_name)
        if not concept:
            return False
        return concept.in_degree >= 3


def extract_keywords(text: str) -> Set[str]:
    """提取关键词"""
    if not text:
        return set()

    words = []

    # 提取英文单词
    english_words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9_-]+\b', text)
    words.extend(english_words)

    # 提取中文词（2-4字）
    chinese_phrases = re.findall(r'[一-鿿]{2,4}', text)
    words.extend(chinese_phrases)

    # 过滤停用词和短词
    keywords = {w.lower() for w in words if w.lower() not in STOP_WORDS and len(w) >= 2}

    return keywords


def calculate_similarity(concept_a: Concept, concept_b: Concept) -> Tuple[float, Set[str], List[str]]:
    """
    计算两个概念的相似度

    返回：(相似度, 共同关键词, 关联原因列表)
    """
    score = 0.0
    reasons = []
    common_keywords = set()

    # 1. 名称相似（30%）
    if concept_a.name.lower() in concept_b.name.lower() or concept_b.name.lower() in concept_a.name.lower():
        score += 0.3
        reasons.append("名称相似")

    # 2. 关键词重叠（40%）
    text_a = concept_a.get_text_for_keywords()
    text_b = concept_b.get_text_for_keywords()

    keywords_a = extract_keywords(text_a)
    keywords_b = extract_keywords(text_b)

    if keywords_a and keywords_b:
        common_keywords = keywords_a & keywords_b
        if common_keywords:
            overlap_ratio = len(common_keywords) / max(len(keywords_a), len(keywords_b))
            keyword_score = 0.4 * overlap_ratio
            score += keyword_score
            reasons.append(f"关键词重叠（{len(common_keywords)} 个）")

    # 3. 来源重叠（20%）
    if concept_a.first_appearance and concept_b.first_appearance:
        if concept_a.first_appearance == concept_b.first_appearance:
            score += 0.2
            reasons.append(f"同一来源: {concept_a.first_appearance}")

    # 4. 标签重叠（10%）
    common_tags = set(concept_a.tags) & set(concept_b.tags)
    if common_tags:
        tag_score = 0.1 * (len(common_tags) / max(len(concept_a.tags), len(concept_b.tags)))
        score += tag_score
        reasons.append(f"共享标签: {', '.join(common_tags)}")

    return min(score, 1.0), common_keywords, reasons


def load_all_concepts() -> ConceptGraph:
    """加载所有项目的概念"""
    graph = ConceptGraph()

    # 遍历所有项目目录
    for item in LEARNING_REPO.iterdir():
        if not item.is_dir():
            continue

        # 跳过隐藏目录
        if item.name.startswith('.'):
            continue

        # 跳过非项目目录
        if item.name in ('articles', 'graph', 'raw-sources'):
            continue

        # 查找 concepts 目录
        concepts_dir = item / 'concepts' if item.name != 'concepts' else item

        if not concepts_dir.exists():
            continue

        project_name = item.name if item.name != 'concepts' else '根目录'

        # 加载所有概念文件
        for concept_file in concepts_dir.glob('*.md'):
            try:
                concept = Concept(concept_file, project_name)
                graph.add_concept(concept)
            except Exception as e:
                print(f"⚠️  加载概念失败: {concept_file} - {e}", file=sys.stderr)

    return graph


def suggest_for_concept(graph: ConceptGraph, concept_name: str, limit: int = 8, output_format: str = 'human') -> dict:
    """
    基于某个概念生成推荐

    Args:
        graph: 概念图谱
        concept_name: 目标概念名称
        limit: 推荐数量上限
        output_format: 输出格式 ('human' 或 'json')

    返回推荐结果字典
    """
    target = graph.get_concept(concept_name)
    if not target:
        return {'error': f'概念不存在: {concept_name}'}

    same_project_recs = []
    cross_project_recs = []

    # 1. 同项目推荐

    # 前置概念（dependencies）
    for dep_name in target.dependencies:
        dep = graph.get_concept(dep_name)
        if dep:
            same_project_recs.append({
                'concept': dep.to_dict(),
                'type': 'dependency',
                'reason': f'理解 {target.name} 的前置概念',
                'similarity': 0.9,
            })

    # 下游概念（依赖当前概念的）
    dependents = graph.get_dependents(target.name)
    for dep_name in dependents[:3]:  # 最多 3 个
        dep = graph.get_concept(dep_name)
        if dep and dep.project == target.project:
            same_project_recs.append({
                'concept': dep.to_dict(),
                'type': 'downstream',
                'reason': f'{target.name} 的实际应用',
                'similarity': 0.85,
            })

    # Hub 概念
    for name in graph.projects[target.project]:
        if name == target.name:
            continue
        concept = graph.get_concept(name)
        if concept and graph.is_hub(name):
            same_project_recs.append({
                'concept': concept.to_dict(),
                'type': 'hub',
                'reason': f'Hub 概念（被 {concept.in_degree} 个概念引用）',
                'similarity': 0.75,
            })

    # 2. 跨项目推荐

    candidates = []
    for name, concept in graph.concepts.items():
        if concept.project == target.project:
            continue

        similarity, common_keywords, reasons = calculate_similarity(target, concept)

        if similarity >= 0.3:  # 阈值
            candidates.append({
                'concept': concept.to_dict(),
                'type': 'semantic',
                'reason': '; '.join(reasons),
                'similarity': similarity,
                'common_keywords': list(common_keywords)[:10],
            })

    # 按相似度排序
    candidates.sort(key=lambda x: x['similarity'], reverse=True)
    cross_project_recs = candidates[:3]

    # 3. 合并推荐，按优先级排序
    all_recs = same_project_recs + cross_project_recs
    all_recs.sort(key=lambda x: x['similarity'], reverse=True)

    return {
        'target': target.to_dict(),
        'suggestions': all_recs[:limit],
        'generated': datetime.now(timezone.utc).isoformat(),
    }


def discover_cross_project_links(graph: ConceptGraph, threshold: float = 0.35) -> List[dict]:
    """发现跨项目的草蛇灰线连接"""
    links = []

    projects = list(graph.projects.keys())

    for i, project_a in enumerate(projects):
        for project_b in projects[i+1:]:
            concepts_a = [graph.get_concept(name) for name in graph.projects[project_a]]
            concepts_b = [graph.get_concept(name) for name in graph.projects[project_b]]

            for concept_a in concepts_a:
                for concept_b in concepts_b:
                    similarity, common_keywords, reasons = calculate_similarity(concept_a, concept_b)

                    if similarity >= threshold:
                        links.append({
                            'project_a': project_a,
                            'project_b': project_b,
                            'concept_a': concept_a.to_dict(),
                            'concept_b': concept_b.to_dict(),
                            'similarity': similarity,
                            'common_keywords': list(common_keywords)[:15],
                            'reasons': reasons,
                        })

    # 按相似度排序
    links.sort(key=lambda x: x['similarity'], reverse=True)

    return links


def format_suggestions(result: dict):
    """格式化推荐结果"""
    if 'error' in result:
        print(f"❌ {result['error']}")
        return

    target = result['target']
    suggestions = result['suggestions']

    print(f"\n💡 基于「{target['name']}」的联想推荐")
    print(f"\n来自项目：{target['project']}")
    if target['definition']:
        print(f"定义：{target['definition'][:100]}...")
    print("\n" + "="*70)

    if not suggestions:
        print("\n未找到相关推荐")
        return

    # 同项目推荐
    same_project = [s for s in suggestions if s['concept']['project'] == target['project']]
    if same_project:
        print(f"\n✅ 同项目推荐（{target['project']}）：\n")
        for i, rec in enumerate(same_project, 1):
            concept = rec['concept']
            print(f"{i}. {concept['name']} （相似度: {rec['similarity']:.2f}）")
            print(f"   类型：{rec['type']}")
            print(f"   原因：{rec['reason']}")
            print(f"   📁 {concept['file_path']}")
            print()

    # 跨项目推荐
    cross_project = [s for s in suggestions if s['concept']['project'] != target['project']]
    if cross_project:
        print(f"\n🔗 跨项目联想（草蛇灰线）：\n")
        for i, rec in enumerate(cross_project, 1):
            concept = rec['concept']
            print(f"{i}. {concept['name']} （来自：{concept['project']}）")
            print(f"   相似度：{rec['similarity']:.2f}")
            print(f"   原因：{rec['reason']}")
            if rec.get('common_keywords'):
                print(f"   关键词：{', '.join(rec['common_keywords'][:8])}")
            print(f"   📁 {concept['file_path']}")
            print()


def format_discovery(links: List[dict]):
    """格式化发现结果"""
    print("\n🔍 跨项目草蛇灰线发现")
    print("\n" + "="*70 + "\n")

    if not links:
        print("未发现跨项目关联（阈值: 0.35）")
        return

    # 按项目对分组
    project_pairs = defaultdict(list)
    for link in links:
        key = (link['project_a'], link['project_b'])
        project_pairs[key].append(link)

    for (project_a, project_b), pair_links in project_pairs.items():
        print(f"\n📁 {project_a} ↔ {project_b}")
        print("-" * 70)

        for link in pair_links[:5]:  # 每对项目最多 5 个
            concept_a = link['concept_a']
            concept_b = link['concept_b']
            similarity = link['similarity']
            common_keywords = link['common_keywords']
            reasons = link['reasons']

            print(f"\n• {concept_a['name']} ↔ {concept_b['name']}")
            print(f"  相似度：{similarity:.2f}")
            print(f"  关联：{'; '.join(reasons)}")
            if common_keywords:
                print(f"  关键词：{', '.join(common_keywords[:10])}")

        print()


def cmd_context(concept_name: str, output_format: str = 'human'):
    """提供概念的完整上下文"""
    if output_format != 'json':
        print("🔄 加载概念图谱...", file=sys.stderr)

    graph = load_all_concepts()

    if output_format != 'json':
        print(f"✅ 已加载 {len(graph.concepts)} 个概念，来自 {len(graph.projects)} 个项目\n", file=sys.stderr)

    concept = graph.get_concept(concept_name)
    if not concept:
        if output_format == 'json':
            print(json.dumps({'error': f'概念不存在: {concept_name}'}, ensure_ascii=False, indent=2))
        else:
            print(f"❌ 概念不存在：{concept_name}")
            print(f"\n💡 可用概念（前 10 个）：")
            for name in list(graph.concepts.keys())[:10]:
                print(f"   - {name}")
        return

    # 生成推荐
    result = suggest_for_concept(graph, concept_name, output_format=output_format)

    if output_format == 'json':
        # JSON 输出：直接输出结构化数据
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # 人类可读输出
        print(f"📖 概念上下文：{concept.name}")
        print("="*70)
        print(f"\n项目：{concept.project}")
        print(f"文件：{concept.file_path}")

        if concept.tags:
            print(f"标签：{', '.join(concept.tags)}")

        if concept.first_appearance:
            print(f"首次出现：{concept.first_appearance}")

        print(f"\n定义：\n{concept.definition}")

        if concept.why:
            print(f"\n为什么重要：\n{concept.why}")

        if concept.dependencies:
            print(f"\n前置概念：{', '.join(concept.dependencies)}")

        dependents = graph.get_dependents(concept.name)
        if dependents:
            print(f"\n被以下概念引用：{', '.join(dependents[:5])}")
            if len(dependents) > 5:
                print(f"   ... 还有 {len(dependents) - 5} 个")

        if concept.wikilinks:
            print(f"\n内部链接：{', '.join(list(concept.wikilinks)[:10])}")

        if concept.mastery is not None:
            print(f"\n掌握度：{concept.mastery:.2f}")

        print("\n" + "="*70)
        format_suggestions(result)


def cmd_discover():
    """发现跨项目草蛇灰线"""
    print("🔄 加载概念图谱...")
    graph = load_all_concepts()
    print(f"✅ 已加载 {len(graph.concepts)} 个概念，来自 {len(graph.projects)} 个项目\n")

    print("🔍 正在发现跨项目关联...\n")
    links = discover_cross_project_links(graph, threshold=0.35)

    format_discovery(links)

    print(f"\n📊 统计：发现 {len(links)} 个跨项目关联")


def main():
    if len(sys.argv) < 2:
        print("用法：")
        print("  llm-wiki context <concept> [--format json]  - 查看概念的完整上下文和联想推荐")
        print("  llm-wiki discover                           - 发现跨项目的草蛇灰线连接")
        print("")
        print("选项：")
        print("  --format json   输出 JSON 格式（用于被其他 Skill 调用）")
        print("  --format human  输出人类可读格式（默认）")
        sys.exit(1)

    command = sys.argv[1]

    if command == 'context':
        if len(sys.argv) < 3:
            print("❌ 请指定概念名称")
            sys.exit(1)

        concept_name = sys.argv[2]
        output_format = 'human'

        # 解析可选参数
        if len(sys.argv) > 3 and sys.argv[3] == '--format' and len(sys.argv) > 4:
            output_format = sys.argv[4]

        cmd_context(concept_name, output_format=output_format)

    elif command == 'discover':
        cmd_discover()

    else:
        print(f"❌ 未知命令：{command}")
        sys.exit(1)


if __name__ == '__main__':
    main()
