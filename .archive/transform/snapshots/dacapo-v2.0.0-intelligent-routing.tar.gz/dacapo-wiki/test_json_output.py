#!/usr/bin/env python3
"""
测试 llm-wiki JSON 输出格式
模拟 dacapo-dispatch 的调用方式
"""

import subprocess
import json
import sys

def test_json_output():
    """测试 JSON 输出"""
    print("🧪 测试 llm-wiki JSON 输出\n")

    # 测试用例 1: 存在的概念
    print("测试 1: 查询存在的概念 (harness)")
    result = subprocess.run(
        ["python3", "llm-wiki.py", "context", "harness", "--format", "json"],
        capture_output=True,
        text=True,
        cwd="/Users/housibo/.openclaw-autoclaw/skills/dacapo-wiki"
    )

    if result.returncode == 0:
        try:
            data = json.loads(result.stdout)
            print("✅ JSON 解析成功")
            print(f"   概念名称: {data['target']['name']}")
            print(f"   项目: {data['target']['project']}")
            print(f"   掌握度: {data['target']['mastery']}")
            print(f"   推荐数量: {len(data['suggestions'])}")

            if data['suggestions']:
                print(f"   首个推荐: {data['suggestions'][0]['concept']['name']}")
                print(f"   推荐类型: {data['suggestions'][0]['type']}")
                print(f"   相似度: {data['suggestions'][0]['similarity']:.2f}")
        except json.JSONDecodeError as e:
            print(f"❌ JSON 解析失败: {e}")
            return False
    else:
        print(f"❌ 命令执行失败: {result.stderr}")
        return False

    print()

    # 测试用例 2: 不存在的概念
    print("测试 2: 查询不存在的概念 (nonexistent)")
    result = subprocess.run(
        ["python3", "llm-wiki.py", "context", "nonexistent", "--format", "json"],
        capture_output=True,
        text=True,
        cwd="/Users/housibo/.openclaw-autoclaw/skills/dacapo-wiki"
    )

    if result.returncode == 0:
        try:
            data = json.loads(result.stdout)
            if "error" in data:
                print("✅ 错误处理正确")
                print(f"   错误信息: {data['error']}")
            else:
                print("❌ 应该返回错误，但没有")
                return False
        except json.JSONDecodeError as e:
            print(f"❌ JSON 解析失败: {e}")
            return False

    print()

    # 测试用例 3: 向后兼容（不带 --format 参数）
    print("测试 3: 向后兼容（人类可读输出）")
    result = subprocess.run(
        ["python3", "llm-wiki.py", "context", "harness"],
        capture_output=True,
        text=True,
        cwd="/Users/housibo/.openclaw-autoclaw/skills/dacapo-wiki"
    )

    if result.returncode == 0:
        # 人类可读输出不应该是 JSON
        if "📖 概念上下文" in result.stdout:
            print("✅ 人类可读输出正常")
        else:
            print("❌ 人类可读输出格式不正确")
            return False
    else:
        print(f"❌ 命令执行失败: {result.stderr}")
        return False

    print()
    print("🎉 所有测试通过！")
    return True

if __name__ == '__main__':
    success = test_json_output()
    sys.exit(0 if success else 1)
