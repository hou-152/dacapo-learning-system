# dacapo-wiki 集成指南

本文档说明如何在其他 Skill 中调用 `dacapo-wiki` 获取学习上下文。

## 快速开始

```python
import subprocess
import json

def get_concept_context(concept_name: str) -> dict:
    """获取概念的学习上下文"""
    result = subprocess.run(
        ["llm-wiki", "context", concept_name, "--format", "json"],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        return {"error": "llm-wiki 调用失败"}
    
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"error": "JSON 解析失败"}

# 使用示例
context = get_concept_context("harness")

if "error" not in context:
    target = context["target"]
    print(f"概念：{target['name']}")
    print(f"掌握度：{target['mastery']}")
    print(f"推荐：{len(context['suggestions'])} 个")
```

## 数据结构

### 成功响应

```json
{
  "target": {
    "name": "harness",
    "project": "根目录",
    "file_path": "/path/to/harness.md",
    "tags": ["concept"],
    "dependencies": ["context-engineering"],
    "inDegree": 3,
    "mastery": 0.75,
    "firstAppearance": "[[article-name]]",
    "definition": "概念定义...",
    "why": "为什么重要...",
    "wikilinks": ["link1", "link2"]
  },
  "suggestions": [
    {
      "concept": {
        "name": "related-concept",
        "project": "根目录",
        "mastery": 0.5,
        ...
      },
      "type": "downstream",
      "reason": "harness 的实际应用",
      "similarity": 0.85
    }
  ],
  "generated": "2024-01-15T10:30:00Z"
}
```

### 错误响应

```json
{
  "error": "概念不存在: unknown"
}
```

## 字段说明

### `target` (概念信息)

| 字段 | 类型 | 说明 | 可能为空 |
|------|------|------|----------|
| `name` | string | 概念名称 | ❌ |
| `project` | string | 所属项目 | ❌ |
| `file_path` | string | 文件完整路径 | ❌ |
| `tags` | string[] | 标签列表 | ✅ |
| `dependencies` | string[] | 前置概念 | ✅ |
| `inDegree` | number | 被引用次数 | ❌ |
| `mastery` | number\|null | 掌握度 (0-1) | ✅ |
| `firstAppearance` | string\|null | 首次出现来源 | ✅ |
| `definition` | string | 定义 | ✅ |
| `why` | string | 重要性 | ✅ |
| `wikilinks` | string[] | 内部链接 | ✅ |

**重点**：
- `mastery` 为 `null` 表示未学习，不是错误
- `dependencies` 为空数组表示无前置概念
- `definition` 和 `why` 可能为空字符串（文件中未定义）

### `suggestions` (推荐列表)

每个推荐包含：

| 字段 | 类型 | 说明 |
|------|------|------|
| `concept` | object | 完整概念对象（结构同 `target`） |
| `type` | string | 推荐类型（见下表） |
| `reason` | string | 人类可读的推荐理由 |
| `similarity` | number | 相似度评分 (0-1) |
| `common_keywords` | string[] | 共同关键词（仅 semantic 类型） |

**推荐类型**：

| 类型 | 说明 | 优先级 |
|------|------|--------|
| `dependency` | 前置概念（必须先学） | 最高 |
| `downstream` | 下游概念（依赖当前概念） | 高 |
| `hub` | Hub 概念（被 3+ 概念引用） | 中 |
| `semantic` | 语义相似（跨项目关联） | 低 |

## 使用模式

### 模式 1: 检查学习状态

```python
def should_learn(concept_name: str) -> bool:
    """判断是否需要学习该概念"""
    context = get_concept_context(concept_name)
    
    if "error" in context:
        return False  # 概念不存在
    
    mastery = context["target"]["mastery"]
    
    # mastery 为 null 或低于阈值
    return mastery is None or mastery < 0.5
```

### 模式 2: 获取前置概念

```python
def get_prerequisites(concept_name: str) -> list[str]:
    """获取需要先学的前置概念"""
    context = get_concept_context(concept_name)
    
    if "error" in context:
        return []
    
    # 方法 1: 从 dependencies 获取
    deps = context["target"]["dependencies"]
    
    # 方法 2: 从推荐中筛选 dependency 类型
    dep_suggestions = [
        s["concept"]["name"] 
        for s in context["suggestions"] 
        if s["type"] == "dependency"
    ]
    
    return deps  # 或 dep_suggestions
```

### 模式 3: 构建学习提示

```python
def build_learning_prompt(concept_name: str) -> str:
    """构建学习上下文提示"""
    context = get_concept_context(concept_name)
    
    if "error" in context:
        return f"学习概念：{concept_name}"
    
    target = context["target"]
    suggestions = context["suggestions"]
    
    prompt = f"""
学习概念：{target['name']}

定义：{target['definition']}

重要性：{target['why']}

前置概念：{', '.join(target['dependencies']) if target['dependencies'] else '无'}

相关概念：
"""
    
    for s in suggestions[:3]:
        prompt += f"- {s['concept']['name']} ({s['type']}): {s['reason']}\n"
    
    return prompt
```

### 模式 4: 发现跨项目关联

```python
def find_cross_project_links(concept_name: str) -> list[dict]:
    """获取跨项目的草蛇灰线连接"""
    context = get_concept_context(concept_name)
    
    if "error" in context:
        return []
    
    target_project = context["target"]["project"]
    
    # 筛选 semantic 类型且来自不同项目的推荐
    cross_links = [
        {
            "name": s["concept"]["name"],
            "project": s["concept"]["project"],
            "similarity": s["similarity"],
            "keywords": s.get("common_keywords", [])
        }
        for s in context["suggestions"]
        if s["type"] == "semantic" and s["concept"]["project"] != target_project
    ]
    
    return cross_links
```

## 容错处理

### 推荐做法

```python
def safe_get_context(concept_name: str) -> dict:
    """安全获取上下文，失败不阻塞主流程"""
    try:
        context = get_concept_context(concept_name)
        
        # 检查错误
        if "error" in context:
            print(f"⚠️  {context['error']}")
            return None
        
        return context
        
    except Exception as e:
        print(f"⚠️  llm-wiki 调用失败: {e}")
        return None

# 使用示例
context = safe_get_context("harness")

if context:
    # 使用上下文
    mastery = context["target"]["mastery"]
    suggestions = context["suggestions"]
else:
    # 降级处理：不使用上下文，继续主流程
    mastery = None
    suggestions = []
```

### 不推荐的做法

```python
# ❌ 不要让 llm-wiki 失败阻塞主流程
context = get_concept_context("harness")
assert "error" not in context  # 这会导致整个流程失败

# ❌ 不要假设字段一定存在
definition = context["target"]["definition"]  # 可能为空字符串

# ❌ 不要假设一定有推荐
first_rec = context["suggestions"][0]  # 可能是空数组
```

## 性能考虑

- **首次加载**：扫描所有概念文件，约 2-3 秒（70 个概念）
- **后续调用**：每次都重新扫描（无缓存）
- **内存占用**：约 10 MB

**建议**：
- 不要在循环中频繁调用
- 如果需要批量查询，考虑一次性调用 `discover` 后解析结果
- 在 dispatch 层调用一次，结果传递给 learning 层

## 测试

使用提供的测试脚本：

```bash
cd ~/.openclaw-autoclaw/skills/dacapo-wiki
python3 test_json_output.py
```

预期输出：

```
🧪 测试 llm-wiki JSON 输出

测试 1: 查询存在的概念 (harness)
✅ JSON 解析成功
   概念名称: harness
   ...

测试 2: 查询不存在的概念 (nonexistent)
✅ 错误处理正确
   ...

测试 3: 向后兼容（人类可读输出）
✅ 人类可读输出正常

🎉 所有测试通过！
```

## 完整示例

参考 `dacapo-dispatch` 的实际集成：

```python
# Step 1: 获取上下文
context = safe_get_context(concept_name)

# Step 2: 提取关键信息
if context:
    mastery = context["target"]["mastery"]
    definition = context["target"]["definition"]
    dependencies = context["target"]["dependencies"]
    suggestions = context["suggestions"][:5]  # 前 5 个推荐
else:
    mastery = None
    definition = ""
    dependencies = []
    suggestions = []

# Step 3: 构建学习提示
prompt = build_learning_context(
    concept_name=concept_name,
    mastery=mastery,
    definition=definition,
    dependencies=dependencies,
    suggestions=suggestions
)

# Step 4: 传递给 dacapo-learning
result = call_skill("dacapo-learning", {
    "concept": concept_name,
    "context": prompt
})
```

## 常见问题

### Q: 为什么不缓存结果？

A: 概念文件可能随时更新（学习完成后更新 mastery），缓存会导致数据不一致。当前性能足够（2-3 秒），不需要缓存。

### Q: 如何处理 mastery 为 null？

A: `null` 表示未学习，是正常状态，不是错误。应该视为 0 处理。

### Q: suggestions 为空怎么办？

A: 空数组是合法返回，表示没有找到相关推荐。不影响主流程。

### Q: 调用失败会抛异常吗？

A: 不会。失败返回 `{"error": "..."}` 的 JSON，不抛异常。但 JSON 解析失败会抛 `JSONDecodeError`，调用方应捕获。

### Q: 支持批量查询吗？

A: 当前不支持。每次调用只查询一个概念。如需批量，在调用方循环或考虑用 `discover` 获取全局关联。
