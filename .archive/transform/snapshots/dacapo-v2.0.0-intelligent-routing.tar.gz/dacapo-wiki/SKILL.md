# llm-wiki - 概念探索和上下文挖掘引擎

**定位**：探索引擎，不是简单推荐系统。发现不同项目、不同学科之间的"草蛇灰线"连接。

**双模式运行**：
- **人类交互模式**：直接调用，输出友好的文本格式
- **API 模式**：通过 `--format json` 输出结构化数据，供其他 Skill 调用

## 核心能力

### 1. 跨项目探索
发现概念在不同项目、不同领域中的关联，识别隐藏的知识网络。

### 2. 上下文挖掘
从 Obsidian 概念文件中提取多层上下文：
- **Frontmatter**：tags、dependencies、inDegree、mastery、firstAppearance
- **Wikilink 网络**：双向链接、引用关系
- **内容**：定义、重要性、实际应用
- **来源**：首次出现的文章/课程

### 3. 联想发现
不只是相似度，包括多维度关联：
- **语义关联**：共享关键词、术语
- **结构关联**：依赖链、Hub 概念（被 3+ 概念引用）
- **历史关联**：同一来源、同一时期
- **标签关联**：共享 tags

### 4. 上下文传递
给 dispatch 和学习系统提供丰富的学习上下文：
- 已学相关概念（mastery > 0）
- 草蛇灰线连接
- 推荐学习路径

## 命令

### `/llm-wiki context <concept> [--format json|human]`

查看指定概念的完整上下文和联想推荐。

**参数**：
- `<concept>` — 概念名称（必需）
- `--format json` — 输出 JSON 格式（用于被其他 Skill 调用）
- `--format human` — 输出人类可读格式（默认）

**输出**：
- 概念基本信息（项目、文件路径、标签）
- 定义和重要性
- 前置概念和下游概念
- 内部链接网络
- 掌握度（如果有）
- **同项目推荐**（前置概念、下游概念、Hub 概念）
- **跨项目联想**（草蛇灰线）

**示例**：
```bash
# 人类可读输出
llm-wiki context harness

# JSON 输出（被调用模式）
llm-wiki context harness --format json
```

**输出示例**：
```
📖 概念上下文：harness
======================================================================

项目：根目录
文件：/Users/housibo/Documents/dacapo-学习仓库/concepts/harness.md
标签：concept
首次出现：[[01-Martin-Fowler-harness-engineering]]

定义：
全文的锚概念。作者说她喜欢用 harness 这个词来描述「the tooling and 
practices we can use to keep AI agents in check」——我们用来把 AI agent 
管住的工具与实践。它不是某一个工具，而是知识库、动态上下文、自定义 
linter、结构性测试、巡逻 agent 的总和。

为什么重要：
harness 原意是套在牲口身上的挽具——既限制它乱跑，又让它的力气能被用上...

被以下概念引用：context-engineering, ai-友好度作为选型标准

======================================================================

💡 基于「harness」的联想推荐

来自项目：根目录
定义：全文的锚概念。作者说她喜欢用 harness 这个词来描述...

======================================================================

✅ 同项目推荐（根目录）：

1. context-engineering （相似度: 0.85）
   类型：downstream
   原因：harness 的实际应用
   📁 /Users/housibo/Documents/dacapo-学习仓库/concepts/context-engineering.md

2. 拓扑作为新抽象层 （相似度: 0.75）
   类型：hub
   原因：Hub 概念（被 3 个概念引用）
   📁 /Users/housibo/Documents/dacapo-学习仓库/concepts/拓扑作为新抽象层.md

🔗 跨项目联想（草蛇灰线）：

1. 工程治理 （来自：泛化测试-直播稿）
   相似度：0.42
   原因：关键词重叠（5 个）
   关键词：工程, ai, agent, 管理, 方法
   📁 /Users/housibo/Documents/dacapo-学习仓库/泛化测试-直播稿/concepts/工程治理.md

2. 熔炉系统 （来自：泛化测试-直播稿）
   相似度：0.38
   原因：关键词重叠（4 个）
   关键词：系统, 工具, 实践, 结构
   📁 /Users/housibo/Documents/dacapo-学习仓库/泛化测试-直播稿/concepts/熔炉系统.md
```

### `/llm-wiki discover`

全局扫描所有项目，发现跨项目的草蛇灰线连接。

**输出**：
- 按项目对分组的跨项目关联
- 相似度评分
- 关联原因（名称相似、关键词重叠、共享来源、共享标签）
- 共同关键词

**示例**：
```bash
llm-wiki discover
```

**输出示例**：
```
🔍 跨项目草蛇灰线发现

======================================================================

📁 根目录 ↔ 泛化测试-直播稿
----------------------------------------------------------------------

• harness ↔ 工程治理
  相似度：0.42
  关联：关键词重叠（5 个）
  关键词：工程, ai, agent, 管理, 实践, 方法

• context-engineering ↔ 认知
  相似度：0.39
  关联：关键词重叠（4 个）
  关键词：context, 工程, 设计, 方法

📁 根目录 ↔ AI实战营-从Demo到产品
----------------------------------------------------------------------

• harness ↔ ai-native
  相似度：0.36
  关联：关键词重叠（3 个）; 共享标签: 元习惯
  关键词：ai, 方法, 标准

📊 统计：发现 12 个跨项目关联
```

## 数据来源

- **学习仓库路径**：`~/Documents/dacapo-学习仓库/`
- **概念文件**：所有项目下的 `concepts/*.md` 文件
- **文件格式**：Obsidian 原生 Markdown，frontmatter + 正文

**支持的项目**：
- 根目录 concepts（AI 内参等主题）
- AI实战营-从Demo到产品
- AI实战营-前沿速递
- 泛化测试-直播稿
- 泛化测试-A类-陌生领域
- 泛化测试-B类-低结构化
- 泛化测试-C类-多模态

## 相似度计算

采用多维度规则匹配：

```python
相似度 = 名称相似(30%) + 关键词重叠(40%) + 来源重叠(20%) + 标签重叠(10%)
```

### 1. 名称相似（30%）
- 概念 A 的名称包含概念 B，或反之
- 示例：harness ↔ deepseek-harness

### 2. 关键词重叠（40%）
- 从定义和重要性中提取关键词
- 计算交集 / 并集比例
- 过滤停用词

### 3. 来源重叠（20%）
- 检查 `firstAppearance` 字段
- 来自同一文章/课程 → +20%

### 4. 标签重叠（10%）
- 检查 frontmatter 中的 `tags`
- 共享标签数量 / 最大标签数量

**阈值**：
- 推荐阈值：0.30
- 发现阈值：0.35

## 技术实现

### 概念解析

支持多种 frontmatter 字段：

```yaml
---
tags: [concept, 元习惯]
dependencies: [context-engineering, harness]
inDegree: 3
mastery: 0.75
firstAppearance: "[[01-Martin-Fowler-harness-engineering]]"
---
```

也支持中文字段：

```yaml
---
标签: [概念]
前置概念: [上下文工程]
被引用次数: 3
掌握度: 0.75
首次出现: AI内参第3期
---
```

### 内容提取

- **定义**：从 `# 定义`、`# Definition`、`# Context`、`# 费曼一下` 章节提取
- **重要性**：从 `# 为什么重要`、`# Why`、`# 重要性` 章节提取
- **Wikilinks**：提取所有 `[[...]]` 链接

### 关键词提取

- **英文**：提取单词（2+ 字符）
- **中文**：提取短语（2-4 字）
- **过滤**：停用词、单字符词

### 图谱结构

```python
class ConceptGraph:
    concepts: Dict[str, Concept]      # name -> Concept
    projects: Dict[str, List[str]]    # project -> [concept_names]
    
    def get_dependents(concept_name) -> List[str]
    def is_hub(concept_name) -> bool
```

## 性能

- **扫描速度**：~70 个概念文件 < 3 秒
- **内存占用**：~10 MB（70 个概念）
- **推荐延迟**：单个概念 < 1 秒

## 容错设计

1. **文件解析失败**：跳过该文件，输出警告，不影响其他概念
2. **Frontmatter 缺失**：使用默认值，仍能提取内容和 wikilinks
3. **空项目**：跳过没有 concepts 目录的项目
4. **隐藏目录**：自动跳过 `.claude`、`.git`、`.obsidian`

## 与其他 Skill 的关系

### dbs-learning（学习进度）

dbs-learning 完成概念学习后，可以调用 llm-wiki 获取联想推荐：

```bash
# dbs-learning 内部调用
llm-wiki context harness > .learning-progress/context-harness.txt
```

### interactive-learning-dispatch（路由器）

dispatch 可以利用 llm-wiki 的上下文信息：

```bash
# 查询某概念的学习上下文
llm-wiki context <concept> | grep "前置概念"
```

### dacapo-visualize（可视化）

visualize 可以读取 llm-wiki 发现的跨项目关联，生成可视化图谱。

## 被调用模式（API 接口）

### 使用场景

当 `dacapo-dispatch` 或 `dacapo-learning` 需要获取历史学习上下文时，通过 JSON 格式调用本 Skill。

### 调用方式

```bash
llm-wiki context <concept> --format json
```

### 输出格式（JSON）

```json
{
  "target": {
    "name": "harness",
    "project": "根目录",
    "file_path": "/Users/housibo/Documents/dacapo-学习仓库/concepts/harness.md",
    "tags": ["concept"],
    "dependencies": ["context-engineering"],
    "inDegree": 3,
    "mastery": 0.75,
    "firstAppearance": "[[01-Martin-Fowler-harness-engineering]]",
    "definition": "全文的锚概念。作者说她喜欢用 harness 这个词...",
    "why": "harness 原意是套在牲口身上的挽具...",
    "wikilinks": ["context-engineering", "ai-友好度作为选型标准"]
  },
  "suggestions": [
    {
      "concept": {
        "name": "context-engineering",
        "project": "根目录",
        "file_path": "/Users/housibo/Documents/dacapo-学习仓库/concepts/context-engineering.md",
        "mastery": 0.5,
        ...
      },
      "type": "downstream",
      "reason": "harness 的实际应用",
      "similarity": 0.85
    },
    {
      "concept": {
        "name": "工程治理",
        "project": "泛化测试-直播稿",
        ...
      },
      "type": "semantic",
      "reason": "关键词重叠（5 个）",
      "similarity": 0.42,
      "common_keywords": ["工程", "ai", "agent", "管理", "方法"]
    }
  ],
  "generated": "2024-01-15T10:30:00Z"
}
```

### 输出说明

#### `target` 字段
- `name` — 概念名称
- `project` — 所属项目
- `file_path` — 概念文件完整路径
- `tags` — 标签列表
- `dependencies` — 前置概念列表
- `inDegree` — 被引用次数
- `mastery` — 掌握度（0-1，null 表示未学习）
- `firstAppearance` — 首次出现的文章/课程
- `definition` — 定义（从 `# 定义` 章节提取）
- `why` — 重要性（从 `# 为什么重要` 章节提取）
- `wikilinks` — 内部链接列表

#### `suggestions` 字段
推荐概念列表，每个推荐包含：
- `concept` — 推荐的概念对象（结构同 `target`）
- `type` — 推荐类型：
  - `dependency` — 前置概念
  - `downstream` — 下游概念（依赖当前概念的）
  - `hub` — Hub 概念（被 3+ 概念引用）
  - `semantic` — 语义相似概念（跨项目关联）
- `reason` — 推荐理由（人类可读）
- `similarity` — 相似度评分（0-1）
- `common_keywords` — 共同关键词（仅 `semantic` 类型）

#### `generated` 字段
生成时间戳（ISO 8601 格式）

### 集成示例（dacapo-dispatch）

```python
import subprocess
import json

def get_concept_context(concept_name: str) -> dict:
    """获取概念的学习上下文"""
    result = subprocess.run(
        ["llm-wiki", "context", concept_name, "--format", "json"],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        return {"error": "llm-wiki 调用失败"}
    
    return json.loads(result.stdout)

# 使用示例
context = get_concept_context("harness")

if "error" not in context:
    target = context["target"]
    suggestions = context["suggestions"]
    
    print(f"概念：{target['name']}")
    print(f"掌握度：{target['mastery']}")
    print(f"推荐 {len(suggestions)} 个相关概念")
```

### 容错处理

**概念不存在**：
```json
{
  "error": "概念不存在: unknown-concept"
}
```

**调用方应该**：
1. 检查 `error` 字段
2. `mastery` 为 `null` 表示未学习
3. `suggestions` 可能为空列表
4. llm-wiki 失败不应阻塞主流程

## 扩展方向

未来可以支持（当前 MVP 不实现）：

### 1. 学习路径生成
基于依赖关系和 mastery，推荐最优学习顺序。

### 2. 学习孤岛检测
发现未被依赖、未被链接的概念（可能需要补充关联）。

### 3. 概念聚类
按语义相似度自动聚类，发现隐含的主题。

### 4. 时间维度分析
基于学习历史，推荐"该复习的概念"。

### 5. 个性化推荐
基于用户的 mastery 和学习历史，调整推荐权重。

## DaCapo Learn 数据流

```
用户输入
  ↓
dacapo-main (统一入口)
  ↓
dacapo-dispatch (智能路由)
  ↓
┌─────────────────────────────────────┐
│ llm-wiki context <concept> --format json
│ 
│ 返回：
│ {
│   "target": {概念信息 + 掌握度},
│   "suggestions": [{推荐概念列表}]
│ }
└─────────────────────────────────────┘
  ↓
dacapo-learning (交互式学习)
  ↓
更新 frontmatter (mastery)
```

### 接口契约

**输入**：
- `<concept>` — 概念名称（必需）
- `--format json` — 输出格式（可选，默认 human）

**输出（JSON 格式）**：
```json
{
  "target": {
    "name": string,
    "project": string,
    "file_path": string,
    "mastery": number | null,
    "definition": string,
    "dependencies": string[],
    ...
  },
  "suggestions": [
    {
      "concept": {...},
      "type": "dependency" | "downstream" | "hub" | "semantic",
      "similarity": number,
      "reason": string
    }
  ],
  "generated": string (ISO 8601)
}
```

**错误输出**：
```json
{
  "error": string
}
```

**保证**：
1. JSON 输出可解析（valid JSON）
2. `mastery` 为 `null` 表示未学习，不是概念不存在
3. `suggestions` 可能为空数组（无推荐）
4. 失败返回 `{"error": "..."}` 而非异常退出

## 测试用例

### 用例 1：从 harness 探索

**命令**：
```bash
llm-wiki context harness
```

**预期**：
- 找到同项目的 context-engineering（下游概念）
- 发现跨项目关联：工程治理（泛化测试-直播稿）
- 相似度 > 0.3，有共同关键词

### 用例 2：全局发现

**命令**：
```bash
llm-wiki discover
```

**预期**：
- 发现至少 10 个跨项目关联
- 按项目对分组
- 相似度 > 0.35

### 用例 3：容错测试

**场景**：某个概念文件损坏

**预期**：
- 输出警告信息
- 其他概念正常加载
- 程序不崩溃

## 安装与运行

### 安装

将 `llm-wiki.py` 放到 `~/.openclaw-autoclaw/skills/llm-wiki/` 目录：

```bash
chmod +x ~/.openclaw-autoclaw/skills/llm-wiki/llm-wiki.py
```

### 运行

```bash
# 查看概念上下文
~/.openclaw-autoclaw/skills/llm-wiki/llm-wiki.py context harness

# 发现跨项目关联
~/.openclaw-autoclaw/skills/llm-wiki/llm-wiki.py discover
```

### 作为 Skill 调用

Claude Code 会自动发现该 skill：

```
/llm-wiki context harness
/llm-wiki discover
```

## 限制

1. **仅支持 Markdown**：不解析其他格式（PDF、docx）
2. **简单关键词提取**：不使用 NLP 库，可能漏掉语义相似但词不同的概念
3. **静态快照**：不实时监控文件变化，需要重新运行
4. **中文分词简化**：按 2-4 字提取，不是真正的分词

## 设计原则

1. **轻量级**：纯 Python 标准库，无外部依赖
2. **规则优先**：不引入复杂算法，保持可解释性
3. **容错为先**：单个文件失败不影响整体
4. **快速响应**：秒级返回结果
5. **可扩展**：清晰的类结构，方便后续增强
