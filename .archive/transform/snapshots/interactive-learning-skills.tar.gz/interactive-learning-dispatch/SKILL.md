# interactive-learning-dispatch

**作用**：交互式学习的统一入口，负责判断用户学习意图并路由到对应 Skill。

## 核心职责

像 qiuzhi-dispatch 一样，这是导航层：
1. 解析用户的学习请求
2. 定位目标概念和学习仓库
3. 路由到对应的执行 Skill
4. 生成可直接发送的提示词

## 路由规则

### 场景 1：开始学习某个概念
**触发词**：「学习」「了解」「掌握」+ 概念名
**路由到**：`/dbs-learning <concept>`
**示例**：
- 用户："我想学习 harness 概念"
- 路由：`/dbs-learning harness`

### 场景 2：查看学习进度
**触发词**：「进度」「学到哪了」「掌握情况」
**路由到**：`/dbs-learning status`

### 场景 3：查看联想推荐
**触发词**：「推荐」「还能学什么」「相关概念」
**路由到**：`/dbs-learning suggestions`

### 场景 4：探索概念网络
**触发词**：「有哪些概念」「概念地图」「整体结构」
**路由到**：`/dacapo-visualize`

### 场景 5：发现跨项目关联
**触发词**：「发现」「关联」「联想」
**路由到**：`/llm-wiki discover`

## 执行流程

```
用户输入
  ↓
读取学习仓库真源（SOURCE_OF_TRUTH.md）
  ↓
识别意图 + 定位概念
  ↓
调用 llm-wiki 获取学习上下文
  ├─ 前面学过的相关概念
  ├─ 掌握度信息
  └─ 推荐的学习路径
  ↓
生成可直接发送的提示词（包含已定位事实 + 学习上下文）
  ↓
交回用户复制发送
```

## 调用示例

**用户**："我想学习 AI 内参里的 agent 概念"

**输出**：

---

**推荐：`/dbs-learning agent`**

**选择理由**：你要开始学习特定概念——dbs-learning 通过简单问答评估掌握度，并将结果记录到概念文件的 frontmatter 中。

**已定位的事实**：
- 〔概念位置｜`~/Documents/dacapo-学习仓库/AI内参/concepts/agent.md`〕概念已存在
- 〔依赖关系｜同上 frontmatter〕该概念依赖：harness、context-engineering
- 〔当前进度｜同上 frontmatter〕mastery 字段为 null（首次学习）
- 〔学习上下文｜llm-wiki 提供〕你之前学过 harness（掌握度 75%），可以用来理解 agent

**边界**：学习完成后 dbs-learning 自动触发 llm-wiki 后台推送（静默执行，写入 `.learning-progress/suggestions.json`），不打断当前学习流程。

---

**可直接发送的提示词**：

> 使用 `/dbs-learning agent`。
> 
> 我要学习「AI 内参」项目中的 agent 概念。
> 
> **学习上下文（llm-wiki 提供）**：
> - 你之前学过 harness（掌握度 75%），agent 是在 harness 之上的执行单元
> - 你之前学过 context-engineering（掌握度 30%），建议先复习
> - 这 3 个概念形成链条：context-engineering → harness → agent
> 
> 请执行交互式学习流程：
> 1. 读取概念文件 `~/Documents/dacapo-学习仓库/AI内参/concepts/agent.md`
> 2. 检查依赖（harness、context-engineering）的掌握度，利用已学概念帮助理解
> 3. 通过 2 个问题评估我的当前掌握度
> 4. 根据评估结果给出学习建议，**关联我之前学过的 harness 概念**
> 5. 将掌握度（mastery）和学习时间（lastStudied）写入概念文件的 frontmatter
> 6. 完成后触发 llm-wiki 后台推送（静默执行，不阻塞）
> 
> 已定位事实：
> - 概念文件存在，包含定义和 3 次 appearances 记录
> - 该概念被 5 个其他概念依赖（inDegree: 5）
> - 当前 mastery 字段为 null，这是首次学习
> - **你之前学过 harness，可以用来类比理解 agent**

把上面引用块整段复制发送即可。发出去之后由 dbs-learning 接管交互式学习，它会利用你之前学过的概念（复利效应）来帮助你理解新概念。

---

## 技术细节

### 定位逻辑
1. 读取 `~/Documents/dacapo-学习仓库/SOURCE_OF_TRUTH.md`
2. 扫描所有项目的 `concepts/` 目录
3. 匹配概念名（模糊匹配 + 别名）
4. 读取概念文件的 frontmatter（dependencies、inDegree）

### 进度查询
- 读取概念文件 frontmatter 中的 `mastery` 和 `lastStudied` 字段
- 格式：
```yaml
---
name: agent
dependencies: [harness, context-engineering]
inDegree: 5
mastery: 0.75
lastStudied: 2026-09-12T14:30:00Z
studyCount: 2
---
```

### 边界处理
- 概念不存在 → 提示可用概念列表
- 依赖未满足 → 推荐先学依赖项
- 已完全掌握（mastery ≥ 0.9）→ 推荐复习或学习关联概念

## 与其他 Skill 的关系

- **dbs-learning**：执行层，负责实际的交互式学习
- **llm-wiki**：后台层，静默推送联想推荐
- **dacapo-***：数据层，提供概念网络和知识图谱
- **interactive-learning-dispatch**：导航层（本 Skill），负责路由

## 约定

1. **只生成提示词，不执行**：像 qiuzhi-dispatch，输出的是「可直接发送的提示词」
2. **定位事实必须真实**：从文件读取，不推测
3. **边界必须明确**：告诉用户哪些会自动执行，哪些需要确认
4. **保持轻量**：dispatch 只做判断和定位，重活交给执行 Skill
