# dbs-learning - 概念学习对话

**作用**：通过简单问答评估概念掌握度，记录到概念文件的 frontmatter 中。

## 使用场景

用户想学习某个概念时：
```
/dbs-learning harness
```

系统会：
1. 读取 `concepts/harness.md`
2. 问 2-3 个问题评估理解
3. 将掌握度写入 frontmatter：`mastery: 0.75`
4. 根据掌握度给出学习建议

## 执行流程

### 1. 读取概念文件
```yaml
# concepts/harness.md frontmatter
---
name: harness
dependencies: [context-engineering]
inDegree: 3
mastery: null  # 首次学习为 null
lastStudied: null
---
```

### 2. 掌握度评估（2 个问题）

**问题 1**：「用一句话说说你理解的 {concept} 是什么？」

(用户回答后，基于关键词匹配给出分数 0-1)

**问题 2**：「能举个你见过的例子吗？」

(检查是否提到 appearances 中的来源)

平均分 = (问题1分数 + 问题2分数) / 2

### 3. 更新 frontmatter

```yaml
---
name: harness
dependencies: [context-engineering]
inDegree: 3
mastery: 0.65  # 新增
lastStudied: 2026-09-12T15:30:00Z  # 新增
---
```

### 4. 给出学习建议

- mastery < 0.5：建议先学习依赖概念，或重读概念定义
- mastery 0.5-0.8：建议查看 appearances 中的实际案例
- mastery > 0.8：建议学习下游概念（被依赖的概念）

### 5. 触发 llm-wiki（静默）

在后台调用 llm-wiki 生成联想推荐，不阻塞当前对话。

## 输出示例

```markdown
## 学习概念：harness

### 问题 1
用一句话说说你理解的 harness 是什么？

> (用户输入：Claude Code 的权限控制和工具调用层)

✓ 评分：0.7 (包含核心关键词：权限、工具)

### 问题 2
能举个你见过的例子吗？

> (用户输入：AI 内参里提到的 tool-use)

✓ 评分：0.6 (提到了相关来源)

---

### 掌握度：65% (学习中)

建议下一步：
1. 查看 harness 在「AI 内参」中的实际出现（3 次）
2. 学习依赖概念：context-engineering (你还未学习)

已更新概念文件的 mastery 字段 ✓
后台已触发联想推荐 (使用 `/dbs-learning suggestions` 查看)
```

## 数据结构

**全部数据都在概念文件的 frontmatter 中**，不需要额外的 JSON 文件：

```yaml
---
name: agent
dependencies: [harness, context-engineering]
inDegree: 5
mastery: 0.75
lastStudied: 2026-09-12T15:30:00Z
studyCount: 2
---
```

**联想推荐缓存**（可选，仅用于 llm-wiki）：
- 位置：`~/Documents/dacapo-学习仓库/.learning-progress/suggestions.json`
- 由 llm-wiki 后台写入，dbs-learning 只读取显示

## 命令

### `/dbs-learning <concept>`
开始学习指定概念（主命令）

### `/dbs-learning status`
查看所有概念的掌握度总览：
```markdown
已掌握 (mastery ≥ 0.8): harness, agent
学习中 (0.3-0.8): context-engineering
未学习: 其余 12 个
```

### `/dbs-learning suggestions`
查看 llm-wiki 的联想推荐（如果有）

## 轻量化原则

1. **不做复杂状态机**：没有多轮对话、没有 agent loop
2. **数据在 Obsidian**：利用 frontmatter，不建新数据库
3. **评估靠规则**：简单关键词匹配，不用 ML
4. **2 个问题足够**：不追求精确评估，快速给反馈
5. **后台推送异步**：llm-wiki 失败不影响学习

## 与其他 Skill 的关系

- **interactive-learning-dispatch** → 路由到本 Skill
- **本 Skill** → 评估 + 记录
- **llm-wiki** ← 本 Skill 触发（后台静默）
- **dacapo-visualize** ← 读取 mastery 字段，可视化学习路径
