#!/usr/bin/env python3
"""
llm-wiki - 联想学习系统
基于概念图谱的跨项目概念推荐
"""

import json
import os
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple
from collections import defaultdict


# 停用词列表
STOP_WORDS = {
    # 中文停用词
    '的', '是', '在', '和', '与', '或', '等', '也', '就', '而', '有', '为', '这', '那',
    '它', '把', '被', '从', '到', '将', '会', '可以', '能够', '需要', '什么', '如何',
    # 英文停用词
    'the', 'is', 'at', 'which', 'on', 'a', 'an', 'as', 'are', 'was', 'were',
    'for', 'to', 'of', 'in', 'by', 'with', 'from', 'that', 'this', 'it',
}


class ConceptGraph:
    """概念图谱"""

    def __init__(self):
        self.concepts = {}  # id -> concept
        self.projects = {}  # project_name -> [concept_ids]

    def add_concept(self, concept_id: str, concept: dict, project: str):
        """添加概念"""
        self.concepts[concept_id] = {
            **concept,
            'id': concept_id,
            'project': project,
        }

        if project not in self.projects:
            self.projects[project] = []
        self.projects[project].append(concept_id)

    def get_concept(self, concept_id: str) -> dict:
        """获取概念"""
        return self.concepts.get(concept_id)

    def find_concept_by_name(self, name: str) -> dict:
        """通过名称查找概念"""
        for cid, concept in self.concepts.items():
            if concept.get('name', '').lower() == name.lower() or cid.lower() == name.lower():
                return concept
        return None

    def get_prerequisites(self, concept_id: str) -> List[str]:
        """获取前置概念"""
        concept = self.get_concept(concept_id)
        if not concept:
            return []
        return concept.get('prerequisites', []) or concept.get('前置', []) or []

    def get_dependents(self, concept_id: str) -> List[str]:
        """获取依赖该概念的其他概念"""
        dependents = []
        for cid, concept in self.concepts.items():
            prereqs = concept.get('prerequisites', []) or concept.get('前置', []) or []
            if concept_id in prereqs:
                dependents.append(cid)
        return dependents

    def is_hub(self, concept_id: str) -> bool:
        """判断是否为 Hub 概念"""
        concept = self.get_concept(concept_id)
        if not concept:
            return False

        # 检查 hub 标记
        if concept.get('hub'):
            return True

        # 检查 inDegree
        in_degree = concept.get('inDegree', 0)
        return in_degree >= 3

    def get_hubs_in_project(self, project: str) -> List[str]:
        """获取项目中的 Hub 概念"""
        concept_ids = self.projects.get(project, [])
        return [cid for cid in concept_ids if self.is_hub(cid)]


def extract_keywords(text: str) -> Set[str]:
    """提取关键词"""
    if not text:
        return set()

    # 分词（简单版本）
    # 中文：按标点分割
    # 英文：按空格分割
    words = []

    # 提取英文单词
    english_words = re.findall(r'\b[a-zA-Z][a-zA-Z0-9_-]*\b', text)
    words.extend(english_words)

    # 提取中文词（2-4字）
    chinese_phrases = re.findall(r'[一-鿿]{2,4}', text)
    words.extend(chinese_phrases)

    # 过滤停用词
    keywords = {w.lower() for w in words if w.lower() not in STOP_WORDS and len(w) > 1}

    return keywords


def calculate_similarity(concept_a: dict, concept_b: dict) -> Tuple[float, Set[str]]:
    """计算两个概念的相似度"""
    text_a = f"{concept_a.get('name', '')} {concept_a.get('definition', '')}"
    text_b = f"{concept_b.get('name', '')} {concept_b.get('definition', '')}"

    keywords_a = extract_keywords(text_a)
    keywords_b = extract_keywords(text_b)

    if not keywords_a or not keywords_b:
        return 0.0, set()

    intersection = keywords_a & keywords_b
    union = keywords_a | keywords_b

    similarity = len(intersection) / len(union) if union else 0.0

    return similarity, intersection


def load_dacapo_concepts(base_path: Path) -> Dict[str, dict]:
    """加载 dacapo 风格的概念数据"""
    concepts = {}

    schema_file = base_path / 'schema' / 'concepts.json'
    if schema_file.exists():
        with open(schema_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if 'nodes' in data:
                for node in data['nodes']:
                    concept_id = node['id']
                    concepts[concept_id] = node

    return concepts


def load_knowledge_concepts(base_path: Path) -> Dict[str, dict]:
    """加载知识生产风格的概念数据"""
    concepts = {}

    concepts_file = base_path / 'concepts' / 'concepts-index.json'
    if concepts_file.exists():
        with open(concepts_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            for concept_id, concept in data.items():
                concepts[concept_id] = concept

    return concepts


def load_all_concepts(base_dir: str = '/Users/housibo/Documents/交互式学习') -> ConceptGraph:
    """加载所有项目的概念"""
    graph = ConceptGraph()
    base_path = Path(base_dir)

    # 查找所有包含概念数据的项目
    for item in base_path.iterdir():
        if not item.is_dir() or item.name.startswith('.'):
            continue

        project_name = item.name

        # 尝试加载 dacapo 风格
        concepts = load_dacapo_concepts(item)
        if concepts:
            for cid, concept in concepts.items():
                graph.add_concept(cid, concept, project_name)
            continue

        # 尝试加载知识生产风格
        concepts = load_knowledge_concepts(item)
        if concepts:
            for cid, concept in concepts.items():
                graph.add_concept(cid, concept, project_name)

    return graph


def suggest_concepts(graph: ConceptGraph, target_concept_id: str) -> dict:
    """基于某个概念推荐相关概念"""
    target = graph.get_concept(target_concept_id)
    if not target:
        # 尝试通过名称查找
        target = graph.find_concept_by_name(target_concept_id)
        if not target:
            return {'error': f'未找到概念：{target_concept_id}'}
        target_concept_id = target['id']

    recommendations = {
        'target': target,
        'same_project': [],
        'cross_project': [],
        'learning_path': [],
    }

    target_project = target['project']

    # 1. 同项目推荐

    # 前置概念
    prerequisites = graph.get_prerequisites(target_concept_id)
    for prereq_id in prerequisites:
        prereq = graph.get_concept(prereq_id)
        if prereq:
            recommendations['same_project'].append({
                'concept': prereq,
                'relationship': '前置概念',
                'reason': f'理解 {target["name"]} 的基础',
            })

    # 依赖该概念的其他概念
    dependents = graph.get_dependents(target_concept_id)
    for dep_id in dependents:
        dep = graph.get_concept(dep_id)
        if dep:
            recommendations['same_project'].append({
                'concept': dep,
                'relationship': f'引用了 {target["name"]}',
                'reason': f'{target["name"]} 的实际应用',
            })

    # Hub 概念
    hubs = graph.get_hubs_in_project(target_project)
    for hub_id in hubs:
        if hub_id == target_concept_id:
            continue
        hub = graph.get_concept(hub_id)
        if hub and hub_id not in prerequisites and hub_id not in dependents:
            recommendations['same_project'].append({
                'concept': hub,
                'relationship': f'Hub 概念 (inDegree: {hub.get("inDegree", 0)})',
                'reason': f'理解 {target["name"]} 在整体架构中的位置',
            })

    # 2. 跨项目推荐
    cross_project_candidates = []

    for cid, concept in graph.concepts.items():
        if concept['project'] == target_project:
            continue

        similarity, common_keywords = calculate_similarity(target, concept)

        if similarity > 0.3:  # 相似度阈值
            cross_project_candidates.append({
                'concept': concept,
                'similarity': similarity,
                'common_keywords': common_keywords,
            })

    # 按相似度排序
    cross_project_candidates.sort(key=lambda x: x['similarity'], reverse=True)

    # 取前 3 个
    recommendations['cross_project'] = cross_project_candidates[:3]

    # 3. 生成学习路径
    learning_path = []

    # 优先学习前置概念
    if prerequisites:
        for prereq_id in prerequisites[:2]:  # 最多 2 个
            prereq = graph.get_concept(prereq_id)
            if prereq:
                learning_path.append({
                    'step': len(learning_path) + 1,
                    'concept': prereq,
                    'reason': f'理解 {target["name"]} 的基础知识',
                })

    # 然后是 Hub 概念
    if hubs:
        hub_id = hubs[0]
        if hub_id not in prerequisites:
            hub = graph.get_concept(hub_id)
            if hub:
                learning_path.append({
                    'step': len(learning_path) + 1,
                    'concept': hub,
                    'reason': f'理解 {target["name"]} 在整体架构中的位置',
                })

    # 最后是跨项目概念
    if cross_project_candidates:
        learning_path.append({
            'step': len(learning_path) + 1,
            'concept': cross_project_candidates[0]['concept'],
            'reason': '探索跨领域应用',
        })

    recommendations['learning_path'] = learning_path

    return recommendations


def discover_cross_project_links(graph: ConceptGraph, threshold: float = 0.3) -> List[dict]:
    """发现跨项目概念关联"""
    links = []

    projects = list(graph.projects.keys())

    for i, project_a in enumerate(projects):
        for project_b in projects[i+1:]:
            concepts_a = graph.projects[project_a]
            concepts_b = graph.projects[project_b]

            for cid_a in concepts_a:
                concept_a = graph.get_concept(cid_a)

                for cid_b in concepts_b:
                    concept_b = graph.get_concept(cid_b)

                    similarity, common_keywords = calculate_similarity(concept_a, concept_b)

                    if similarity >= threshold:
                        links.append({
                            'project_a': project_a,
                            'project_b': project_b,
                            'concept_a': concept_a,
                            'concept_b': concept_b,
                            'similarity': similarity,
                            'common_keywords': common_keywords,
                        })

    # 按相似度排序
    links.sort(key=lambda x: x['similarity'], reverse=True)

    return links


def format_recommendations(recommendations: dict):
    """格式化推荐结果"""
    if 'error' in recommendations:
        print(f"❌ {recommendations['error']}")
        return

    target = recommendations['target']

    print(f"\n💡 基于「{target['name']}」的联想推荐")
    print(f"\n来自项目：{target['project']}")
    print(f"定义：{target.get('definition', 'N/A')}")
    print("\n" + "="*60)

    # 同项目推荐
    same_project = recommendations['same_project']
    if same_project:
        print(f"\n✅ 同项目推荐（{target['project']}）：\n")
        for rec in same_project[:5]:  # 最多显示 5 个
            concept = rec['concept']
            print(f"• {concept['name']}")
            print(f"  关系：{rec['relationship']}")
            print(f"  原因：{rec['reason']}")
            print()

    # 跨项目推荐
    cross_project = recommendations['cross_project']
    if cross_project:
        print(f"\n🔗 跨项目推荐：\n")
        for rec in cross_project:
            concept = rec['concept']
            similarity = rec['similarity']
            common_keywords = rec['common_keywords']

            print(f"• {concept['name']}（来自：{concept['project']}）")
            print(f"  相似度：{similarity:.2f}")
            print(f"  关联关键词：{', '.join(list(common_keywords)[:10])}")
            print()

    # 学习路径
    learning_path = recommendations['learning_path']
    if learning_path:
        print(f"\n📚 建议学习路径：\n")
        for step in learning_path:
            concept = step['concept']
            print(f"{step['step']}️⃣ {concept['name']}")
            print(f"   {step['reason']}")
            print()


def format_discovery(links: List[dict]):
    """格式化发现结果"""
    print("\n🔍 跨项目概念关联发现")
    print("\n" + "="*60 + "\n")

    if not links:
        print("未发现跨项目关联（相似度阈值: 0.3）")
        return

    # 按项目对分组
    project_pairs = defaultdict(list)
    for link in links:
        key = (link['project_a'], link['project_b'])
        project_pairs[key].append(link)

    for (project_a, project_b), pair_links in project_pairs.items():
        print(f"\n{project_a} ↔ {project_b}")
        print("-" * 60)

        for link in pair_links[:5]:  # 每对项目最多显示 5 个关联
            concept_a = link['concept_a']
            concept_b = link['concept_b']
            similarity = link['similarity']
            common_keywords = link['common_keywords']

            print(f"\n• {concept_a['name']} ↔ {concept_b['name']}")
            print(f"  相似度：{similarity:.2f}")
            print(f"  共同关键词：{', '.join(list(common_keywords)[:10])}")

        print()


def main():
    import sys

    if len(sys.argv) < 2:
        print("用法：")
        print("  llm-wiki suggest <concept>   - 基于某概念推荐相关概念")
        print("  llm-wiki discover            - 发现跨项目概念关联")
        sys.exit(1)

    command = sys.argv[1]

    print("🔄 加载概念图谱...")
    graph = load_all_concepts()
    print(f"✅ 已加载 {len(graph.concepts)} 个概念，来自 {len(graph.projects)} 个项目")

    if command == 'suggest':
        if len(sys.argv) < 3:
            print("❌ 请指定概念名称或 ID")
            sys.exit(1)

        concept_id = sys.argv[2]
        print(f"\n🔍 正在分析「{concept_id}」...")

        recommendations = suggest_concepts(graph, concept_id)
        format_recommendations(recommendations)

    elif command == 'discover':
        print("\n🔍 正在发现跨项目关联...")

        links = discover_cross_project_links(graph, threshold=0.3)
        format_discovery(links)

    else:
        print(f"❌ 未知命令：{command}")
        sys.exit(1)


if __name__ == '__main__':
    main()
