# llm-wiki - 联想学习推荐（后台静默）

**作用**：在用户学习某概念后，静默分析并推送相关概念建议，不打断学习流程。

## 核心特性

- **后台运行**：由 dbs-learning 触发，不阻塞主对话
- **静默推送**：写入缓存文件，用户主动查询时才显示
- **跨项目联想**：发现不同项目间的概念关联
- **简单规则**：基于关键词和图谱结构，不用复杂算法

## 触发时机

**自动触发**（由 dbs-learning 调用）：
- 用户完成一次概念学习（mastery ≥ 0.5）
- dbs-learning 在后台调用 `llm-wiki push <concept>`

**手动触发**：
- 用户想主动探索：`/llm-wiki discover`

## 推荐逻辑

### 1. 同项目推荐（优先级高）
- **直接依赖**：概念的 dependencies 列表
- **下游概念**：依赖当前概念的其他概念
- **Hub 概念**：inDegree ≥ 3 的核心概念

### 2. 跨项目推荐（语义相似）
- **关键词匹配**：定义中有相同的关键术语
- **来源重叠**：appearances 中提到相同的文章/来源
- **名称相似**：如 harness ↔ deepseek-harness

### 3. 推荐数量
- 同项目：3-5 个
- 跨项目：2-3 个
- 总计不超过 8 个

## 命令

### `/llm-wiki push <concept>` (内部调用)
由 dbs-learning 后台触发，用户不直接调用。

执行：
1. 读取当前概念文件
2. 扫描所有项目的概念文件
3. 计算相似度（规则匹配）
4. 写入 `.learning-progress/suggestions.json`

### `/llm-wiki discover`
用户主动探索概念网络的隐藏关联。

输出示例：
```markdown
## 💡 发现概念关联

扫描了 3 个项目，17 个概念，发现这些有趣的跨项目联想：

### 1. harness ↔ deepseek-harness
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 同名概念，不同实现视角
- 相似度：0.95

### 2. agent ↔ skill-composition  
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 关键词重叠：orchestration, coordination
- 相似度：0.72

### 3. context-engineering ↔ prompt-design
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 来源重叠：都在「内参 #3」中出现
- 相似度：0.68
```

## 数据结构

### 推荐缓存：`.learning-progress/suggestions.json`

```json
{
  "generated": "2026-09-12T15:35:00Z",
  "basedOn": "agent",
  "suggestions": [
    {
      "concept": "tool-use",
      "project": "AI内参",
      "reason": "直接下游：5 个概念依赖 agent，tool-use 是最常用的",
      "similarity": 0.85,
      "type": "downstream",
      "expires": "2026-09-19T15:35:00Z"
    },
    {
      "concept": "skill-composition",
      "project": "AI实战营-前沿速递",
      "reason": "跨项目语义相似：都涉及 orchestration",
      "similarity": 0.72,
      "type": "semantic",
      "expires": "2026-09-19T15:35:00Z"
    },
    {
      "concept": "memory-management",
      "project": "AI内参",
      "reason": "Hub 概念：被 8 个概念依赖",
      "similarity": 0.68,
      "type": "hub",
      "expires": "2026-09-19T15:35:00Z"
    }
  ],
  "expiresAt": "2026-09-19T15:35:00Z"
}
```

### 过期策略
- 推荐有效期：7 天
- 过期后自动清理
- 下次学习时重新生成

## 相似度计算（简化规则）

```python
def calculate_similarity(concept_a, concept_b):
    score = 0.0
    
    # 1. 名称相似（30%）
    if concept_a.name in concept_b.name or concept_b.name in concept_a.name:
        score += 0.3
    
    # 2. 关键词重叠（40%）
    keywords_a = extract_keywords(concept_a.definition)
    keywords_b = extract_keywords(concept_b.definition)
    overlap = len(set(keywords_a) & set(keywords_b))
    score += 0.4 * (overlap / max(len(keywords_a), len(keywords_b)))
    
    # 3. 来源重叠（30%）
    sources_a = {app['source'] for app in concept_a.appearances}
    sources_b = {app['source'] for app in concept_b.appearances}
    if sources_a & sources_b:
        score += 0.3
    
    return min(score, 1.0)
```

## 输出格式（给 dbs-learning 读取）

当用户在 dbs-learning 中调用 `/dbs-learning suggestions` 时，dbs-learning 读取 `suggestions.json` 并格式化输出：

```markdown
## 💡 为你推荐的概念（基于你学习的 agent）

### 同项目推荐
1. **tool-use** (相似度 85%)
   - 直接下游：agent 的实际应用
   - 📁 AI内参/concepts/tool-use.md

2. **memory-management** (相似度 68%)  
   - Hub 概念：被 8 个概念依赖
   - 📁 AI内参/concepts/memory-management.md

### 跨项目联想
3. **skill-composition** (相似度 72%)
   - 来自「AI实战营-前沿速递」
   - 语义相似：都涉及 orchestration
   - 📁 AI实战营-前沿速递/concepts/skill-composition.md

📌 推荐有效期：7 天（至 2026-09-19）
使用 `/dbs-learning <concept>` 开始学习任一概念
```

## 实现约束

1. **轻量级**：扫描所有概念文件 < 5 秒
2. **规则优先**：不引入 NLP 库、不做向量计算
3. **容错**：某个概念文件读取失败不影响其他推荐
4. **静默失败**：推荐生成失败不阻塞 dbs-learning 主流程
5. **单向调用**：只被 dbs-learning 调用，不回调

## 与其他 Skill 的关系

```
dbs-learning (完成学习)
    ↓
llm-wiki push (后台静默)
    ↓
写入 suggestions.json
    ↓
(用户继续其他工作，无感知)
    ↓
(稍后) 用户调用 /dbs-learning suggestions
    ↓
dbs-learning 读取 suggestions.json 并显示
```

## 扩展可能

未来可以支持（当前 MVP 不实现）：
- 基于学习历史的个性化推荐
- 发现「学习孤岛」（未被依赖的概念）
- 推荐最优学习路径（拓扑排序 + mastery）
- 推送到 Obsidian Daily Note（每日学习建议）
