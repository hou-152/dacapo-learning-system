# DaCapo Learn 完整测试用例

**版本**：1.0.0  
**更新时间**：2026-09-28

---

## 测试目标

验证 DaCapo Learn 三个 Skill 的完整协作流程：

```
用户意图 → dispatch（定位 + 整合） → 提示词 → 
用户发送 → dbs-learning（评估 + 记录） → 
后台 llm-wiki（推荐 + 缓存）
```

---

## 测试环境准备

### 1. 确认 Skills 已安装

```bash
ls -la ~/.openclaw-autoclaw/skills/ | grep -E "(dbs-learning|llm-wiki|interactive-learning-dispatch)"
```

**预期输出**：
```
drwxr-xr-x  dbs-learning/
drwxr-xr-x  llm-wiki/
drwxr-xr-x  interactive-learning-dispatch/
```

### 2. 确认学习仓库已初始化

```bash
ls -la ~/Documents/dacapo-学习仓库/
```

**预期输出**：
```
concepts/          # 概念文件
articles/          # 学习文章（可选）
graph/             # 概念网络（可选）
.learning-progress/ # 缓存目录
SOURCE_OF_TRUTH.md # 真源导航
```

### 3. 确认至少有一个概念文件

```bash
ls ~/Documents/dacapo-学习仓库/concepts/ | head -3
```

**预期输出**：
```
context-engineering.md
harness.md
agent.md
```

---

## 测试用例 1：首次学习基础概念

### 场景描述

用户第一次使用 DaCapo Learn，想学习「harness」这个基础概念。

### 测试步骤

#### Step 1: 用户发起学习请求

**输入**：
```
我想学习 harness 概念
```

或直接调用：
```
/interactive-learning-dispatch harness
```

#### Step 2: dispatch 生成提示词

**预期行为**：
1. 读取 `SOURCE_OF_TRUTH.md` 或扫描目录
2. 定位概念文件：`~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
3. 读取 frontmatter：
   ```yaml
   ---
   tags: concept
   inDegree: 3
   dependencies: []
   mastery: null
   lastStudied: null
   ---
   ```
4. 调用 llm-wiki 获取上下文（首次学习，返回空）
5. 生成提示词

**预期输出**：

---

**推荐：`/dbs-learning harness`**

**选择理由**：你要开始学习特定概念——dbs-learning 通过简单问答评估掌握度，并将结果记录到概念文件的 frontmatter 中。

**已定位的事实**：
- 〔概念位置｜`~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`〕概念文件已存在
- 〔依赖关系｜同上 frontmatter〕该概念依赖：无（这是基础概念）
- 〔当前进度｜同上 frontmatter〕mastery 字段为 null（首次学习）
- 〔网络拓扑｜同上 frontmatter〕inDegree: 3（被 3 个其他概念依赖，是 Hub 概念）

**学习上下文（llm-wiki 提供）**：
- 这是首次学习，没有前置概念需要补
- 这是 Hub 概念（被 3 个概念依赖），掌握后能理解更多下游概念
- 学完后推荐学习：agent、tool-use

**边界**：学习完成后 dbs-learning 自动触发 llm-wiki 后台推送（静默执行，写入 `.learning-progress/suggestions.json`），不打断当前学习流程。

---

**可直接发送的提示词**：

> 使用 `/dbs-learning harness`。
> 
> 我要学习「AI 内参」项目中的 harness 概念。
> 
> **学习上下文（llm-wiki 提供）**：
> - 这是首次学习，没有前置概念需要补
> - 这是 Hub 概念（被 3 个概念依赖），掌握后能理解更多下游概念
> - 学完后推荐学习：agent、tool-use
> 
> 请执行交互式学习流程：
> 1. 读取概念文件 `~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
> 2. 检查前置概念（无），可以直接开始学习
> 3. 通过 2 个问题评估我的当前掌握度
> 4. 根据评估结果给出学习建议
> 5. 将掌握度（mastery）和学习时间（lastStudied）写入概念文件的 frontmatter
> 6. 完成后触发 llm-wiki 后台推送（静默执行，不阻塞）
> 
> 已定位事实：
> - 概念文件存在：`~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
> - 包含定义、为什么重要、出现文章
> - 该概念被 3 个其他概念依赖（inDegree: 3）→ Hub 概念
> - 当前 mastery 字段为 null，这是首次学习

把上面引用块整段复制发送即可。

---

#### Step 3: 用户复制粘贴提示词，发送

**用户操作**：复制引用块中的提示词，粘贴到对话框，发送

#### Step 4: dbs-learning 接管交互式学习

**预期行为**：

1. **读取概念文件**
   ```bash
   Read ~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md
   ```

2. **提问 1**：
   ```
   用一句话说说你理解的 harness 是什么？
   ```

3. **用户回答**（示例）：
   ```
   把 AI agent 管住的那套工具和实践
   ```

4. **评分**：关键词匹配（agent, 管住, 工具, 实践）→ 得分 0.7

5. **提问 2**：
   ```
   能举个你见过的例子吗？
   ```

6. **用户回答**（示例）：
   ```
   Martin Fowler 文章里提到的 context engineering、linter、测试
   ```

7. **评分**：来源匹配（Martin Fowler 文章）+ 具体概念（context engineering）→ 得分 0.6

8. **计算掌握度**：
   ```
   mastery = (0.7 + 0.6) / 2 = 0.65
   ```

9. **更新 frontmatter**：
   ```bash
   Edit ~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md
   ```
   
   新增字段：
   ```yaml
   mastery: 0.65
   lastStudied: 2026-09-28T16:00:00Z
   studyCount: 1
   ```

10. **给出学习建议**：
    ```markdown
    ## 学习概念：harness
    
    ### 掌握度：65% (学习中)
    
    建议下一步：
    1. 查看 harness 在「AI 内参」中的实际出现
    2. 学习下游概念：agent (依赖 harness)、tool-use (依赖 harness)
    
    已更新概念文件的 mastery 字段 ✓
    后台已触发联想推荐 (使用 `/推荐` 查看)
    ```

11. **后台触发 llm-wiki**（静默）：
    ```bash
    # 不阻塞主流程
    background: /llm-wiki push harness
    ```

#### Step 5: llm-wiki 后台生成推荐（静默）

**预期行为**：

1. **扫描概念网络**：
   - 读取所有 `concepts/*.md` 文件
   - 识别依赖关系

2. **计算推荐**：
   - 同项目下游：agent (依赖 harness)、tool-use (依赖 harness)
   - Hub 概念：memory-management (inDegree >= 3)
   - 跨项目联想：deepseek-harness (AI实战营-前沿速递，名称相似)

3. **写入缓存**：
   ```bash
   Write ~/Documents/dacapo-学习仓库/.learning-progress/suggestions.json
   ```
   
   内容：
   ```json
   {
     "generated": "2026-09-28T16:00:30Z",
     "basedOn": "harness",
     "suggestions": [
       {
         "concept": "agent",
         "project": "AI内参",
         "type": "downstream",
         "similarity": 0.85,
         "reason": "直接下游：agent 依赖 harness"
       },
       {
         "concept": "tool-use",
         "project": "AI内参",
         "type": "downstream",
         "similarity": 0.80,
         "reason": "直接下游：tool-use 依赖 harness"
       },
       {
         "concept": "deepseek-harness",
         "project": "AI实战营-前沿速递",
         "type": "semantic",
         "similarity": 0.95,
         "reason": "跨项目语义相似：同名概念"
       }
     ],
     "expiresAt": "2026-10-05T16:00:30Z"
   }
   ```

### 验证点

- ✅ dispatch 成功定位概念文件
- ✅ dispatch 生成的提示词可复制
- ✅ dbs-learning 成功评估掌握度
- ✅ frontmatter 成功更新（mastery、lastStudied、studyCount）
- ✅ llm-wiki 后台推送成功（生成 suggestions.json）
- ✅ 用户无感知后台推送（不阻塞主流程）

---

## 测试用例 2：查看推荐概念

### 场景描述

用户学完 harness 后，想看系统推荐什么概念。

### 测试步骤

#### Step 1: 用户查看推荐

**输入**：
```
/推荐
```

或：
```
/dbs-learning suggestions
```

#### Step 2: dbs-learning 读取缓存

**预期行为**：

1. 读取 `.learning-progress/suggestions.json`
2. 检查是否过期（7 天内）
3. 格式化输出

**预期输出**：

```markdown
## 💡 为你推荐的概念（基于你学习的 harness）

### 同项目推荐

1. **agent** (相似度 85%)
   - 直接下游：agent 依赖 harness
   - 📁 AI内参/concepts/agent.md
   - 当前掌握度：未学习

2. **tool-use** (相似度 80%)
   - 直接下游：tool-use 依赖 harness
   - 📁 AI内参/concepts/tool-use.md
   - 当前掌握度：未学习

### 跨项目联想（草蛇灰线）

3. **deepseek-harness** (相似度 95%)
   - 来自「AI实战营-前沿速递」
   - 语义相似：同名概念，不同实现视角
   - 📁 AI实战营-前沿速递/concepts/deepseek-harness.md
   - 当前掌握度：未学习

---

📌 推荐有效期：7 天（至 2026-10-05）

使用 `/学习 <概念名>` 开始学习任一概念
```

### 验证点

- ✅ 成功读取 suggestions.json
- ✅ 推荐列表包含同项目 + 跨项目
- ✅ 相似度计算合理
- ✅ 推荐理由清晰

---

## 测试用例 3：学习有依赖的概念

### 场景描述

用户想学习「agent」，但它依赖「harness」（已学习，掌握度 65%）。

### 测试步骤

#### Step 1: 用户发起学习请求

**输入**：
```
/学习 agent
```

#### Step 2: dispatch 生成提示词

**预期行为**：

1. 定位概念文件：`concepts/agent.md`
2. 读取 frontmatter：
   ```yaml
   dependencies: [harness, context-engineering]
   inDegree: 5
   mastery: null
   ```
3. 检查依赖掌握度：
   - harness: 0.65 ⚠️
   - context-engineering: 0.85 ✅
4. 调用 llm-wiki 获取上下文：
   - 你之前学过 harness (65%)，agent 是在 harness 之上的执行单元
5. 生成提示词

**预期输出**（关键部分）：

```
**学习上下文（llm-wiki 提供）**：
- 你之前学过 harness（掌握度 65%），agent 是在 harness 之上的执行单元
- 你之前学过 context-engineering（掌握度 85%），agent 需要它来管理上下文
- 这 3 个概念形成链条：context-engineering → harness → agent

请执行交互式学习流程：
1. 读取概念文件 `~/Documents/dacapo-学习仓库/AI内参/concepts/agent.md`
2. 检查前置概念：
   - harness ⚠️ 需要巩固（当前 65%）
   - context-engineering ✅ 已掌握（当前 85%）
3. 通过 2 个问题评估我的当前掌握度，**关联我之前学过的 harness 和 context-engineering**
4. ...
```

### 验证点

- ✅ dispatch 成功识别依赖关系
- ✅ dispatch 提示依赖掌握度状态
- ✅ 学习上下文包含已学概念（复利效应）
- ✅ dbs-learning 评估时关联已学概念

---

## 测试用例 4：查看学习进度

### 场景描述

用户想查看整体学习进度。

### 测试步骤

#### Step 1: 用户查看进度

**输入**：
```
/进度
```

或：
```
/dbs-learning status
```

#### Step 2: dbs-learning 扫描所有概念

**预期行为**：

1. 扫描 `concepts/` 下所有 `.md` 文件
2. 读取每个文件的 frontmatter.mastery
3. 统计分布

**预期输出**：

```markdown
## 📊 学习进度总览

**已掌握** (mastery ≥ 0.8)：
- ✅ context-engineering (85%)

**学习中** (0.5 ≤ mastery < 0.8)：
- ⚠️ harness (65%)
- ⚠️ agent (70%)

**初识** (0 < mastery < 0.5)：
- ❓ tool-use (30%)

**未学习** (mastery = null 或 0)：
- ⭕️ memory-management
- ⭕️ service-template
- ⭕️ 其余 8 个概念

---

总计：13 个概念
- 已掌握：1 个 (8%)
- 学习中：2 个 (15%)
- 初识：1 个 (8%)
- 未学习：9 个 (69%)

**建议**：
1. 巩固 harness（当前 65% → 目标 80%）
2. 巩固 agent（当前 70% → 目标 80%）
3. 学习 memory-management（Hub 概念，inDegree: 5）
```

### 验证点

- ✅ 成功扫描所有概念文件
- ✅ 掌握度分类准确
- ✅ 统计数据正确
- ✅ 给出合理学习建议

---

## 测试用例 5：发现跨项目关联

### 场景描述

用户想探索不同项目间的概念关联（草蛇灰线）。

### 测试步骤

#### Step 1: 用户发起探索

**输入**：
```
/发现关联
```

或：
```
/llm-wiki discover
```

#### Step 2: llm-wiki 扫描跨项目概念

**预期行为**：

1. 扫描所有项目的 `concepts/` 目录
2. 计算跨项目相似度：
   - 名称相似：harness ↔ deepseek-harness
   - 关键词重叠：agent ↔ skill-composition
   - 来源重叠：context-engineering ↔ prompt-design

**预期输出**：

```markdown
## 💡 发现概念关联（跨项目）

扫描了 3 个项目，21 个概念，发现这些有趣的跨项目联想：

### 1. harness ↔ deepseek-harness
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 同名概念，不同实现视角
- 相似度：0.95
- 你已学习 AI内参 的 harness (65%)，可以快速理解 deepseek-harness

### 2. agent ↔ skill-composition
- 📁 AI内参 ↔ AI实战营-前沿速递
- 🔗 关键词重叠：orchestration, coordination, workflow
- 相似度：0.72
- 你已学习 agent (70%)，可以类比理解 skill-composition

### 3. context-engineering ↔ prompt-design
- 📁 AI内参 ↔ AI实战营-从Demo到产品
- 🔗 来源重叠：都在「内参 #3」中出现
- 相似度：0.68
- 你已掌握 context-engineering (85%)，可以扩展到 prompt-design

---

💡 **草蛇灰线**：这些关联不是直接依赖关系，而是隐藏的语义相似性。

掌握跨项目关联能帮你：
- 快速理解新项目的概念（复利效应）
- 发现知识盲区（某个领域只学了一个项目）
- 建立更完整的知识网络
```

### 验证点

- ✅ 成功扫描多个项目
- ✅ 相似度计算合理（名称、关键词、来源）
- ✅ 关联你已学概念（复利提示）
- ✅ 解释「草蛇灰线」的价值

---

## 测试用例 6：错误处理

### 6.1 概念不存在

**输入**：
```
/学习 xyz
```

**预期输出**：
```markdown
❌ **找不到概念「xyz」**

可用概念有（共 13 个）：

**AI内参**：
- harness
- context-engineering
- agent
- tool-use
- memory-management

**AI实战营-前沿速递**：
- skill-composition
- deepseek-harness

请使用 `/学习 <概念名>` 重新选择。
```

### 6.2 多个匹配

**输入**：
```
/学习 context
```

**预期输出**：
```markdown
⚠️ **找到多个匹配「context」的概念**

1. context-engineering（AI内参）
2. context-design（AI实战营-从Demo到产品）

请明确指定：
- `/学习 context-engineering`
- `/学习 context-design`
```

### 6.3 依赖未满足（提示而不阻止）

**输入**：
```
/学习 advanced-agent
```

**预期输出**（提示词中包含）：
```
**学习上下文（llm-wiki 提供）**：
- ⚠️ 前置概念 harness 掌握度较低（30%），建议先巩固
- ⚠️ 前置概念 agent 未学习，可能较难理解
- 建议学习顺序：harness → agent → advanced-agent

是否继续学习 advanced-agent？（可能较难理解，但不阻止）
```

---

## 完整学习循环测试

### 测试场景

从零开始，学习 5 个概念，验证整个体系协作。

### 测试步骤

1. **学习 context-engineering**（基础概念，无依赖）
   - dispatch 定位 ✅
   - dbs-learning 评估 ✅
   - 掌握度 85% ✅
   - llm-wiki 后台推送 ✅

2. **查看推荐**
   - 读取 suggestions.json ✅
   - 推荐：harness、prompt-design ✅

3. **学习 harness**（依赖 context-engineering）
   - dispatch 识别依赖 ✅
   - 学习上下文：「你之前学过 context-engineering (85%)」✅
   - 掌握度 65% ✅

4. **学习 agent**（依赖 harness、context-engineering）
   - 学习上下文：「你之前学过 harness (65%) 和 context-engineering (85%)」✅
   - 评估时关联已学概念 ✅
   - 掌握度 70% ✅

5. **查看进度**
   - 已掌握：1 个 (context-engineering 85%)
   - 学习中：2 个 (harness 65%, agent 70%)
   - 统计准确 ✅

6. **发现跨项目关联**
   - 找到 harness ↔ deepseek-harness ✅
   - 找到 agent ↔ skill-composition ✅
   - 提示复利效应 ✅

### 验证点

- ✅ 三个 Skill 协作流畅
- ✅ 数据流转正确（frontmatter → suggestions.json）
- ✅ 复利效应体现（关联已学概念）
- ✅ 用户体验顺畅（dispatch 生成提示词 → 用户复制发送 → dbs-learning 接管）

---

## 性能测试

### 测试目标

验证各 Skill 的响应时间。

### 测试数据

- 概念文件数量：20 个
- 项目数量：3 个
- 学习历史：5 个概念已学习

### 性能要求

| 操作 | 要求 | 实际 | 状态 |
|------|------|------|------|
| dispatch 定位概念 | < 1s | - | ⏳ |
| dispatch 生成提示词 | < 3s | - | ⏳ |
| dbs-learning 评估 | < 10s | - | ⏳ |
| llm-wiki 后台推送 | < 5s | - | ⏳ |
| 查看推荐 | < 1s | - | ⏳ |
| 查看进度 | < 2s | - | ⏳ |
| 发现跨项目关联 | < 5s | - | ⏳ |

---

## 数据完整性测试

### 测试目标

验证 frontmatter 数据的完整性和一致性。

### 测试用例

#### 1. frontmatter 必需字段

**检查**：所有概念文件必须包含：
```yaml
---
tags: concept
dependencies: [...]
inDegree: <number>
firstAppearance: "[[...]]"
---
```

#### 2. mastery 字段更新

**测试**：
- 学习前：`mastery: null`
- 学习后：`mastery: 0.65`
- 再次学习：`mastery: 0.80`（应该更新，不是覆盖）

#### 3. studyCount 累加

**测试**：
- 首次学习：`studyCount: 1`
- 第二次学习：`studyCount: 2`
- 第三次学习：`studyCount: 3`

#### 4. 依赖关系一致性

**测试**：
- 如果 A.dependencies 包含 B
- 则 B.inDegree 应该 >= 1

---

## 边界测试

### 1. 空学习仓库

**场景**：`concepts/` 目录为空

**预期**：
- dispatch 提示：「学习仓库为空，请先添加概念文件」
- 不报错，不崩溃

### 2. 缓存过期

**场景**：suggestions.json 超过 7 天

**预期**：
- 读取时提示：「推荐已过期，请重新学习以更新」
- 或自动重新生成

### 3. 概念文件格式错误

**场景**：frontmatter 格式不正确

**预期**：
- dbs-learning 报错：「概念文件格式错误，请检查 frontmatter」
- 不损坏文件

### 4. llm-wiki 调用失败

**场景**：llm-wiki 不可用或超时

**预期**：
- dispatch 降级：不提供学习上下文，继续生成提示词
- dbs-learning 继续工作：不阻塞主流程
- 用户不感知后台失败

---

## 回归测试清单

每次更新后，必须通过以下测试：

- [ ] 测试用例 1：首次学习基础概念
- [ ] 测试用例 2：查看推荐概念
- [ ] 测试用例 3：学习有依赖的概念
- [ ] 测试用例 4：查看学习进度
- [ ] 测试用例 5：发现跨项目关联
- [ ] 测试用例 6：错误处理（3 个子用例）
- [ ] 完整学习循环（5 个概念）
- [ ] frontmatter 数据完整性
- [ ] 性能要求达标

---

## 测试报告模板

```markdown
# DaCapo Learn 测试报告

**测试时间**：YYYY-MM-DD  
**测试人**：XXX  
**版本**：1.0.0

## 测试环境

- Skills 版本：
  - dbs-learning: 1.0.0
  - llm-wiki: 1.0.0
  - interactive-learning-dispatch: 1.0.0
- 学习仓库：~/Documents/dacapo-学习仓库/
- 概念数量：20 个
- 项目数量：3 个

## 测试结果

| 测试用例 | 状态 | 备注 |
|---------|------|------|
| 首次学习基础概念 | ✅ | |
| 查看推荐概念 | ✅ | |
| 学习有依赖的概念 | ✅ | 复利效应生效 |
| 查看学习进度 | ✅ | |
| 发现跨项目关联 | ✅ | |
| 错误处理 | ✅ | 3/3 通过 |
| 完整学习循环 | ✅ | 5 个概念 |
| 数据完整性 | ✅ | |
| 性能要求 | ⚠️ | dispatch 偶尔超时 |

## 发现的问题

1. dispatch 在概念数量 > 50 时偶尔超时（> 3s）
2. llm-wiki 后台推送失败时无日志
3. 建议：优化概念扫描算法

## 总体评价

✅ **通过**

三个 Skill 协作流畅，核心功能完整，用户体验良好。
```

---

## 总结

### 测试覆盖

- ✅ 单 Skill 功能测试（dispatch、dbs-learning、llm-wiki）
- ✅ 三 Skill 协作测试（完整学习循环）
- ✅ 数据完整性测试（frontmatter、缓存）
- ✅ 错误处理测试（概念不存在、依赖未满足）
- ✅ 性能测试（响应时间）
- ✅ 边界测试（空仓库、缓存过期）

### 测试策略

1. **先单 Skill，再集成**：确保每个 Skill 独立工作
2. **先正常流程，再异常**：核心功能优先
3. **先功能，再性能**：可用性优先于效率
4. **用真实数据**：不模拟，用实际概念文件

### 验收标准

- 所有测试用例通过
- 性能要求达标
- 无数据损坏风险
- 用户体验流畅
