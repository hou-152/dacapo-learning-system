# 交互式学习体系命名规范

**版本**：1.0.0  
**更新时间**：2026-09-28

---

## 一、体系名称

### 主系统名称

**DaCapo Learn**（达·卡波学习）

- **DaCapo**：音乐术语「从头再来」，寓意温故知新、螺旋上升的学习
- **Learn**：明确学习定位，区别于单纯的知识管理

**一句话描述**：基于概念网络的交互式学习系统，通过掌握度追踪实现知识复利。

---

## 二、三个 Skill 的定位

### 1. dbs-learning（数据库学习）

**英文全称**：Database-Backed Learning  
**中文名称**：概念学习对话

**定位**：执行层——通过简单问答评估掌握度，记录到概念文件

**核心职责**：
- 读取概念文件（Obsidian frontmatter）
- 通过 2-3 个问题评估用户理解
- 将掌握度（mastery）写回 frontmatter
- 根据掌握度给出学习建议

**用户可见命令**：
- `/dbs-learning <概念名>` — 开始学习某个概念
- `/dbs-learning status` — 查看学习进度总览
- `/dbs-learning suggestions` — 查看推荐概念

**关键术语**：
- **掌握度（mastery）**：0-1 的数值，表示对概念的理解程度
- **依赖概念（dependencies）**：需要先掌握的前置概念
- **入度（inDegree）**：被多少个其他概念依赖

---

### 2. llm-wiki（联想学习推荐）

**英文全称**：LLM-Powered Wiki Context  
**中文名称**：概念联想推荐

**定位**：后台层——静默分析概念关联，推送学习建议

**核心职责**：
- 在用户学完一个概念后后台触发（由 dbs-learning 调用）
- 扫描同项目和跨项目的概念网络
- 计算相似度（基于关键词、来源、依赖关系）
- 写入推荐缓存（`.learning-progress/suggestions.json`）

**用户可见命令**：
- `/llm-wiki discover` — 主动探索跨项目概念关联

**关键术语**：
- **草蛇灰线（semantic trail）**：跨项目的隐藏概念关联
- **Hub 概念（hub concept）**：inDegree ≥ 3 的核心概念
- **下游概念（downstream）**：依赖当前概念的其他概念

---

### 3. interactive-learning-dispatch（学习入口调度）

**英文全称**：Interactive Learning Dispatcher  
**中文名称**：学习入口

**定位**：导航层——解析用户意图，生成可执行提示词

**核心职责**：
- 解析用户的学习请求
- 读取学习仓库真源（SOURCE_OF_TRUTH.md）
- 定位概念文件和依赖关系
- 调用 llm-wiki 获取学习上下文
- 生成可直接发送的提示词（包含已定位事实 + 学习建议）

**用户可见命令**：
- `/学习 <概念名>` — 用户友好的入口（等价于 dispatch）
- `/进度` — 查看学习进度
- `/推荐` — 查看推荐的概念

**关键术语**：
- **已定位事实（located facts）**：从文件系统真实读取的数据
- **学习上下文（learning context）**：llm-wiki 提供的关联概念信息
- **复利效应（compounding effect）**：利用已学概念理解新概念

---

## 三、命令命名规范

### 底层命令（Skill 内部）

遵循 Unix 风格，短横线分隔：

```bash
/dbs-learning harness
/llm-wiki discover
/interactive-learning-dispatch agent
```

### 用户友好命令（入口别名）

中文、简短、直观：

```bash
/学习 harness        # → /dbs-learning harness
/进度               # → /dbs-learning status
/推荐               # → /dbs-learning suggestions
/发现关联           # → /llm-wiki discover
```

---

## 四、核心概念术语

### 1. 掌握度（Mastery）

**定义**：0-1 的数值，表示用户对概念的理解深度

**分级**：
- `null` 或 `0`：未学习
- `0.01-0.49`：初识（heard of it）
- `0.50-0.79`：理解中（learning）
- `0.80-1.00`：已掌握（mastered）

**存储位置**：概念文件 frontmatter 的 `mastery` 字段

---

### 2. 草蛇灰线（Semantic Trail）

**定义**：跨项目的概念关联，不一定是直接依赖关系，但有语义相似性

**来源**：《红楼梦》脂砚斋评语「草蛇灰线，伏脉千里」

**示例**：
- AI 内参的 `harness` ↔ AI 实战营的 `deepseek-harness`
- 从知识生产到 IP 定位的 `议程所有权` ↔ AI 内参的 `context-engineering`

**实现**：llm-wiki 通过关键词匹配、来源重叠计算相似度

---

### 3. Hub 概念（Hub Concept）

**定义**：被多个其他概念依赖（inDegree ≥ 3）的核心概念

**特征**：
- 是概念网络的「枢纽」
- 掌握后能理解更多下游概念
- 优先学习能带来更大的复利效应

**示例**：
- `harness`（被 agent、tool-use、memory-management 等依赖）
- `context-engineering`（被 prompt-design、agent-workflow 等依赖）

---

### 4. 复利效应（Compounding Effect）

**定义**：先掌握的概念帮助理解后续概念，学习效率呈指数增长

**机制**：
- dbs-learning 在提问时关联已掌握概念
- 「你之前学过 X（掌握度 75%），Y 是在 X 基础上的扩展」

**验证指标**：
- 学习前 3 篇：每篇需要 30 分钟
- 学习 10 篇后：每篇只需 15 分钟（因为新概念大多依赖已掌握概念）

---

### 5. 入度（inDegree）

**定义**：有多少个其他概念依赖当前概念

**计算**：扫描所有概念的 `dependencies` 字段，统计当前概念出现次数

**用途**：
- 识别 Hub 概念（inDegree ≥ 3）
- 推荐学习顺序（优先学习 inDegree 高的概念）

---

## 五、文件与目录命名

### 概念文件

**格式**：`<概念名>.md`（小写，短横线分隔）

**示例**：
```
concepts/harness.md
concepts/context-engineering.md
concepts/service-template.md
```

### 学习项目目录

**格式**：`<项目主题>`（中文）

**示例**：
```
~/Documents/dacapo-学习仓库/
├── AI内参/
├── AI实战营-从Demo到产品/
└── 从知识生产到IP定位/
```

### 缓存文件

**格式**：`.learning-progress/<类型>.json`（隐藏目录，类型小写）

**示例**：
```
.learning-progress/suggestions.json   # llm-wiki 推荐缓存
.learning-progress/history.json       # 学习历史记录
```

---

## 六、输出文本术语

### 状态标签

```
✅ 已掌握 (mastery ≥ 0.8)
⚠️ 学习中 (0.5 ≤ mastery < 0.8)
❓ 初识 (0 < mastery < 0.5)
⭕️ 未学习 (mastery = null 或 0)
```

### 推荐理由

```
🔴 前置概念（需要先掌握）
🟢 当前概念
🔵 后续概念（学完后可以学）
🔗 跨项目联想（草蛇灰线）
⭐️ Hub 概念（核心枢纽）
```

### 学习建议

```
📖 巩固：掌握度 50% → 70%
🎯 深入：掌握度 70% → 90%
💎 学习：掌握度 0% → 50%
🔍 实践：阅读实际案例
🏆 完成：掌握度 90% → 100%
```

---

## 七、错误与警告术语

### 错误类型

```
❌ 概念不存在：「找不到概念 X，可用概念有：A, B, C」
⚠️ 依赖未满足：「建议先学习前置概念：X (掌握度 30%)」
⏸️ 学习中断：「上次学到一半，继续还是重新开始？」
```

### 边界提示

```
📌 已定位事实：从文件真实读取
💭 推测信息：基于规则推导，可能不准确
⏳ 待更新：需要完成学习后才有数据
```

---

## 八、版本与迁移

### Skill 版本号

遵循语义化版本（Semantic Versioning）：

```
dbs-learning v1.0.0
llm-wiki v1.0.0
interactive-learning-dispatch v1.0.0
```

### 数据迁移标记

当 frontmatter 格式变化时：

```yaml
---
schemaVersion: 2  # 数据格式版本
migratedFrom: 1   # 从版本 1 迁移而来
migratedAt: 2026-09-28T10:00:00Z
---
```

---

## 九、与其他系统的术语对照

### DaCapo Learn vs dbs-learning（旧体系）

| 概念 | DaCapo Learn | dbs-learning（旧） | 说明 |
|------|--------------|-------------------|------|
| 掌握度 | mastery（0-1） | mastery（0-100%）| 统一为 0-1 |
| 推荐 | suggestions | 无 | 新增 llm-wiki |
| 入口 | dispatch + context | 直接调用 | 新增 context 整合 |
| 概念文件 | frontmatter | 独立 JSON | 迁移到 Obsidian |

### DaCapo Learn vs Obsidian 原生

| 功能 | DaCapo Learn | Obsidian 原生 | 说明 |
|------|-------------|--------------|------|
| 概念关联 | 依赖图 + inDegree | 双向链接 | 补充语义 |
| 学习追踪 | frontmatter mastery | 无 | 新增能力 |
| 复习提醒 | 基于掌握度 | 间隔重复插件 | 不同算法 |

---

## 十、命名原则总结

### 底层 Skill（开发者视角）

- **英文**：方便代码调用
- **短横线分隔**：Unix 风格
- **描述性**：说明职责（learning, wiki, dispatch）

### 用户命令（学习者视角）

- **中文**：降低认知负担
- **简短**：1-2 个字（学习、进度、推荐）
- **动词优先**：表达意图清晰

### 核心术语（文档与输出）

- **中英双语**：首次出现给英文，后续用中文
- **隐喻自然**：草蛇灰线、Hub 概念、复利效应
- **避免生造**：优先使用领域内已有术语

### 文件与数据

- **小写 + 短横线**：跨平台兼容
- **隐藏目录用点开头**：`.learning-progress/`
- **元数据在 frontmatter**：遵循 Obsidian 约定

---

## 附录：快速查询表

### 用户最常用的 5 个命令

```bash
/学习 <概念>     # 开始学习
/进度           # 查看总览
/推荐           # 查看建议
/发现关联       # 跨项目探索
/可视化         # 打开概念网络图
```

### 开发者最常用的 5 个路径

```bash
~/.openclaw-autoclaw/skills/dbs-learning/
~/.openclaw-autoclaw/skills/llm-wiki/
~/.openclaw-autoclaw/skills/interactive-learning-dispatch/
~/Documents/dacapo-学习仓库/concepts/
~/Documents/dacapo-学习仓库/.learning-progress/
```

### 关键术语速查

| 中文 | 英文 | 简短定义 |
|------|------|---------|
| 掌握度 | mastery | 0-1 数值，理解深度 |
| 草蛇灰线 | semantic trail | 跨项目概念关联 |
| Hub 概念 | hub concept | inDegree ≥ 3 的核心概念 |
| 复利效应 | compounding effect | 已学概念助力新概念 |
| 入度 | inDegree | 被依赖次数 |
| 前置概念 | prerequisites / dependencies | 需要先掌握的概念 |
| 下游概念 | downstream | 依赖当前概念的概念 |

---

**命名哲学**：

> 好的命名是用户无需查文档就能猜到功能；好的术语是隐喻自然、易于传播。
> 
> 底层用英文保持技术严谨性，上层用中文降低认知负担，核心术语用隐喻建立直觉。
