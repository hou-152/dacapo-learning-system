# DaCapo Learn 集成架构

**版本**：1.0.0  
**更新时间**：2026-09-28

---

## 一、架构总览

### 三层架构

```
┌─────────────────────────────────────────────────────┐
│  导航层：interactive-learning-dispatch              │
│  - 解析用户意图                                      │
│  - 定位概念文件                                      │
│  - 整合学习上下文                                    │
│  - 生成可执行提示词                                  │
└─────────────────┬───────────────────────────────────┘
                  │ 生成提示词（包含事实 + 上下文）
                  ↓
┌─────────────────────────────────────────────────────┐
│  执行层：dbs-learning                                │
│  - 评估掌握度（2-3 个问题）                          │
│  - 更新 frontmatter                                  │
│  - 给出学习建议                                      │
│  - 触发后台推荐                                      │
└─────────────────┬───────────────────────────────────┘
                  │ 后台触发（静默）
                  ↓
┌─────────────────────────────────────────────────────┐
│  后台层：llm-wiki                                    │
│  - 扫描概念网络                                      │
│  - 计算相似度                                        │
│  - 写入推荐缓存                                      │
│  - 不阻塞主流程                                      │
└─────────────────────────────────────────────────────┘
```

---

## 二、数据流详解

### 完整学习循环

```
用户："我想学习 harness 概念"
  ↓
┌─────────────────────────────────────────────┐
│ Step 1: dispatch 定位与整合                  │
├─────────────────────────────────────────────┤
│ 1.1 读取学习仓库真源                         │
│     ~/Documents/dacapo-学习仓库/            │
│                                             │
│ 1.2 定位概念文件                            │
│     concepts/harness.md                     │
│     ├─ frontmatter.dependencies: []        │
│     ├─ frontmatter.inDegree: 3             │
│     └─ frontmatter.mastery: null           │
│                                             │
│ 1.3 调用 llm-wiki 获取学习上下文            │
│     /llm-wiki context harness              │
│     └─ 返回：已学概念、推荐路径             │
│                                             │
│ 1.4 生成可执行提示词                        │
│     已定位事实 + 学习上下文 + 边界说明      │
└─────────────────────────────────────────────┘
  ↓ 输出提示词
用户：复制粘贴提示词，发送
  ↓
┌─────────────────────────────────────────────┐
│ Step 2: dbs-learning 评估掌握度              │
├─────────────────────────────────────────────┤
│ 2.1 读取概念文件                            │
│     Read concepts/harness.md               │
│     └─ 解析定义、前置概念、出现文章         │
│                                             │
│ 2.2 评估掌握度（2 个问题）                  │
│     问题 1：「用一句话说说你理解的 harness」│
│     └─ 用户回答 → 关键词匹配 → 得分 0.7   │
│                                             │
│     问题 2：「能举个你见过的例子吗？」      │
│     └─ 用户回答 → 来源匹配 → 得分 0.6     │
│                                             │
│     平均掌握度 = (0.7 + 0.6) / 2 = 0.65   │
│                                             │
│ 2.3 更新概念文件 frontmatter                │
│     Edit concepts/harness.md               │
│     ├─ mastery: 0.65                       │
│     ├─ lastStudied: 2026-09-28T15:30:00Z  │
│     └─ studyCount: 1                       │
│                                             │
│ 2.4 给出学习建议                            │
│     - 掌握度 65% → 建议查看实际案例         │
│     - 推荐下游概念：agent, tool-use        │
└─────────────────────────────────────────────┘
  ↓ 后台触发（用户无感知）
┌─────────────────────────────────────────────┐
│ Step 3: llm-wiki 生成推荐（静默）            │
├─────────────────────────────────────────────┤
│ 3.1 扫描概念网络                            │
│     Read concepts/*.md (所有概念文件)       │
│                                             │
│ 3.2 计算推荐                                │
│     - 同项目：下游概念（agent, tool-use）   │
│     - 跨项目：语义相似（skill-composition） │
│     - Hub 概念：memory-management           │
│                                             │
│ 3.3 写入缓存                                │
│     Write .learning-progress/suggestions.json│
│     └─ 有效期 7 天                          │
└─────────────────────────────────────────────┘
  ↓ 稍后（用户主动查询）
用户："/推荐" 或 "/dbs-learning suggestions"
  ↓
dbs-learning 读取 suggestions.json 并格式化显示
```

---

## 三、调用链详解

### 场景 1：开始学习（最常用）

```
用户输入
  ↓
interactive-learning-dispatch
  ├─ 读取：SOURCE_OF_TRUTH.md（真源导航）
  ├─ 读取：concepts/<concept>.md（概念文件）
  ├─ 调用：llm-wiki context <concept>（获取上下文）
  └─ 输出：可直接发送的提示词
  ↓
用户复制粘贴提示词
  ↓
dbs-learning（接管交互）
  ├─ 提问 → 用户回答
  ├─ 评估掌握度
  ├─ 更新 frontmatter
  ├─ 给出学习建议
  └─ 后台触发 llm-wiki push <concept>（静默）
  ↓
llm-wiki（后台运行）
  ├─ 扫描概念网络
  ├─ 计算推荐
  └─ 写入 suggestions.json
```

### 场景 2：查看进度

```
用户："/进度"
  ↓
interactive-learning-dispatch
  └─ 路由到 dbs-learning status
  ↓
dbs-learning status
  ├─ 扫描所有概念文件
  ├─ 统计掌握度分布
  └─ 输出：已掌握 / 学习中 / 未学习
```

### 场景 3：查看推荐

```
用户："/推荐"
  ↓
interactive-learning-dispatch
  └─ 路由到 dbs-learning suggestions
  ↓
dbs-learning suggestions
  ├─ 读取：.learning-progress/suggestions.json
  ├─ 检查：是否过期（7 天）
  └─ 输出：同项目推荐 + 跨项目联想
```

### 场景 4：跨项目发现

```
用户："/发现关联"
  ↓
interactive-learning-dispatch
  └─ 路由到 llm-wiki discover
  ↓
llm-wiki discover
  ├─ 扫描所有项目的概念文件
  ├─ 计算跨项目相似度
  └─ 输出：草蛇灰线关联列表
```

---

## 四、文件系统集成

### 目录结构

```
~/Documents/dacapo-学习仓库/
├── AI内参/                          # 项目 1
│   ├── concepts/                    # 概念文件（全局唯一）
│   │   ├── harness.md
│   │   ├── context-engineering.md
│   │   └── agent.md
│   ├── articles/                    # 学习文章
│   │   ├── 01-*.md
│   │   └── 02-*.md
│   └── graph/                       # 概念网络可视化
│       ├── local/                   # 局部网络（每篇文章）
│       └── global/                  # 全局 Hub 网络
│
├── AI实战营-从Demo到产品/            # 项目 2
│   ├── concepts/
│   ├── articles/
│   └── graph/
│
├── .learning-progress/              # 跨项目缓存（隐藏）
│   ├── suggestions.json             # llm-wiki 推荐
│   └── history.json                 # 学习历史
│
└── SOURCE_OF_TRUTH.md               # 真源导航（重要！）
```

### SOURCE_OF_TRUTH.md 示例

```markdown
# 学习仓库真源导航

## 项目列表

### AI内参
- 路径：`~/Documents/dacapo-学习仓库/AI内参/`
- 概念数：13
- 状态：学习中

### AI实战营-从Demo到产品
- 路径：`~/Documents/dacapo-学习仓库/AI实战营-从Demo到产品/`
- 概念数：8
- 状态：未开始

## 概念文件位置规则

所有概念文件存储在各项目的 `concepts/` 目录下：
- `<项目>/concepts/<概念名>.md`

## 缓存文件位置

跨项目数据存储在根目录的隐藏文件夹：
- `.learning-progress/suggestions.json`
- `.learning-progress/history.json`

## 更新时间

2026-09-28
```

---

## 五、概念文件 Frontmatter 规范

### 标准字段

```yaml
---
# 基础信息
tags: concept
name: harness                              # 概念名称（可选，默认为文件名）

# 网络拓扑
dependencies: [context-engineering]        # 前置概念（数组）
inDegree: 3                               # 入度（被多少概念依赖）
firstAppearance: "[[01-harness-article]]" # 首次出现的文章

# 学习追踪（由 dbs-learning 写入）
mastery: 0.65                             # 掌握度 (0-1)
lastStudied: 2026-09-28T15:30:00Z         # 最后学习时间（ISO 8601）
studyCount: 2                             # 学习次数
nextReview: 2026-10-05                    # 建议复习日期

# 元数据
schemaVersion: 1                          # 数据格式版本
---
```

### 字段更新责任

| 字段 | 初始值 | 更新者 | 更新时机 |
|------|--------|--------|----------|
| `tags` | `concept` | dacapo-article | 概念提取时 |
| `dependencies` | `[]` | dacapo-article | 概念提取时 |
| `inDegree` | `0` | dacapo-article | 全局扫描后 |
| `firstAppearance` | 文章链接 | dacapo-article | 概念提取时 |
| `mastery` | `null` | dbs-learning | 学习评估后 |
| `lastStudied` | `null` | dbs-learning | 学习评估后 |
| `studyCount` | `0` | dbs-learning | 每次学习 +1 |
| `nextReview` | `null` | dbs-learning | 学习评估后 |

---

## 六、Skills 之间的接口

### dispatch → llm-wiki

**接口**：`/llm-wiki context <concept>`

**输入**：
```json
{
  "concept": "harness",
  "project": "AI内参"
}
```

**输出**：
```json
{
  "learnedConcepts": [
    {
      "name": "context-engineering",
      "mastery": 0.75,
      "relation": "dependency"
    }
  ],
  "suggestedPath": [
    "agent",
    "tool-use"
  ],
  "crossProjectLinks": [
    {
      "concept": "skill-composition",
      "project": "AI实战营-前沿速递",
      "similarity": 0.72,
      "reason": "语义相似：都涉及 orchestration"
    }
  ]
}
```

### dbs-learning → llm-wiki

**接口**：`/llm-wiki push <concept>`（后台调用）

**输入**：
```json
{
  "concept": "harness",
  "mastery": 0.65,
  "project": "AI内参"
}
```

**输出**：（异步写入 suggestions.json）
```json
{
  "generated": "2026-09-28T15:35:00Z",
  "basedOn": "harness",
  "suggestions": [
    {
      "concept": "agent",
      "project": "AI内参",
      "type": "downstream",
      "similarity": 0.85,
      "reason": "直接下游：agent 依赖 harness"
    }
  ],
  "expiresAt": "2026-10-05T15:35:00Z"
}
```

### dispatch → dbs-learning

**接口**：生成的提示词（字符串）

**输出示例**：

```
使用 `/dbs-learning harness`。

我要学习「AI 内参」项目中的 harness 概念。

**学习上下文（llm-wiki 提供）**：
- 你之前学过 context-engineering（掌握度 75%），harness 包含它
- 这是首次学习，当前 mastery 为 null

请执行交互式学习流程：
1. 读取概念文件 `~/Documents/dacapo-学习仓库/AI内参/concepts/harness.md`
2. 通过 2 个问题评估我的当前掌握度
3. 根据评估结果给出学习建议
4. 将掌握度（mastery）和学习时间（lastStudied）写入概念文件的 frontmatter
5. 完成后触发 llm-wiki 后台推送（静默执行，不阻塞）

已定位事实：
- 概念文件存在，包含定义和出现文章
- 该概念被 3 个其他概念依赖（inDegree: 3）
- 当前 mastery 字段为 null，这是首次学习
```

---

## 七、错误处理与边界

### dispatch 层错误处理

| 错误场景 | 处理方式 |
|----------|----------|
| 概念文件不存在 | 列出可用概念，建议用户选择 |
| SOURCE_OF_TRUTH.md 不存在 | 扫描目录，尝试自动生成 |
| llm-wiki 调用失败 | 降级：不提供学习上下文，继续执行 |
| 依赖概念未掌握 | 提示：「建议先学习 X（当前掌握度 30%）」|

### dbs-learning 层错误处理

| 错误场景 | 处理方式 |
|----------|----------|
| 概念文件格式错误 | 报错：「frontmatter 格式不正确」|
| 用户回答为空 | 追问：「能再详细说说吗？」|
| frontmatter 写入失败 | 报错并保留原文件 |
| llm-wiki 后台推送失败 | 记录日志但不阻塞主流程 |

### llm-wiki 层错误处理

| 错误场景 | 处理方式 |
|----------|----------|
| 概念文件读取失败 | 跳过该文件，继续扫描其他 |
| suggestions.json 写入失败 | 静默失败，不影响 dbs-learning |
| 相似度计算异常 | 降级：只推荐直接依赖关系 |

---

## 八、性能与优化

### 数据加载策略

| 场景 | 加载方式 | 优化 |
|------|----------|------|
| dispatch 定位概念 | 只读取目标概念文件 | 不扫描全部 |
| dbs-learning 评估 | 只读取当前概念文件 | 按需加载 |
| llm-wiki 推荐 | 扫描所有概念文件（后台） | 异步执行，缓存 7 天 |
| 查看进度 | 扫描所有概念 frontmatter | 只读 frontmatter，不读正文 |

### 缓存策略

| 数据 | 缓存位置 | 有效期 | 失效条件 |
|------|----------|--------|----------|
| llm-wiki 推荐 | suggestions.json | 7 天 | 新学习一个概念 |
| 学习历史 | history.json | 永久 | 无 |
| 概念索引 | 内存 | 单次会话 | 会话结束 |

---

## 九、扩展接口

### 未来可接入的组件

```
┌─────────────────────────────────────────────┐
│  可视化层（未来）                            │
│  - dacapo-visualize：概念网络可视化         │
│  - Obsidian Graph View：原生图谱           │
└─────────────────┬───────────────────────────┘
                  │ 读取 frontmatter
                  ↓
┌─────────────────────────────────────────────┐
│  当前三层（DaCapo Learn Core）               │
│  - dispatch → dbs-learning → llm-wiki       │
└─────────────────┬───────────────────────────┘
                  │ 提供数据接口
                  ↓
┌─────────────────────────────────────────────┐
│  未来扩展层                                  │
│  - 间隔重复算法（Spaced Repetition）        │
│  - 学习分析报告（Analytics）                │
│  - 多人协同学习（Collaboration）            │
└─────────────────────────────────────────────┘
```

### 数据导出接口

```json
// GET /api/concepts
[
  {
    "name": "harness",
    "mastery": 0.65,
    "dependencies": ["context-engineering"],
    "inDegree": 3,
    "project": "AI内参"
  }
]

// GET /api/progress
{
  "totalConcepts": 20,
  "mastered": 5,
  "learning": 8,
  "notStarted": 7,
  "averageMastery": 0.52
}
```

---

## 十、部署与启用

### Skills 安装位置

```bash
~/.openclaw-autoclaw/skills/
├── dbs-learning/
│   └── SKILL.md
├── llm-wiki/
│   └── SKILL.md
└── interactive-learning-dispatch/
    └── SKILL.md
```

### 学习仓库初始化

```bash
# 1. 创建学习仓库
mkdir -p ~/Documents/dacapo-学习仓库

# 2. 初始化 Obsidian vault
cd ~/Documents/dacapo-学习仓库
mkdir -p .obsidian concepts articles graph/{local,global} .learning-progress

# 3. 创建真源导航
touch SOURCE_OF_TRUTH.md

# 4. 在 Obsidian 中打开
open -a Obsidian ~/Documents/dacapo-学习仓库/
```

### 启动学习

```bash
# 用户友好入口
/学习 harness

# 或直接调用 dispatch
/interactive-learning-dispatch harness

# 查看进度
/进度

# 查看推荐
/推荐
```

---

## 十一、与 dacapo 链式架构的关系

### dacapo 全栈 vs DaCapo Learn

| 层级 | dacapo 全栈 | DaCapo Learn | 说明 |
|------|------------|--------------|------|
| 生产层 | dacapo-article | （不包含） | 生成学习文章 |
| 提取层 | dacapo-core | （不包含） | 提取概念 |
| 导航层 | （无） | dispatch | 新增：整合上下文 |
| 评估层 | dacapo-diagnose | dbs-learning | 重构：简化为 2 问 |
| 推荐层 | （无） | llm-wiki | 新增：概念联想 |
| 可视化层 | dacapo-visualize | （可选集成） | 共用概念网络 |

### 数据兼容性

DaCapo Learn 可以读取 dacapo 全栈生成的概念文件：

```yaml
---
# dacapo 全栈生成的字段
tags: concept
dependencies: [...]
inDegree: 3
firstAppearance: "[[...]]"

# DaCapo Learn 新增的字段
mastery: null          # 初始为 null，学习后更新
lastStudied: null
studyCount: 0
---
```

### 集成方式

```
dacapo-article（生成文章）
  ↓ 产出：concepts/*.md
dacapo-core（提取概念）
  ↓ 产出：frontmatter (dependencies, inDegree)
  ↓
┌───────────────────────────────┐
│ DaCapo Learn 接管学习流程      │
│ dispatch → dbs-learning → wiki │
└───────────────────────────────┘
  ↓ 产出：frontmatter (mastery, lastStudied)
dacapo-visualize（可视化）
  ↓ 读取：mastery 渲染节点颜色
```

---

## 总结

### 核心设计原则

1. **分层清晰**：导航 → 执行 → 后台，职责分明
2. **数据驱动**：所有状态在 frontmatter，不建新数据库
3. **静默后台**：llm-wiki 不打断主流程
4. **轻量实现**：规则匹配优于复杂算法
5. **可扩展**：预留接口，兼容未来组件

### 用户体验流程

```
用户意图 → dispatch（定位 + 整合） → 提示词 → 
用户复制发送 → dbs-learning（评估 + 记录） → 学习建议 →
（后台）llm-wiki（推荐 + 缓存） →
（稍后）用户主动查看推荐
```

### 开发者集成要点

1. **dispatch 是唯一入口**：用户只需记住 `/学习` 命令
2. **frontmatter 是唯一数据源**：所有 Skills 读写同一文件
3. **llm-wiki 是纯后台**：失败不影响主流程
4. **概念文件是真源**：SOURCE_OF_TRUTH.md 只是导航

---

**架构哲学**：

> 简单的架构靠约定（frontmatter 规范），不靠复杂的协调。
> 
> 静默的后台靠缓存（7 天有效期），不靠实时推送。
> 
> 清晰的边界靠文档（已定位事实 vs 推测信息），不靠黑箱。
