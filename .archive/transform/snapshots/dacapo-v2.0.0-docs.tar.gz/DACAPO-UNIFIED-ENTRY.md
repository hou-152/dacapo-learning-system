# dacapo - 概念学习系统（统一入口）

**定位**：DaCapo Learn 的统一入口，智能路由到对应的学习 Skill。

## 使用方式

### 基础用法
```bash
# 学习单个概念
/dacapo agent

# 自然语言描述
/dacapo 我想学习 harness 概念

# 查看学习进度
/dacapo 进度

# 查看推荐
/dacapo 推荐

# 发现概念关联
/dacapo 发现关联
```

## 执行流程

```
用户输入
    ↓
意图识别（学习/查询/探索）
    ↓
Skill 发现（扫描可用的 dacapo-* Skills）
    ↓
智能路由
    ├─ 学习意图 → dacapo-learning
    ├─ 查询意图 → dacapo-wiki
    ├─ 可视化 → dacapo-visualize
    └─ 其他 → dacapo-*
    ↓
检查已有材料（避免重复）
    ↓
直接执行（不生成提示词）
```

## 内部 Skills

### dacapo-learning（执行层）
- 概念学习对话
- 2 个问题评估掌握度
- 更新 frontmatter（mastery、lastStudied、studyCount）
- 触发后台推荐

### dacapo-wiki（后台层）
- 概念探索和联想推荐
- 跨项目草蛇灰线发现
- 静默推送，不阻塞主流程
- 7 天推荐缓存

### dacapo-visualize（可视化层）
- 概念网络图谱
- 学习路径可视化
- Hub 概念高亮

### 其他 dacapo-* Skills
- dacapo-article — 文章处理
- dacapo-core — 核心功能
- dacapo-lint — 质量校验
- dacapo-diagnose — 问题诊断
- dacapo-learn-backup — 版本备份

## 意图识别规则

### 学习意图
- 关键词：学习、了解、掌握、教我
- 后跟概念名
- 路由到：`dacapo-learning`

### 查询意图
- 关键词：进度、状态、学到哪了
- 路由到：`dacapo-learning status`

### 推荐意图
- 关键词：推荐、下一个、继续
- 路由到：`dacapo-learning suggestions`

### 探索意图
- 关键词：发现、关联、联想、探索
- 路由到：`dacapo-wiki discover`

### 可视化意图
- 关键词：图谱、可视化、网络
- 路由到：`dacapo-visualize`

## 与 dbs 的对比

### dbs 的形态
```bash
/dbs 我准备学习社会学基本概念、女权主义简史...
    ↓
版本检查 + Skill 发现
    ↓
五步只读导航（检查已有材料）
    ↓
判断意图："系统学习主题" → dbs-learning
    ↓
直接启动学习（不需要用户确认）
```

### dacapo 的形态（对标 dbs）
```bash
/dacapo agent
    ↓
Skill 发现（扫描 dacapo-* Skills）
    ↓
检查已有：agent 概念存在？掌握度如何？
    ↓
判断意图："学习概念" → dacapo-learning
    ↓
调用 dacapo-wiki 获取上下文（内部调用）
    ↓
直接启动交互式学习
```

## 核心设计

### 1. 一个入口
- 用户只需要知道 `/dacapo`
- 降低学习成本

### 2. 智能路由
- 自动判断意图
- 内部调用合适的 Skill
- 不需要用户了解 Skill 生态

### 3. 直接执行
- 不生成提示词让用户复制
- 不打断用户流程
- 像 dbs 一样顺畅

### 4. 检查已有
- 避免重复学习
- 利用已有掌握度
- 复利效应自然发生

## 技术实现

### Skill 发现
```python
# 扫描 ~/.openclaw-autoclaw/skills/dacapo-*
available_skills = [
    'dacapo-learning',
    'dacapo-wiki',
    'dacapo-visualize',
    # ...
]
```

### 意图识别
```python
def recognize_intent(user_input):
    if any(kw in user_input for kw in ['学习', '了解', '掌握']):
        return 'learn'
    elif any(kw in user_input for kw in ['进度', '状态']):
        return 'status'
    elif any(kw in user_input for kw in ['推荐', '下一个']):
        return 'suggest'
    elif any(kw in user_input for kw in ['发现', '关联']):
        return 'discover'
    elif any(kw in user_input for kw in ['图谱', '可视化']):
        return 'visualize'
```

### 路由执行
```python
def route_and_execute(intent, concept):
    if intent == 'learn':
        # 内部调用
        context = call_skill('dacapo-wiki', 'context', concept)
        call_skill('dacapo-learning', 'start', concept, context)
    elif intent == 'status':
        call_skill('dacapo-learning', 'status')
    # ...
```

## 数据流

```
用户：/dacapo agent
    ↓
dacapo（主入口）：
  1. Skill 发现
  2. 检查 agent 概念存在
  3. 读取 frontmatter（掌握度 null，首次学习）
  4. 判断意图：学习
  5. 内部调用 dacapo-wiki context agent
  6. 获取学习上下文
    ↓
dacapo-learning（直接执行）：
  1. 显示概念信息
  2. 问 2 个问题
  3. 评估掌握度
  4. 更新 frontmatter
  5. 给出学习建议
  6. 触发 dacapo-wiki push（后台）
    ↓
dacapo-wiki（后台静默）：
  1. 扫描概念网络
  2. 计算推荐
  3. 写入缓存
```

## 用户体验

### 传统方式（dispatch 模式）
```
用户：/dacapo-dispatch agent
    ↓ 生成提示词
用户：复制提示词
    ↓ 粘贴发送
系统：执行学习
```

### dacapo 方式（dbs 模式）
```
用户：/dacapo agent
    ↓ 直接执行
系统：开始学习对话
```

**体验提升**：减少 1 次交互，更流畅

## 对标原始 dbs-learning

### dbs-learning 解决的问题
- Bloom 2 Sigma Problem
- 一对一辅导的规模化
- 根据反馈持续调整学习内容

### dacapo 的实现
- 在 Obsidian 概念库基础上
- 评估掌握度 → 记录 frontmatter → 下次利用历史
- 自适应：掌握度低用简单类比，掌握度高深入原理
- 复利：用已学概念帮助理解新概念

## 命名说明

### 为什么叫 dacapo？
- **Da Capo**（意大利语）：从头再来、重复
- **音乐术语**：回到开头，但带着新的理解
- **学习隐喻**：温故知新、螺旋上升

### DaCapo Learn
- 整个学习体系的名称
- 强调概念复利、螺旋上升的学习

## 安装

```bash
# 主入口 Skill
~/.openclaw-autoclaw/skills/dacapo/

# 子 Skills
~/.openclaw-autoclaw/skills/dacapo-learning/
~/.openclaw-autoclaw/skills/dacapo-wiki/
~/.openclaw-autoclaw/skills/dacapo-visualize/
# ...其他 dacapo-* Skills
```

## 约定

1. **用户只调用 `/dacapo`** — 不直接调用子 Skills
2. **内部自动路由** — 根据意图选择合适的 Skill
3. **数据在 frontmatter** — 不建额外数据库
4. **后台推送静默** — 不打断用户流程
5. **复利效应自然** — 系统自动关联已学概念
