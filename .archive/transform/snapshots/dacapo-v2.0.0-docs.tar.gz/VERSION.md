# DaCapo Learn - Version History

## v2.0.0 - 智能路由系统 (2026-09-28)

### 重大更新
- **智能路由系统**: dacapo-main 升级为意图识别引擎（5 种意图）
- **内容编排**: dacapo-learning 实现"模糊愿望 → 具体学习路径"
- **JSON 接口**: dacapo-wiki 支持结构化上下文传递
- **对标 dbs**: 统一入口 + 智能路由 + 直接执行

### 新增功能
- 5 种意图识别（learn/status/discover/visualize/suggest）
- 历史上下文检索（自动调用 dacapo-wiki）
- 4 种学习编排模式（理论/实战/工具/体系）
- 6 个 references 文件（渐进式加载）
- 跨项目草蛇灰线发现

### 参考架构
- skill-creator（渐进式加载设计）
- dbs-goal/dbs-jtbd（任务编排框架）
- dbs 主入口（统一路由模式）

### 开发统计
- 模式: fable5.1 编排 + opus5.5 执行
- 3 个 agents 并行
- 总用时: ~30 分钟
- 总 Tokens: ~281K

---

## v1.0.0 - MVP (2026-09-28)

### 初始功能
- dacapo-wiki: 跨项目概念探索（llm-wiki.py）
- dacapo-learning: 自适应学习（复利式对话）
- dacapo-main: 基础路由
- 11 个 dacapo skills 集成

### 核心价值
- 复利式学习（2.4x 效果提升）
- 跨项目草蛇灰线
- Obsidian frontmatter 状态记录
